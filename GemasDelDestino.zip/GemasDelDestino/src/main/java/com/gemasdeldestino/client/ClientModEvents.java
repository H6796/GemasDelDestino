package com.gemasdeldestino.client;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.entity.NpcEntity;
import com.gemasdeldestino.entity.FusionBossEntity;
import com.gemasdeldestino.entity.GuardianBossEntity;
import com.gemasdeldestino.entity.SilasBossEntity;
import com.gemasdeldestino.entity.TraderEntity;
import com.gemasdeldestino.registry.ModEntities;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GemasMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {

    @SubscribeEvent
    public static void registerKeys(net.minecraftforge.client.event.RegisterKeyMappingsEvent event) {
        event.register(GemasShaders.TOGGLE);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ELDRIC.get(), ctx -> new NpcRenderer(ctx, "eldric"));
        event.registerEntityRenderer(ModEntities.LYRA.get(), ctx -> new NpcRenderer(ctx, "lyra"));
        event.registerEntityRenderer(ModEntities.BRAM.get(), ctx -> new NpcRenderer(ctx, "bram"));
        event.registerEntityRenderer(ModEntities.SILAS.get(), ctx -> new NpcRenderer(ctx, "silas"));
        event.registerEntityRenderer(ModEntities.SILAS_JEFE.get(), BossRenderer::new);
        event.registerEntityRenderer(ModEntities.ANCIANO.get(), ctx -> new NpcRenderer(ctx, "anciano"));
        event.registerEntityRenderer(ModEntities.COMERCIANTE.get(), TraderRenderer::new);
        event.registerEntityRenderer(ModEntities.GUARDIAN.get(), GuardianRenderer::new);
        event.registerEntityRenderer(ModEntities.QUIMERA.get(), FusionRenderer::new);
    }

    /** Los NPC usan el modelo de jugador con su propia skin de 64x64. */
    public static class NpcRenderer extends HumanoidMobRenderer<NpcEntity, PlayerModel<NpcEntity>> {
        private final ResourceLocation texture;

        public NpcRenderer(EntityRendererProvider.Context ctx, String name) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
            this.texture = new ResourceLocation(GemasMod.MODID, "textures/entity/" + name + ".png");
        }

        @Override
        public ResourceLocation getTextureLocation(NpcEntity entity) {
            return texture;
        }
    }

    public static class BossRenderer extends HumanoidMobRenderer<SilasBossEntity, PlayerModel<SilasBossEntity>> {
        private static final ResourceLocation TEXTURE = new ResourceLocation(GemasMod.MODID, "textures/entity/silas_jefe.png");

        public BossRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.7F);
        }

        @Override
        protected void scale(SilasBossEntity entity, PoseStack poseStack, float partialTick) {
            poseStack.scale(1.3F, 1.3F, 1.3F);
        }

        @Override
        public ResourceLocation getTextureLocation(SilasBossEntity entity) {
            return TEXTURE;
        }
    }

    /** Cada oficio tiene su propia skin. */
    public static class TraderRenderer extends HumanoidMobRenderer<TraderEntity, PlayerModel<TraderEntity>> {
        public TraderRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        }

        @Override
        public ResourceLocation getTextureLocation(TraderEntity entity) {
            return new ResourceLocation(GemasMod.MODID, "textures/entity/comerciante_" + entity.getProfession().texture() + ".png");
        }
    }

    /** Minijefes: una skin por gema y algo más grandes. */
    public static class GuardianRenderer extends HumanoidMobRenderer<GuardianBossEntity, PlayerModel<GuardianBossEntity>> {
        public GuardianRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.6F);
        }

        @Override
        protected void scale(GuardianBossEntity entity, PoseStack poseStack, float partialTick) {
            poseStack.scale(1.2F, 1.2F, 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(GuardianBossEntity entity) {
            return new ResourceLocation(GemasMod.MODID, "textures/entity/guardian_" + entity.getGem().name().toLowerCase() + ".png");
        }
    }

    /** La Quimera: el doble de grande que un jugador. */
    public static class FusionRenderer extends HumanoidMobRenderer<FusionBossEntity, PlayerModel<FusionBossEntity>> {
        private static final ResourceLocation TEXTURE = new ResourceLocation(GemasMod.MODID, "textures/entity/quimera.png");

        public FusionRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 1.2F);
        }

        @Override
        protected void scale(FusionBossEntity entity, PoseStack poseStack, float partialTick) {
            poseStack.scale(2.2F, 2.2F, 2.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(FusionBossEntity entity) {
            return TEXTURE;
        }
    }

    private ClientModEvents() {}
}
