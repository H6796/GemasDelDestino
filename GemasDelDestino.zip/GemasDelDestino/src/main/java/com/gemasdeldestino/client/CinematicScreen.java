package com.gemasdeldestino.client;

import com.gemasdeldestino.cinematic.Cinematic;
import com.gemasdeldestino.story.DialogueLine;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Reproduce una cinemática: mueve una cámara invisible entre planos, oculta el HUD,
 * dibuja franjas negras de cine y subtítulos con efecto máquina de escribir. ESC la salta.
 */
public class CinematicScreen extends Screen {
    private final Cinematic cinematic;
    private final Vec3 anchor;
    private final int total;

    private ArmorStand camera;
    private CameraType previousCameraType;
    private boolean previousHideGui;
    private boolean restored = false;

    private int tick = 0;
    private int currentShot = -1;
    private int shotStart = 0;

    private String queuedDialogueId;
    private List<DialogueLine> queuedDialogue;

    public CinematicScreen(Cinematic cinematic, Vec3 anchor) {
        super(Component.literal("Cinemática"));
        this.cinematic = cinematic;
        this.anchor = anchor;
        this.total = cinematic.totalTicks();
    }

    public void queueDialogue(String id, List<DialogueLine> lines) {
        this.queuedDialogueId = id;
        this.queuedDialogue = lines;
    }

    @Override
    protected void init() {
        if (camera != null || minecraft == null || minecraft.level == null) return;
        camera = new ArmorStand(EntityType.ARMOR_STAND, minecraft.level);
        camera.setInvisible(true);
        camera.setNoGravity(true);
        previousCameraType = minecraft.options.getCameraType();
        previousHideGui = minecraft.options.hideGui;
        minecraft.options.setCameraType(CameraType.FIRST_PERSON);
        minecraft.options.hideGui = true;
        updateCamera(0, true);
        minecraft.setCameraEntity(camera);
        onShotChanged(0);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ Lógica de cámara
    private int shotIndexAt(int t) {
        int acc = 0;
        for (int i = 0; i < cinematic.shots.size(); i++) {
            acc += cinematic.shots.get(i).ticks();
            if (t < acc) return i;
        }
        return cinematic.shots.size() - 1;
    }

    private int shotStartTick(int index) {
        int acc = 0;
        for (int i = 0; i < index; i++) acc += cinematic.shots.get(i).ticks();
        return acc;
    }

    private void updateCamera(int t, boolean snap) {
        int idx = shotIndexAt(t);
        Cinematic.Shot shot = cinematic.shots.get(idx);
        float p = Mth.clamp((t - shotStartTick(idx)) / (float) Math.max(1, shot.ticks()), 0F, 1F);
        float e = p * p * (3F - 2F * p); // suavizado
        Vec3 pos = anchor.add(shot.from().lerp(shot.to(), e));
        Vec3 look = anchor.add(shot.lookFrom().lerp(shot.lookTo(), e)).subtract(pos);

        float yaw = (float) Math.toDegrees(Math.atan2(look.z, look.x)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(look.y, Math.sqrt(look.x * look.x + look.z * look.z)));
        double y = pos.y - camera.getEyeHeight();

        if (snap) {
            camera.setPos(pos.x, y, pos.z);
            camera.xo = pos.x; camera.yo = y; camera.zo = pos.z;
            camera.xOld = pos.x; camera.yOld = y; camera.zOld = pos.z;
            setRot(yaw, pitch);
            camera.yRotO = yaw; camera.xRotO = pitch; camera.yHeadRotO = yaw;
        } else {
            camera.xo = camera.getX(); camera.yo = camera.getY(); camera.zo = camera.getZ();
            camera.xOld = camera.getX(); camera.yOld = camera.getY(); camera.zOld = camera.getZ();
            camera.yRotO = camera.getYRot(); camera.xRotO = camera.getXRot(); camera.yHeadRotO = camera.yHeadRot;
            yaw = camera.getYRot() + Mth.wrapDegrees(yaw - camera.getYRot());
            camera.setPos(pos.x, y, pos.z);
            setRot(yaw, pitch);
        }
    }

    private void setRot(float yaw, float pitch) {
        camera.setYRot(yaw);
        camera.setXRot(pitch);
        camera.setYHeadRot(yaw);
        camera.yHeadRot = yaw;
    }

    private void onShotChanged(int index) {
        currentShot = index;
        shotStart = shotStartTick(index);
        String s = cinematic.shots.get(index).sound();
        if (s == null || minecraft == null) return;
        SoundEvent sound = switch (s) {
            case "chime" -> SoundEvents.AMETHYST_BLOCK_CHIME;
            case "thunder" -> SoundEvents.LIGHTNING_BOLT_THUNDER;
            case "wither" -> SoundEvents.WITHER_SPAWN;
            case "beacon" -> SoundEvents.BEACON_ACTIVATE;
            case "totem" -> SoundEvents.TOTEM_USE;
            case "portal" -> SoundEvents.PORTAL_TRIGGER;
            case "levelup" -> SoundEvents.PLAYER_LEVELUP;
            default -> null;
        };
        if (sound != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(sound, 1.0F, 0.7F));
    }

    @Override
    public void tick() {
        if (minecraft == null || minecraft.level == null || minecraft.player == null) {
            onClose();
            return;
        }
        tick++;
        if (tick >= total) {
            onClose();
            return;
        }
        int idx = shotIndexAt(tick);
        if (idx != currentShot) onShotChanged(idx);
        updateCamera(tick, false);
    }

    // ------------------------------------------------------------------ Dibujo
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        float t = tick + partial;

        // Franjas de cine
        int bar = (int) (height / 7F * Mth.clamp(t / 20F, 0F, 1F));
        g.fill(0, 0, width, bar, 0xFF000000);
        g.fill(0, height - bar, width, height, 0xFF000000);

        // Fundido a negro al inicio y al final
        float fade = 0F;
        if (t < 15) fade = 1F - t / 15F;
        else if (total - t < 15) fade = 1F - (total - t) / 15F;
        if (fade > 0) g.fill(0, 0, width, height, ((int) (Mth.clamp(fade, 0F, 1F) * 255) << 24));

        // Subtítulos
        Cinematic.Shot shot = cinematic.shots.get(Math.max(0, currentShot));
        DialogueLine line = shot.line();
        if (line != null) {
            int chars = Math.min(line.text().length(), (int) ((t - shotStart) * 1.4F));
            if (chars > 0) {
                List<FormattedCharSequence> wrapped = font.split(Component.literal(line.text().substring(0, chars)), (int) (width * 0.7F));
                int textH = wrapped.size() * 11;
                int y = height - Math.max(bar, 40) / 2 - textH / 2 - (bar > 0 ? 0 : 20);
                g.drawCenteredString(font, Component.literal(line.speaker()), width / 2, y - 13, line.color());
                for (FormattedCharSequence seq : wrapped) {
                    g.drawCenteredString(font, seq, width / 2, y, 0xFFFFFF);
                    y += 11;
                }
            }
        }
        g.drawString(font, "ESC: saltar", width - font.width("ESC: saltar") - 6, 6, 0x777777, false);
    }

    // ------------------------------------------------------------------ Fin
    private void restore() {
        if (restored || minecraft == null) return;
        restored = true;
        if (minecraft.player != null) minecraft.setCameraEntity(minecraft.player);
        if (previousCameraType != null) minecraft.options.setCameraType(previousCameraType);
        minecraft.options.hideGui = previousHideGui;
    }

    @Override
    public void removed() {
        restore();
        super.removed();
    }

    @Override
    public void onClose() {
        restore();
        super.onClose();
        if (queuedDialogue != null && minecraft != null) {
            Minecraft.getInstance().setScreen(new DialogueScreen(queuedDialogueId, queuedDialogue));
        }
    }
}
