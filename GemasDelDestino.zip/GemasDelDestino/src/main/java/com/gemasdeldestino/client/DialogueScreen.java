package com.gemasdeldestino.client;

import com.gemasdeldestino.network.ModNetwork;
import com.gemasdeldestino.story.DialogueLine;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Caja de diálogo estilo Story Mode: nombre del personaje, texto que aparece letra a letra
 * y clic / espacio para continuar.
 */
public class DialogueScreen extends Screen {
    private static final float CHARS_PER_TICK = 1.6F;

    private final String dialogueId;
    private final List<DialogueLine> lines;
    private int index = 0;
    private int lineTicks = 0;
    private boolean finished = false;

    public DialogueScreen(String dialogueId, List<DialogueLine> lines) {
        super(Component.literal("Diálogo"));
        this.dialogueId = dialogueId;
        this.lines = lines;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        lineTicks++;
        if (lineTicks % 3 == 0 && !fullyShown() && minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ITEM_PICKUP, 1.9F, 0.06F));
        }
    }

    private DialogueLine current() {
        return lines.get(Math.min(index, lines.size() - 1));
    }

    private int visibleChars(float partial) {
        return Math.min(current().text().length(), (int) ((lineTicks + partial) * CHARS_PER_TICK));
    }

    private boolean fullyShown() {
        return lines.isEmpty() || visibleChars(0) >= current().text().length();
    }

    private void advance() {
        if (lines.isEmpty()) {
            onClose();
            return;
        }
        if (!fullyShown()) {
            lineTicks = 10_000;
            return;
        }
        index++;
        lineTicks = 0;
        if (index >= lines.size()) onClose();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        advance();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_E) {
            advance();
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        if (!finished) {
            finished = true;
            ModNetwork.CHANNEL.sendToServer(new ModNetwork.DialogueFinished(dialogueId));
        }
        super.onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        if (lines.isEmpty()) return;
        DialogueLine line = current();

        int boxW = Math.min(360, width - 20);
        int boxH = 70;
        int x = (width - boxW) / 2;
        int y = height - boxH - 12;

        // Fondo y bordes
        g.fill(x - 2, y - 2, x + boxW + 2, y + boxH + 2, 0xFF000000 | line.color());
        g.fill(x, y, x + boxW, y + boxH, 0xE0101018);

        // Placa con el nombre
        int nameW = font.width(line.speaker()) + 12;
        g.fill(x + 8, y - 12, x + 8 + nameW, y + 2, 0xFF000000 | line.color());
        g.fill(x + 9, y - 11, x + 7 + nameW, y + 1, 0xFF1A1A24);
        g.drawString(font, line.speaker(), x + 14, y - 8, line.color(), false);

        // Texto con efecto máquina de escribir
        String shown = line.text().substring(0, visibleChars(partial));
        List<FormattedCharSequence> wrapped = font.split(Component.literal(shown), boxW - 20);
        int ty = y + 10;
        for (FormattedCharSequence seq : wrapped) {
            g.drawString(font, seq, x + 10, ty, 0xFFFFFF, false);
            ty += 11;
        }

        // Indicador para continuar
        if (fullyShown() && (lineTicks / 8) % 2 == 0) {
            String hint = index >= lines.size() - 1 ? "▶ Cerrar" : "▶ Clic o espacio";
            g.drawString(font, hint, x + boxW - font.width(hint) - 8, y + boxH - 12, 0xAAAAAA, false);
        }
        g.drawString(font, (index + 1) + "/" + lines.size(), x + 10, y + boxH - 12, 0x666666, false);
    }
}
