package com.gemasdeldestino.client;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.entity.FusionBossEntity;
import com.gemasdeldestino.entity.GuardianBossEntity;
import com.gemasdeldestino.entity.SilasBossEntity;
import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.registry.ModBlocks;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * El shader propio del mod. Es un efecto de postprocesado (como los de las cinemáticas de Minecraft)
 * que cambia según dónde estés:
 *   - Cinemáticas: look de película (bloom, viñeta, grano, aberración cromática).
 *   - Mazmorras: ambiente frío y oscuro, las luces resplandecen.
 *   - Fortaleza del Eclipse y jefes: tinte morado que late, ondas de calor y aberración.
 *   - Modo "siempre": mejora general de color y resplandor en todo el mundo.
 * La tecla K alterna entre automático, siempre y apagado.
 */
@Mod.EventBusSubscriber(modid = GemasMod.MODID, value = Dist.CLIENT)
public final class GemasShaders {

    public enum Setting { AUTOMATICO, SIEMPRE, APAGADO }

    public static final KeyMapping TOGGLE = new KeyMapping("key.gemasdeldestino.shader", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.gemasdeldestino");

    private static final String[] PRESETS = {"epico", "cinematica", "mazmorra", "eclipse"};
    private static final boolean[] FAILED = new boolean[PRESETS.length];

    private static Setting setting = Setting.AUTOMATICO;
    private static PostChain chain;
    private static int current = -1;
    private static int width = -1, height = -1;
    private static int contextCache = -1;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (TOGGLE.consumeClick()) {
            setting = Setting.values()[(setting.ordinal() + 1) % Setting.values().length];
            if (mc.player != null) {
                String text = switch (setting) {
                    case AUTOMATICO -> "Shader de las Gemas: automático (cinemáticas, mazmorras y jefes)";
                    case SIEMPRE -> "Shader de las Gemas: siempre activo";
                    case APAGADO -> "Shader de las Gemas: apagado";
                };
                mc.player.displayClientMessage(Component.literal(text).withStyle(ChatFormatting.LIGHT_PURPLE), true);
            }
        }
        if (mc.level == null || mc.player == null) {
            setPreset(-1);
            return;
        }
        if (mc.player.tickCount % 10 == 0) contextCache = detectContext(mc);
        int desired;
        if (setting == Setting.APAGADO) desired = -1;
        else if (mc.screen instanceof CinematicScreen) desired = 1;
        else if (contextCache >= 0) desired = contextCache;
        else desired = setting == Setting.SIEMPRE ? 0 : -1;
        setPreset(desired);
    }

    /** 3 = jefes o fortaleza, 2 = mazmorra, -1 = nada especial. */
    private static int detectContext(Minecraft mc) {
        var player = mc.player;
        var level = mc.level;
        AABB near = player.getBoundingBox().inflate(40);
        if (!level.getEntitiesOfClass(SilasBossEntity.class, near).isEmpty()
                || !level.getEntitiesOfClass(FusionBossEntity.class, near).isEmpty()
                || !level.getEntitiesOfClass(GuardianBossEntity.class, player.getBoundingBox().inflate(16)).isEmpty()) {
            return 3;
        }
        BlockPos p = player.blockPosition();
        // ¿Hay muros de la Fortaleza del Eclipse alrededor?
        Block eclipse = ModBlocks.MURO_ECLIPSE.get();
        for (int i = 0; i < 8; i++) {
            double a = Math.PI / 4 * i;
            for (int d = 4; d <= 28; d += 4) {
                BlockPos q = p.offset((int) (Math.cos(a) * d), 1, (int) (Math.sin(a) * d));
                if (level.getBlockState(q).is(eclipse)) return 3;
            }
        }
        // ¿Estamos sobre el suelo o dentro de los muros de una mazmorra?
        for (int dy = 1; dy <= 3; dy++) {
            Block below = level.getBlockState(p.below(dy)).getBlock();
            for (GemType g : GemType.values()) {
                if (below == g.dungeonFloor() || below == g.dungeonWall()) return 2;
            }
        }
        return -1;
    }

    private static void setPreset(int preset) {
        if (preset == current) return;
        close();
        current = preset;
        if (preset < 0 || FAILED[preset]) return;
        Minecraft mc = Minecraft.getInstance();
        try {
            chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(),
                    new ResourceLocation(GemasMod.MODID, "shaders/post/" + PRESETS[preset] + ".json"));
            width = mc.getWindow().getWidth();
            height = mc.getWindow().getHeight();
            chain.resize(width, height);
        } catch (Exception e) {
            FAILED[preset] = true;
            chain = null;
            LogUtils.getLogger().warn("[Gemas del Destino] No se pudo cargar el shader {}", PRESETS[preset], e);
        }
    }

    private static void close() {
        if (chain != null) {
            chain.close();
            chain = null;
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || chain == null) return;
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getWidth(), h = mc.getWindow().getHeight();
        if (w != width || h != height) {
            width = w;
            height = h;
            chain.resize(w, h);
        }
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        chain.process(event.getPartialTick());
        mc.getMainRenderTarget().bindWrite(false);
        RenderSystem.enableDepthTest();
    }

    private GemasShaders() {}
}
