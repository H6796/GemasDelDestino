package com.gemasdeldestino.block;

import com.gemasdeldestino.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Runa de puzzle. Clic derecho cambia el símbolo (0 rojo, 1 azul, 2 verde, 3 amarillo).
 * Cuando las 4 runas de la sala coinciden con el mural, se rompen los sellos.
 */
public class RuneBlock extends Block {
    public static final IntegerProperty SYMBOL = IntegerProperty.create("symbol", 0, 3);

    public RuneBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(SYMBOL, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SYMBOL);
    }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level instanceof ServerLevel server) {
            BlockState next = state.setValue(SYMBOL, (state.getValue(SYMBOL) + 1) % 4);
            server.setBlock(pos, next, 3);
            server.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.BLOCKS, 1.0F, 0.8F + next.getValue(SYMBOL) * 0.2F);
            checkSolved(server, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void checkSolved(ServerLevel level, BlockPos runePos) {
        BlockPos core = null;
        for (BlockPos p : BlockPos.betweenClosed(runePos.offset(-8, -3, -8), runePos.offset(8, 1, 8))) {
            if (level.getBlockState(p).is(ModBlocks.NUCLEO.get())) {
                core = p.immutable();
                break;
            }
        }
        if (core == null) return;
        BlockState coreState = level.getBlockState(core);
        if (coreState.getValue(PuzzleCoreBlock.SOLVED)) return;

        List<BlockPos> runes = new ArrayList<>();
        for (BlockPos p : BlockPos.betweenClosed(core.offset(-6, 0, -6), core.offset(6, 2, 6))) {
            if (level.getBlockState(p).is(ModBlocks.RUNA.get())) runes.add(p.immutable());
        }
        if (runes.size() != 4) return;
        runes.sort(Comparator.comparingInt(BlockPos::getX));
        int pattern = coreState.getValue(PuzzleCoreBlock.PATTERN);
        for (int i = 0; i < 4; i++) {
            if (level.getBlockState(runes.get(i)).getValue(SYMBOL) != PuzzleCoreBlock.symbolAt(pattern, i)) return;
        }
        level.setBlock(core, coreState.setValue(PuzzleCoreBlock.SOLVED, true), 3);
        DungeonUtil.openRoomSeals(level, core, "¡Las runas brillan al unísono y el sello se rompe!");
    }
}
