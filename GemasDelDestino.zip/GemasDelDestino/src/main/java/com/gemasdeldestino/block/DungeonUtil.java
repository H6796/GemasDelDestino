package com.gemasdeldestino.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

/** Utilidades compartidas por los bloques de puzzle. */
public final class DungeonUtil {

    /** Elimina todos los bloques {@code target} en una caja alrededor de {@code center}. Devuelve cuántos ha quitado. */
    public static int breakBlocks(ServerLevel level, BlockPos center, int rxz, int ryDown, int ryUp, Block target) {
        int n = 0;
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-rxz, -ryDown, -rxz), center.offset(rxz, ryUp, rxz))) {
            if (level.getBlockState(p).is(target)) {
                level.setBlock(p, Blocks.AIR.defaultBlockState(), 3);
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 6, 0.3, 0.3, 0.3, 0.05);
                n++;
            }
        }
        return n;
    }

    /** Abre los sellos rúnicos de la sala cuyo centro (a ras de suelo) es {@code roomCenter}. */
    public static void openRoomSeals(ServerLevel level, BlockPos roomCenter, String message) {
        int n = breakBlocks(level, roomCenter, 8, 1, 5, com.gemasdeldestino.registry.ModBlocks.SELLO.get());
        level.playSound(null, roomCenter, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 1.5F, 1.2F);
        if (n > 0) {
            for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, new AABB(roomCenter).inflate(20))) {
                p.displayClientMessage(Component.literal(message).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE), true);
            }
        }
    }

    private DungeonUtil() {}
}
