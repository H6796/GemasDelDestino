package com.gemasdeldestino.block;

import com.gemasdeldestino.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Puerta de la cámara de la gema. Se abre con la Llave del Sello. */
public class KeyDoorBlock extends Block {
    public KeyDoorBlock(Properties props) {
        super(props);
    }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level instanceof ServerLevel server) {
            ItemStack held = player.getItemInHand(hand);
            if (held.is(ModItems.LLAVE_SELLO.get())) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                DungeonUtil.breakBlocks(server, pos, 3, 3, 3, this);
                server.playSound(null, pos, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 1.0F, 0.6F);
                server.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.0F);
                player.displayClientMessage(Component.literal("La cerradura del sello se abre...").withStyle(ChatFormatting.GOLD), true);
            } else {
                player.displayClientMessage(Component.literal("Necesitas la Llave del Sello. La custodia el guardián de esta mazmorra.")
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
