package com.gemasdeldestino.block;

import com.gemasdeldestino.item.GemType;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Altar de desafío. STATE: 0 inactivo, 1-3 oleada en curso, 4 superado. GEM: tema de la mazmorra.
 * Al superar las 3 oleadas se rompen los sellos de la sala.
 */
public class ChallengeAltarBlock extends Block {
    public static final IntegerProperty STATE = IntegerProperty.create("state", 0, 4);
    public static final IntegerProperty GEM = IntegerProperty.create("gem", 0, 7);
    public static final String TAG = "gemas_desafio";

    public ChallengeAltarBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(STATE, 0).setValue(GEM, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(STATE, GEM);
    }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level instanceof ServerLevel server) {
            int s = state.getValue(STATE);
            if (s == 0) {
                server.setBlock(pos, state.setValue(STATE, 1), 3);
                broadcast(server, pos, "¡Desafío aceptado! Oleada 1 de 3", ChatFormatting.RED);
                spawnWave(server, pos, state.getValue(GEM), 1);
                server.scheduleTick(pos, this, 40);
            } else if (s < 4) {
                player.displayClientMessage(Component.literal("¡Derrota a todos los enemigos de la oleada!").withStyle(ChatFormatting.RED), true);
            } else {
                player.displayClientMessage(Component.literal("Este desafío ya ha sido superado.").withStyle(ChatFormatting.GRAY), true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int s = state.getValue(STATE);
        if (s == 0 || s == 4) return;
        AABB room = new AABB(pos).inflate(9, 4, 9);
        int alive = level.getEntitiesOfClass(Mob.class, room, m -> m.isAlive() && m.getTags().contains(TAG)).size();
        if (alive == 0) {
            if (s < 3) {
                level.setBlock(pos, state.setValue(STATE, s + 1), 3);
                broadcast(level, pos, "Oleada " + (s + 1) + " de 3", ChatFormatting.RED);
                spawnWave(level, pos, state.getValue(GEM), s + 1);
            } else {
                level.setBlock(pos, state.setValue(STATE, 4), 3);
                level.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.BLOCKS, 1.0F, 1.0F);
                DungeonUtil.openRoomSeals(level, pos.below(), "¡Desafío superado! Los sellos se desvanecen.");
                return;
            }
        }
        level.scheduleTick(pos, this, 40);
    }

    private static void spawnWave(ServerLevel level, BlockPos pos, int gem, int wave) {
        GemType g = GemType.byIndex(gem);
        int count = 2 + wave + gem / 2;
        for (int i = 0; i < count; i++) {
            EntityType<?> type = switch (i % 3) {
                case 0 -> g.spawnerMob;
                case 1 -> g.secondMob();
                default -> wave == 3 ? g.guardian : g.spawnerMob;
            };
            Entity e = type.create(level);
            if (!(e instanceof Mob mob)) continue;
            double a = Math.PI * 2 * i / count;
            mob.moveTo(pos.getX() + 0.5 + Math.cos(a) * 4.5, pos.getY(), pos.getZ() + 0.5 + Math.sin(a) * 4.5, level.random.nextFloat() * 360, 0);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);
            mob.addTag(TAG);
            mob.setPersistenceRequired();
            level.addFreshEntity(mob);
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, mob.getX(), mob.getY() + 1, mob.getZ(), 15, 0.3, 0.6, 0.3, 0.02);
        }
        level.playSound(null, pos, SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 1.0F, 0.8F);
    }

    private static void broadcast(ServerLevel level, BlockPos pos, String msg, ChatFormatting color) {
        for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, new AABB(pos).inflate(24))) {
            p.displayClientMessage(Component.literal(msg).withStyle(color, ChatFormatting.BOLD), true);
        }
    }
}
