package com.gemasdeldestino.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Núcleo del puzzle de runas. PATTERN guarda la solución: 4 runas x 4 símbolos (base 4).
 * REVERSED indica que el mural se lee de derecha a izquierda.
 */
public class PuzzleCoreBlock extends Block {
    public static final IntegerProperty PATTERN = IntegerProperty.create("pattern", 0, 255);
    public static final BooleanProperty REVERSED = BooleanProperty.create("reversed");
    public static final BooleanProperty SOLVED = BooleanProperty.create("solved");

    public PuzzleCoreBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(PATTERN, 0).setValue(REVERSED, false).setValue(SOLVED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(PATTERN, REVERSED, SOLVED);
    }

    public static int symbolAt(int pattern, int index) {
        return (pattern >> (index * 2)) & 3;
    }
}
