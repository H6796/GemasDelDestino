package com.gemasdeldestino.network;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.story.DialogueLine;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GemasMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(OpenDialogue.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDialogue::encode).decoder(OpenDialogue::decode)
                .consumerMainThread(OpenDialogue::handle).add();
        CHANNEL.messageBuilder(PlayCinematic.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(PlayCinematic::encode).decoder(PlayCinematic::decode)
                .consumerMainThread(PlayCinematic::handle).add();
        CHANNEL.messageBuilder(DialogueFinished.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(DialogueFinished::encode).decoder(DialogueFinished::decode)
                .consumerMainThread(DialogueFinished::handle).add();
    }

    public static void sendDialogue(ServerPlayer player, String id, List<DialogueLine> lines) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenDialogue(id, lines));
    }

    public static void sendCinematic(ServerPlayer player, String id, Vec3 anchor) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new PlayCinematic(id, anchor.x, anchor.y, anchor.z));
    }

    // ---------------------------------------------------------------- Paquetes

    public record OpenDialogue(String id, List<DialogueLine> lines) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeUtf(id);
            buf.writeVarInt(lines.size());
            for (DialogueLine l : lines) {
                buf.writeUtf(l.speaker());
                buf.writeUtf(l.text());
                buf.writeInt(l.color());
            }
        }

        public static OpenDialogue decode(FriendlyByteBuf buf) {
            String id = buf.readUtf();
            int n = buf.readVarInt();
            List<DialogueLine> lines = new ArrayList<>(n);
            for (int i = 0; i < n; i++) lines.add(new DialogueLine(buf.readUtf(), buf.readUtf(), buf.readInt()));
            return new OpenDialogue(id, lines);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.gemasdeldestino.client.ClientHooks.openDialogue(id, lines));
        }
    }

    public record PlayCinematic(String id, double x, double y, double z) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeUtf(id);
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
        }

        public static PlayCinematic decode(FriendlyByteBuf buf) {
            return new PlayCinematic(buf.readUtf(), buf.readDouble(), buf.readDouble(), buf.readDouble());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.gemasdeldestino.client.ClientHooks.playCinematic(id, new Vec3(x, y, z)));
        }
    }

    public record DialogueFinished(String id) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeUtf(id);
        }

        public static DialogueFinished decode(FriendlyByteBuf buf) {
            return new DialogueFinished(buf.readUtf());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) StoryManager.onDialogueFinished(player, id);
        }
    }

    private ModNetwork() {}
}
