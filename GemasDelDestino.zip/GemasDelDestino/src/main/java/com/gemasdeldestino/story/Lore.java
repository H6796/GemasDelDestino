package com.gemasdeldestino.story;

import com.gemasdeldestino.item.GemType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Libros que se encuentran por el mundo: diarios del traidor, notas de la Orden y pistas de puzzles. */
public final class Lore {

    public static ItemStack book(String title, String author, String... pages) {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", title);
        tag.putString("author", author);
        ListTag list = new ListTag();
        for (String p : pages) list.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(p))));
        tag.put("pages", list);
        tag.putBoolean("resolved", true);
        return book;
    }

    /** Diario del traidor en la cámara de cada gema. */
    public static ItemStack journal(GemType g) {
        String[] d = Dialogues.journal(g);
        return book(d[0], "S.", d[1]);
    }

    public static ItemStack entranceBook(GemType g) {
        return book("Advertencia", "Los Guardianes",
                "Viajero: has entrado en el " + g.baseName + ".\n\nLas puertas selladas solo se abren con ingenio o con valor. "
                        + "Los muros fueron forjados por los antiguos y ninguna herramienta puede romperlos.",
                "El guardián de esta mazmorra custodia la Llave del Sello.\n\nSin ella, la cámara de la "
                        + g.gemName + " permanecerá cerrada para siempre.\n\nQue la luz te guíe.");
    }

    public static ItemStack runeHint(boolean reversed) {
        if (reversed) {
            return book("Las Runas Invertidas", "Los Guardianes",
                    "Las runas deben cantar la misma canción que el mural del muro norte.\n\n"
                            + "Pero cuidado: los guardianes de esta mazmorra escribían como el reflejo en el agua...",
                    "...de derecha a izquierda.\n\nLa primera runa de la izquierda imita el último color del mural.");
        }
        return book("El Canto de las Runas", "Los Guardianes",
                "Las runas deben cantar la misma canción que el mural del muro norte.\n\n"
                        + "Toca cada runa para cambiar su color hasta que coincidan, de izquierda a derecha.");
    }

    public static ItemStack challengeHint() {
        return book("El Altar del Valor", "Los Guardianes",
                "Solo quien sobrevive a tres oleadas de sombras es digno de seguir adelante.\n\n"
                        + "Toca el altar cuando estés preparado. No hay vuelta atrás.");
    }

    public static ItemStack libraryBook(GemType g, int n) {
        String[][] books = {
                {"Notas de la Orden", "La Orden del Eclipse nació hace siglos, cuando un aprendiz de los guardianes quiso las ocho gemas para sí.\n\n"
                        + "Fue desterrado, pero sus seguidores juraron terminar su obra."},
                {"Sobre los Guardianes", "Cada gema fue confiada a un guardián inmortal, atado a su mazmorra.\n\n"
                        + "Ignar, Voltra, Zéfir, Gorrak, Nivalis, Solenne, Kronos y Nyx. Solo al ser derrotados liberan la llave de la cámara."},
                {"Carta sin enviar", "Hermano:\n\nNuestro líder se ha infiltrado entre los buscadores de gemas. Dice que ellos harán el trabajo "
                        + "por nosotros y que solo tendrá que esperar.\n\nNo sé si admirarlo o temerlo.\n\n- R."},
                {"El Guantelete", "Las ocho gemas por separado otorgan poderes menores.\n\nUnidas en un guantelete, se dice que pueden "
                        + "doblegar la voluntad de cualquier ser vivo.\n\nNingún guardián debe permitirlo."},
                {"Registro de suministros", "Botas de cuero teñidas de morado: 2 pares.\nTinta: 4 frascos.\nCapa con capucha (morada): 1.\n\n"
                        + "Entregar todo en el campamento de los buscadores. Discreción absoluta."},
        };
        String[] b = books[(g.ordinal() + n) % books.length];
        return book(b[0], "Desconocido", b[1]);
    }

    private Lore() {}
}
