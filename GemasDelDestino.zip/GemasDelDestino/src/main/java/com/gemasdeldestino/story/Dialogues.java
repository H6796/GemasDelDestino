package com.gemasdeldestino.story;

import com.gemasdeldestino.item.GemType;

import java.util.List;

import static com.gemasdeldestino.story.DialogueLine.*;

/**
 * Todos los textos de los diálogos con los NPC. Las pistas sobre el traidor van apareciendo poco a poco.
 */
public final class Dialogues {

    public static List<DialogueLine> eldricIntro() {
        return List.of(
                eldric("¡Bienvenido, viajero! Te estábamos esperando. Soy Eldric, guardián de las antiguas leyendas."),
                eldric("Hace siglos, ocho Gemas del Destino fueron selladas en mazmorras secretas para que nadie pudiera reunirlas."),
                eldric("Fuego, Tormenta, Viento, Tierra, Hielo, Luz, Tiempo y Vacío. Juntas otorgan un poder capaz de doblegar el mundo entero."),
                lyra("La Orden del Eclipse ha vuelto a moverse. Si encuentran las gemas antes que nosotros... estamos perdidos."),
                bram("Por eso te necesitamos. Nosotros ya somos viejos para colarnos en mazmorras llenas de trampas. Bueno... Eldric lo es."),
                eldric("Ejem. Las mazmorras están ocultas. Ni siquiera nosotros sabemos dónde."),
                eldric("Pero cada una tiene un pueblo cercano cuyo anciano guarda un mapa, partido en tres fragmentos."),
                silas("Yo he estudiado los registros. La primera pista está en Brasaroja, un pueblo de herreros. Toma esta brújula."),
                silas("Cuando consigas la gema, tráemela. Yo la guardaré a salvo aquí, en el campamento."),
                bram("Y antes de ir, pásate por la ciudad de Valdoria. Allí podrás cambiar esmeraldas por equipo. Lo vas a necesitar."),
                eldric("Ten paciencia y valor. Este viaje será largo."));
    }

    public static List<DialogueLine> eldricSeek(GemType g, int stage, int step) {
        Chapters.Chapter ch = Chapters.get(g.ordinal());
        if (stage == StoryData.STAGE_SEEK) {
            return List.of(
                    eldric("Usa el Mapa del Eclipse: te dirá si estás frío o caliente. La brújula solo te lleva a la zona."),
                    eldric("Cuando el mapa arda, busca algo fuera de lugar en el suelo. A veces basta con levantar una alfombra."),
                    eldric("Dentro, resuelve los enigmas y derrota al guardián. Él tiene la llave de la cámara de la " + g.gemName + "."));
        }
        String task = switch (step) {
            case StoryData.Q_MEET -> "Ve a " + ch.village() + " y habla con " + ch.elder() + ".";
            case StoryData.Q_FETCH -> ch.elder() + " necesita materiales. Vuelve a hablar con " + ch.elder() + " cuando los tengas.";
            case StoryData.Q_HUNT -> "Ayuda a " + ch.village() + " a librarse de los " + ch.killName() + ".";
            default -> "Busca la torre de vigía de " + ch.village() + ". Allí está el último fragmento.";
        };
        return List.of(
                eldric("Capítulo " + (g.ordinal() + 1) + ": la " + g.gemName + ". " + task),
                eldric("Si te pierdes, pídele otra brújula a Silas."));
    }

    public static List<DialogueLine> eldricReturn(GemType g, int delivered) {
        if (delivered >= 3) {
            return List.of(
                    eldric("¡La " + g.gemName + "! Puedo sentir su energía desde aquí."),
                    eldric("Por cierto... ¿has leído los diarios de las bases? Todos firmados con una 'S'."),
                    eldric("Dicen que el líder de la Orden del Eclipse nunca muestra su rostro. Inquietante."),
                    eldric("En fin. Llévale la gema a Silas, él sabrá qué hacer."));
        }
        return List.of(
                eldric("¡Lo has conseguido! Puedo sentir la energía de la " + g.gemName + " desde aquí."),
                eldric("Llévasela a Silas. Él la custodiará y descifrará el siguiente mapa."));
    }

    public static List<DialogueLine> silasCompass(GemType g, int stage) {
        if (stage == StoryData.STAGE_SEEK) {
            return List.of(silas("¿Has perdido la brújula? Aquí tienes otra. Apunta a la zona del " + g.baseName + "... más o menos."));
        }
        return List.of(silas("¿Otra brújula hacia " + Chapters.get(g.ordinal()).village() + "? Claro. No queremos que te pierdas... ¿verdad?"));
    }

    public static List<DialogueLine> silasReceive(GemType g) {
        return switch (g) {
            case FUEGO -> List.of(
                    silas("¡La Gema de Fuego! Increíble... Dámela, la guardaré en el cofre del campamento."),
                    narrador("(Le entregas la gema. Por un instante, sus ojos brillan con un destello violeta.)"),
                    silas("Según mis registros, la siguiente pista está en Puerto Trueno, un pueblo junto al mar."),
                    silas("Toma la brújula. Y date prisa."));
            case TORMENTA -> List.of(
                    silas("La Tormenta... ruge en mis manos. Quiero decir... ¡qué peligrosa! Mejor que la tenga yo."),
                    silas("La siguiente pista está en Cumbreventosa. Cerca de allí se alza la Ciudadela de Aurora, por si necesitas comerciar."));
            case VIENTO -> List.of(
                    silas("Tres de ocho. Vamos bien... muy bien."),
                    narrador("(Silas guarda la gema bajo su capa, no en el cofre.)"),
                    silas("Ahora ve a Raíz Profunda. Necesitarás visitar el Nether, así que prepárate bien."));
            case TIERRA -> List.of(
                    silas("La mitad. Cuatro gemas... puedo sentir cómo laten juntas."),
                    silas("La siguiente está bajo el hielo. Busca Escarcha Alta, en las tierras nevadas. Abrígate."));
            case HIELO -> List.of(
                    silas("Fría como mi... como el invierno. Gracias, amigo."),
                    narrador("(Al tocar la gema, la escarcha se extiende por los dedos de Silas. No parece importarle.)"),
                    silas("Valle Solar es el siguiente destino. Dicen que su monasterio guarda la luz más pura."));
            case LUZ -> List.of(
                    silas("La Luz... qué irónico que acabe en mis manos."),
                    silas("¿Qué? Nada, nada. Es una broma de eruditos."),
                    silas("Ve a Relojoria. El tiempo corre en nuestra contra."));
            case TIEMPO -> List.of(
                    silas("Siete. Solo falta una. He esperado siglos... digo, años... ¡semanas!"),
                    silas("La última pista está en Umbral, el pueblo de los videntes. Es la más peligrosa... pero confío en ti."),
                    silas("Siempre he confiado en ti."));
            case VACIO -> List.of(
                    silas("La Gema del Vacío... la última."),
                    narrador("(Silas sonríe. El aire a su alrededor empieza a temblar.)"),
                    silas("Gracias. De verdad. No podría haberlo hecho sin ti."));
        };
    }

    // ------------------------------------------------------------------ Ancianos de los pueblos
    private static DialogueLine elder(Chapters.Chapter ch, String text) {
        return new DialogueLine(ch.elder(), text, 0xE6C27A);
    }

    private static String reqList(Chapters.Chapter ch) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ch.fetch().size(); i++) {
            Chapters.Req r = ch.fetch().get(i);
            if (i > 0) sb.append(i == ch.fetch().size() - 1 ? " y " : ", ");
            sb.append(r.count()).append(" ").append(r.name());
        }
        return sb.toString();
    }

    public static List<DialogueLine> elderIntro(int gi) {
        Chapters.Chapter ch = Chapters.get(gi);
        List<DialogueLine> out = new java.util.ArrayList<>();
        out.add(elder(ch, "Forastero... llevas el olor del campamento de los buscadores. Bienvenido a " + ch.village() + "."));
        for (String l : ch.lore()) out.add(elder(ch, l));
        out.add(elder(ch, "Te daré los fragmentos, pero primero demuestra que eres digno."));
        out.add(elder(ch, "Tráeme " + reqList(ch) + ", " + ch.fetchReason() + "."));
        out.add(narrador("Consejo: los comerciantes del pueblo y de la ciudad aceptan esmeraldas."));
        return out;
    }

    public static List<DialogueLine> elderFetchWait(int gi, String progress) {
        Chapters.Chapter ch = Chapters.get(gi);
        return List.of(elder(ch, "Todavía necesito " + reqList(ch) + "."), narrador("Llevas: " + progress));
    }

    public static List<DialogueLine> elderFetchDone(int gi) {
        Chapters.Chapter ch = Chapters.get(gi);
        return List.of(
                elder(ch, "¡Justo lo que necesitábamos! Toma, el primer fragmento del mapa."),
                elder(ch, "Pero hay otro problema: los " + ch.killName() + " no nos dejan en paz."),
                elder(ch, "Elimina " + ch.killCount() + " y te daré el segundo fragmento. Da igual quién del grupo los derrote."));
    }

    public static List<DialogueLine> elderHuntWait(int gi, int done) {
        Chapters.Chapter ch = Chapters.get(gi);
        return List.of(elder(ch, "Aún quedan " + ch.killName() + " ahí fuera. Llevas " + done + " de " + ch.killCount() + "."));
    }

    public static List<DialogueLine> elderHuntDone(int gi, String where) {
        Chapters.Chapter ch = Chapters.get(gi);
        return List.of(
                elder(ch, "Gracias, de verdad. Aquí tienes el segundo fragmento."),
                elder(ch, ch.silasClue()),
                elder(ch, "El tercer fragmento lo guardaba nuestro vigía, en su torre " + where + "."),
                elder(ch, "Hace días que no sabemos nada de él. No hay brújula que te lleve: tendrás que orientarte por el sol."));
    }

    public static List<DialogueLine> elderTowerWait(int gi, String where) {
        Chapters.Chapter ch = Chapters.get(gi);
        return List.of(elder(ch, "La torre del vigía está " + where + ". El fragmento estará en lo más alto."));
    }

    public static List<DialogueLine> elderMap(int gi) {
        Chapters.Chapter ch = Chapters.get(gi);
        GemType g = GemType.byIndex(gi);
        return List.of(
                elder(ch, "Los tres fragmentos... déjame unirlos."),
                narrador("(Los fragmentos se funden en un mapa que brilla con luz violeta.)"),
                elder(ch, "Es el Mapa del Eclipse. No muestra el lugar exacto del " + g.baseName + ": siente el calor de la gema."),
                elder(ch, "Cuanto más cerca estés, más arderá. Y toma esta vieja brújula: no es precisa, pero te llevará a la zona."),
                elder(ch, "La entrada estará oculta. Busca con cuidado... y vuelve con vida."));
    }

    public static List<DialogueLine> elderOther(int gi, boolean past) {
        Chapters.Chapter ch = Chapters.get(gi);
        if (past) return List.of(elder(ch, "Gracias por todo lo que hiciste por " + ch.village() + ". Cuídate de las capas moradas."));
        return List.of(elder(ch, "Aún no es tu momento, forastero. Vuelve cuando el destino te traiga."));
    }

    public static List<DialogueLine> silasNoGem(GemType g) {
        return List.of(silas("¿Y la " + g.gemName + "? No la llevas encima. Tráemela... por favor."));
    }

    public static List<DialogueLine> lyraTalk(int stage, int delivered) {
        if (stage <= StoryData.STAGE_TALK_ELDER) return List.of(lyra("Habla con Eldric. Él te lo explicará todo."));
        if (stage == StoryData.STAGE_BOSS) return List.of(lyra("¡Silas nos ha traicionado! Ha huido a su fortaleza. Rompe los cristales de las torres para entrar."));
        if (stage == StoryData.STAGE_END) return List.of(lyra("Nunca debí ignorar aquellas huellas. Gracias por salvarnos a todos."));
        return switch (delivered) {
            case 0 -> List.of(
                    lyra("Exploré los alrededores. Hay huellas recientes que van hacia el Templo de Ceniza..."),
                    lyra("¿Quién habrá ido allí antes que tú? Y solo hay huellas de ida, no de vuelta."));
            case 1 -> List.of(
                    lyra("Otra vez esas huellas. Botas de cuero morado... como las que usa... no, da igual."),
                    lyra("Seguro que me equivoco."));
            case 2 -> List.of(
                    lyra("Anoche no podía dormir. Vi a alguien junto al cofre de las gemas, susurrando: 'pronto seréis mías'."),
                    lyra("Estaba oscuro. Solo vi una capa morada."));
            default -> List.of(
                    lyra("He mirado en el cofre del campamento. Está VACÍO."),
                    lyra("¿Dónde guarda Silas las gemas que le traes?"));
        };
    }

    public static List<DialogueLine> bramTalk(int stage, int delivered) {
        if (stage <= StoryData.STAGE_TALK_ELDER) return List.of(bram("¿Eres el nuevo? Habla con Eldric, que le encanta dar discursos."));
        if (stage == StoryData.STAGE_BOSS) return List.of(bram("¡El guantelete que forjé era para ÉL! Cuidado en la fortaleza: dicen que tiene a los ocho guardianes a su servicio."));
        if (stage == StoryData.STAGE_END) return List.of(bram("Voy a fundir ese guantelete y hacer algo útil con él. Una sartén, quizá."));
        return switch (delivered) {
            case 0 -> List.of(bram("Las bases están llenas de trampas: lava, fosos, telarañas... lleva comida y una buena espada."));
            case 1 -> List.of(
                    bram("Silas me encargó forjar un guantelete con ocho huecos."),
                    bram("Dijo que era para 'exhibir' las gemas. Raro, ¿no?"));
            case 2 -> List.of(
                    bram("Terminé el guantelete. Silas se lo probó y se rió durante un buen rato."),
                    bram("No me gustó nada esa risa."));
            default -> List.of(
                    bram("Esos diarios firmados con una 'S' que encuentras en las bases..."),
                    bram("Conozco esa letra. La he visto en las notas de alguien de este campamento."));
        };
    }

    public static List<DialogueLine> silasIdle(int stage) {
        if (stage <= StoryData.STAGE_TALK_ELDER) return List.of(silas("Habla primero con Eldric. Yo estaré aquí, estudiando los mapas."));
        return List.of(silas("Las gemas están a salvo conmigo. Te lo prometo."));
    }

    public static List<DialogueLine> eldricBoss() {
        return List.of(
                eldric("¡Era Silas desde el principio! Ha huido a la Fortaleza del Eclipse con las ocho gemas."),
                eldric("Sus muros son irrompibles. En lo alto de cada una de sus cuatro torres brilla un Cristal de defensa."),
                eldric("Rompe los cuatro y la puerta se abrirá. Dentro, en el Salón del Trono, te espera lo peor."),
                bram("Ve con la mejor armadura que puedas conseguir, pociones y un tótem. Lo vas a necesitar."),
                eldric("Toma, otra brújula hacia la fortaleza. Que la luz te acompañe."));
    }

    public static List<DialogueLine> eldricEnd() {
        return List.of(
                eldric("Silas ha caído. Nos engañó a todos... pero tú nunca te rendiste."),
                eldric("Las ocho gemas se han dispersado por el mundo. Quizá sea lo mejor: nadie debería tenerlas todas."),
                eldric("Aunque, si quieres buscarlas, el Mapa del Eclipse todavía siente su calor."),
                eldric("Y la próxima vez... desconfía del que se ofrece a guardarlo todo."));
    }

    /** Diarios que el traidor dejó en cada mazmorra. Firmados con "S.". */
    public static String[] journal(GemType g) {
        return switch (g) {
            case FUEGO -> new String[]{"Diario de la Orden I",
                    "Los guardianes creían que nadie encontraría el Templo de Ceniza.\n\nPero yo no necesito encontrarlo. Alguien lo hará por mí.\n\n- S."};
            case TORMENTA -> new String[]{"Diario de la Orden II",
                    "El viejo Eldric confía en mí ciegamente. Los demás también.\n\nQue traigan las gemas al campamento... directamente a mis manos.\n\n- S."};
            case VIENTO -> new String[]{"Diario de la Orden III",
                    "El herrero ha forjado el guantelete. Ocho engarces, uno por gema.\n\nCuando estén todas, nadie podrá detenerme.\n\n- S."};
            case TIERRA -> new String[]{"Diario de la Orden IV",
                    "La exploradora, Lyra, empieza a sospechar. Ha visto mis huellas.\n\nDebo tener cuidado. Aún faltan cuatro.\n\n- S."};
            case HIELO -> new String[]{"Diario de la Orden V",
                    "Mis siervos terminan la Fortaleza del Eclipse. Muros que ninguna herramienta puede romper.\n\nAllí despertaré a los ocho guardianes... bajo mi mando.\n\n- S."};
            case LUZ -> new String[]{"Diario de la Orden VI",
                    "Los guardianes caídos no mueren del todo. Su esencia vuelve a las gemas.\n\nCuando las tenga todas, los traeré de vuelta. Y los uniré en uno solo.\n\n- S."};
            case TIEMPO -> new String[]{"Diario de la Orden VII",
                    "He contado cada día desde mi destierro. Siglos.\n\nEl buscador cree que trabaja para salvar el mundo. Trabaja para mí.\n\n- S."};
            case VACIO -> new String[]{"Diario de la Orden VIII",
                    "Si estás leyendo esto, has hecho exactamente lo que yo quería.\n\nGracias, héroe. Ahora vuelve al campamento.\n\nTe estoy esperando.\n\n- S."};
        };
    }

    private Dialogues() {}
}
