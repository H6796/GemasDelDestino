package com.gemasdeldestino.story;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.List;

/**
 * Los ocho capítulos. Cada uno tiene un pueblo con su anciano, tres misiones para conseguir
 * los fragmentos del mapa (recolectar, cazar y explorar la torre de vigía) y una mazmorra oculta.
 * Los requisitos van subiendo: hierro, diamantes, el Nether, biomas helados, fortalezas y por último los endermans.
 */
public final class Chapters {

    public record Req(Item item, int count, String name) {}

    public record Chapter(String village, String elder, List<Req> fetch, String fetchReason,
                          EntityType<?> killType, int killCount, String killName,
                          List<String> lore, String silasClue) {}

    private static final List<Chapter> ALL = List.of(
            new Chapter("Brasaroja", "Anciana Ember",
                    List.of(new Req(Items.COAL, 32, "carbones"), new Req(Items.IRON_INGOT, 16, "lingotes de hierro")),
                    "para volver a encender la gran forja del pueblo",
                    EntityType.ZOMBIE, 20, "zombis",
                    List.of("Brasaroja vive del fuego de su forja. Desde que la Orden del Eclipse pasó por aquí, la forja no arde igual.",
                            "Mis antepasados guardaban el mapa del Templo de Ceniza. Lo partieron en tres trozos para que nadie pudiera usarlo solo."),
                    "Hace unas semanas vino un hombre con capa morada preguntando por el templo. Dijo que era un erudito... de tu campamento."),
            new Chapter("Puerto Trueno", "Capitán Bruma",
                    List.of(new Req(Items.COPPER_INGOT, 32, "lingotes de cobre"), new Req(Items.GOLD_INGOT, 8, "lingotes de oro")),
                    "para reparar los pararrayos del puerto antes de la próxima tormenta",
                    EntityType.CREEPER, 15, "creepers",
                    List.of("Puerto Trueno sobrevive a las tormentas gracias a sus pararrayos. La Gema de la Tormenta las atrae hacia nosotros.",
                            "Mi tripulación encontró un mapa en un naufragio. Lo dividimos en tres partes por seguridad."),
                    "Un erudito de capa morada compró todas nuestras cartas de tormentas. Pagó con monedas grabadas con un eclipse."),
            new Chapter("Cumbreventosa", "Ermitaño Aeron",
                    List.of(new Req(Items.FEATHER, 24, "plumas"), new Req(Items.DIAMOND, 3, "diamantes")),
                    "para las cometas sagradas que calman el viento",
                    EntityType.SKELETON, 25, "esqueletos",
                    List.of("Aquí arriba el viento nunca descansa. Desde que el Santuario despertó, ruge día y noche.",
                            "Los ermitaños guardamos el mapa del Santuario en tres pergaminos. Uno se perdió con nuestro vigía."),
                    "El viento me trae susurros. Dicen que el líder del Eclipse duerme cada noche junto a los buscadores de gemas."),
            new Chapter("Raíz Profunda", "Druida Mossa",
                    List.of(new Req(Items.OBSIDIAN, 16, "bloques de obsidiana"), new Req(Items.BLAZE_ROD, 6, "varas de blaze")),
                    "para sellar las raíces que la Orden ha corrompido",
                    EntityType.BLAZE, 12, "blazes (en el Nether)",
                    List.of("Las raíces de este bosque llegan hasta la Cripta de la Tierra. Están enfermas.",
                            "El mapa de la cripta está tallado en tres tablillas de corteza. Te daré una por cada tarea."),
                    "Las raíces lo sienten todo. Sienten tres gemas latiendo juntas en un mismo lugar... y no es una mazmorra. Es tu campamento."),
            new Chapter("Escarcha Alta", "Matriarca Nívea",
                    List.of(new Req(Items.SNOW_BLOCK, 32, "bloques de nieve"), new Req(Items.GOLDEN_CARROT, 8, "zanahorias doradas")),
                    "para las provisiones del largo invierno",
                    EntityType.STRAY, 15, "esqueletos glaciales (en biomas helados)",
                    List.of("Escarcha Alta vive bajo una nevada que nunca termina. El Glaciar Eterno despertó con la Orden.",
                            "Nuestras abuelas grabaron el mapa del glaciar en tres placas de hielo. Solo te las daré si nos ayudas."),
                    "Una noche llegó un hombre de capa morada temblando de frío. Nos preguntó cuántas gemas quedaban por encontrar. Sonreía al oír la respuesta."),
            new Chapter("Valle Solar", "Hermano Lucio",
                    List.of(new Req(Items.GLOWSTONE, 16, "bloques de piedra luminosa"), new Req(Items.GOLDEN_APPLE, 4, "manzanas de oro")),
                    "para reavivar la luz del monasterio",
                    EntityType.WITHER_SKELETON, 10, "esqueletos wither (en las fortalezas del Nether)",
                    List.of("En Valle Solar adoramos la luz. Desde que la Catedral se cerró, los días son más cortos.",
                            "El mapa de la Catedral está escrito con tinta de luz en tres vitrales. Te los entregaré uno a uno."),
                    "Recé por ti, viajero. Y en mi oración vi a tu amigo erudito llorando de risa junto a un cofre vacío."),
            new Chapter("Relojoria", "Maestra Horaria",
                    List.of(new Req(Items.CLOCK, 8, "relojes"), new Req(Items.REDSTONE, 48, "polvos de redstone")),
                    "para reparar el Gran Reloj del pueblo",
                    EntityType.PHANTOM, 10, "phantoms (aparecen si pasas noches sin dormir)",
                    List.of("En Relojoria todos los relojes se pararon el mismo día. El día en que la Orden robó nuestra paciencia.",
                            "El mapa de la Relojería está dividido en tres engranajes. Encajan solo si los tienes todos."),
                    "Los relojes no mienten. Cada vez que entregas una gema, en tu campamento alguien gana un minuto de vida eterna."),
            new Chapter("Umbral", "Vidente Nox",
                    List.of(new Req(Items.ENDER_PEARL, 12, "perlas de ender"), new Req(Items.DIAMOND, 5, "diamantes")),
                    "para abrir el velo que oculta el Abismo",
                    EntityType.ENDERMAN, 20, "endermans",
                    List.of("Umbral es el último pueblo antes del Vacío. Aquí las sombras hablan.",
                            "El mapa del Abismo está roto en tres visiones. Solo quien demuestre su valor podrá verlas todas."),
                    "He visto tu futuro. Alguien de confianza alza un guantelete con ocho luces. Lleva una capa morada. ¿Te suena de algo?")
    );

    public static Chapter get(int i) {
        return ALL.get(Math.max(0, Math.min(ALL.size() - 1, i)));
    }

    private Chapters() {}
}
