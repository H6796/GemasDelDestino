package com.gemasdeldestino.story;

/** Una línea de diálogo o de subtítulo: quién habla, qué dice y de qué color es su nombre. */
public record DialogueLine(String speaker, String text, int color) {
    public static final int NARRADOR = 0xCCCCCC;
    public static final int ELDRIC = 0xFFD27F;
    public static final int LYRA = 0x7FDBFF;
    public static final int BRAM = 0xFF9F5A;
    public static final int SILAS = 0xB48CFF;
    public static final int VOZ = 0x8A2BE2;

    public static DialogueLine narrador(String t) { return new DialogueLine("Narrador", t, NARRADOR); }
    public static DialogueLine eldric(String t) { return new DialogueLine("Eldric", t, ELDRIC); }
    public static DialogueLine lyra(String t) { return new DialogueLine("Lyra", t, LYRA); }
    public static DialogueLine bram(String t) { return new DialogueLine("Bram", t, BRAM); }
    public static DialogueLine silas(String t) { return new DialogueLine("Silas", t, SILAS); }
    public static DialogueLine voz(String t) { return new DialogueLine("Voz misteriosa", t, VOZ); }
}
