package com.gemasdeldestino.story;

import com.gemasdeldestino.block.PedestalBlock;
import com.gemasdeldestino.cinematic.Cinematics;
import com.gemasdeldestino.entity.GuardianBossEntity;
import com.gemasdeldestino.entity.NpcEntity;
import com.gemasdeldestino.entity.SilasBossEntity;
import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.network.ModNetwork;
import com.gemasdeldestino.registry.ModEntities;
import com.gemasdeldestino.registry.ModItems;
import com.gemasdeldestino.entity.FusionBossEntity;
import com.gemasdeldestino.world.CampBuilder;
import com.gemasdeldestino.world.CastleBuilder;
import com.gemasdeldestino.world.DungeonBuilder;
import com.gemasdeldestino.world.TownBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * El "director" de la historia. Decide qué dice cada NPC, cuándo se generan pueblos, torres y
 * mazmorras, cuándo se reproducen las cinemáticas y cuándo Silas revela su verdadera identidad.
 *
 * Estructura de cada capítulo:
 *   1. Viajar al pueblo y hablar con el anciano.
 *   2. Misión de recolección -> fragmento 1.
 *   3. Misión de caza -> fragmento 2.
 *   4. Explorar la torre de vigía (sin brújula, solo indicaciones) -> fragmento 3.
 *   5. El anciano une los fragmentos: Mapa del Eclipse (frío/caliente) + brújula imprecisa.
 *   6. Encontrar la entrada oculta y superar la mazmorra: puzzles, minijefe, llave, cámara.
 *   7. Volver al campamento y entregar la gema a Silas.
 */
public final class StoryManager {

    // ================================================================== Tareas programadas
    private static final class Task {
        int ticks;
        final Consumer<MinecraftServer> action;
        Task(int ticks, Consumer<MinecraftServer> action) { this.ticks = ticks; this.action = action; }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    public static void schedule(int delay, Consumer<MinecraftServer> action) {
        TASKS.add(new Task(delay, action));
    }

    public static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        for (Task t : new ArrayList<>(TASKS)) if (--t.ticks <= 0) due.add(t);
        TASKS.removeAll(due);
        for (Task t : due) {
            try {
                t.action.accept(server);
            } catch (Exception e) {
                com.mojang.logging.LogUtils.getLogger().error("[Gemas del Destino] Error en una tarea programada", e);
            }
        }
    }

    public static void clearTasks() {
        TASKS.clear();
    }

    // ================================================================== Inicio
    public static void onPlayerJoin(ServerPlayer player) {
        StoryData d = StoryData.get(player.server);
        if (d.stage != StoryData.STAGE_NONE || d.starting) return;
        d.starting = true;
        UUID id = player.getUUID();
        schedule(80, server -> {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null || p.level().dimension() != Level.OVERWORLD) {
                d.starting = false;
                return;
            }
            startStory(p);
        });
    }

    public static void startStory(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        StoryData d = StoryData.get(player.server);
        d.reset();
        BlockPos center = CampBuilder.build(level, player.blockPosition().offset(8, 0, 0));
        d.campPos = center;
        spawnCampNpcs(level, d, true);

        // Ciudad de Valdoria, cerca del campamento
        BlockPos city = TownBuilder.findLand(level, offset(center, 200, 260), 200);
        d.cityPos[0] = city;
        TownBuilder.buildCity(level, city, "Valdoria");

        d.stage = StoryData.STAGE_TALK_ELDER;
        d.starting = false;
        d.setDirty();

        Vec3 anchor = Vec3.atBottomCenterOf(center);
        for (ServerPlayer p : nearby(level, anchor, 96)) {
            p.teleportTo(center.getX() + 0.5, center.getY(), center.getZ() + 2.5);
            playCinematic(p, Cinematics.INTRO, anchor);
        }
        schedule(Cinematics.duration(Cinematics.INTRO) + 10, server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                title(p, Component.literal("Las Gemas del Destino").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal("Prólogo: El campamento").withStyle(ChatFormatting.GRAY));
                p.sendSystemMessage(Component.literal("» Habla con Eldric (clic derecho) para empezar tu aventura.").withStyle(ChatFormatting.YELLOW));
            }
        });
    }

    public static void spawnCampNpcs(ServerLevel level, StoryData d, boolean includeSilas) {
        BlockPos c = d.campPos;
        for (NpcEntity old : level.getEntitiesOfClass(NpcEntity.class, new AABB(c).inflate(64))) {
            if (old.getRole() == NpcEntity.Role.ANCIANO) continue;
            if (old.getRole() != NpcEntity.Role.SILAS || includeSilas) old.discard();
        }
        spawnNpc(level, ModEntities.ELDRIC.get(), c, CampBuilder.ELDRIC, "Eldric el Sabio", ChatFormatting.GOLD);
        spawnNpc(level, ModEntities.LYRA.get(), c, CampBuilder.LYRA, "Lyra la Exploradora", ChatFormatting.AQUA);
        spawnNpc(level, ModEntities.BRAM.get(), c, CampBuilder.BRAM, "Bram el Herrero", ChatFormatting.RED);
        if (includeSilas) {
            NpcEntity silas = spawnNpc(level, ModEntities.SILAS.get(), c, CampBuilder.SILAS, "Silas el Erudito", ChatFormatting.LIGHT_PURPLE);
            if (silas != null) d.silasId = silas.getUUID();
        }
        d.setDirty();
    }

    private static NpcEntity spawnNpc(ServerLevel level, EntityType<NpcEntity> type, BlockPos center, int[] off,
                                      String name, ChatFormatting color) {
        NpcEntity npc = type.create(level);
        if (npc == null) return null;
        double x = center.getX() + off[0] + 0.5, z = center.getZ() + off[1] + 0.5;
        float yaw = (float) (Math.toDegrees(Math.atan2(-(center.getX() + 0.5 - x), center.getZ() + 0.5 - z)));
        npc.moveTo(x, center.getY(), z, yaw, 0);
        npc.setYHeadRot(yaw);
        npc.setYBodyRot(yaw);
        npc.setCustomName(Component.literal(name).withStyle(color));
        npc.setCustomNameVisible(true);
        level.addFreshEntity(npc);
        return npc;
    }

    // ================================================================== Capítulos
    public static void startChapter(ServerPlayer player, int gi) {
        StoryData d = StoryData.get(player.server);
        ServerLevel level = player.server.overworld();
        GemType g = GemType.byIndex(gi);
        Chapters.Chapter ch = Chapters.get(gi);
        d.currentGem = gi;
        d.stage = StoryData.STAGE_VILLAGE;
        d.questStep = StoryData.Q_MEET;
        d.killCount = 0;

        if (d.villagePos[gi] == null) {
            double angle = gi * 45 + 40;
            BlockPos guess = offset(d.campPos, angle, 450 + gi * 170);
            BlockPos v = TownBuilder.findLand(level, guess, angle);
            d.villagePos[gi] = v;
            TownBuilder.buildVillage(level, v, gi);
        }
        if (gi == 2 && d.cityPos[1] == null) {
            BlockPos v = d.villagePos[2];
            BlockPos mid = new BlockPos((v.getX() + d.campPos.getX()) / 2, 0, (v.getZ() + d.campPos.getZ()) / 2);
            BlockPos city = TownBuilder.findLand(level, mid, 90);
            d.cityPos[1] = city;
            TownBuilder.buildCity(level, city, "la Ciudadela de Aurora");
        }
        d.setDirty();
        give(player, compass(d.villagePos[gi], "Brújula: " + ch.village(), g.color));

        for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
            title(p, Component.literal("Capítulo " + (gi + 1)).withStyle(g.color, ChatFormatting.BOLD),
                    Component.literal(g.gemName).withStyle(ChatFormatting.GRAY));
            p.sendSystemMessage(Component.literal("» Viaja a " + ch.village() + " (sigue la brújula) y habla con " + ch.elder() + ".")
                    .withStyle(ChatFormatting.YELLOW));
        }
    }

    // ================================================================== Conversaciones
    public static void onNpcInteract(ServerPlayer player, NpcEntity npc) {
        StoryData d = StoryData.get(player.server);
        GemType gem = GemType.byIndex(d.currentGem);
        int s = d.stage;
        switch (npc.getRole()) {
            case ELDRIC -> {
                if (s == StoryData.STAGE_TALK_ELDER) ModNetwork.sendDialogue(player, "eldric_intro", Dialogues.eldricIntro());
                else if (s == StoryData.STAGE_VILLAGE || s == StoryData.STAGE_SEEK)
                    ModNetwork.sendDialogue(player, "eldric_seek", Dialogues.eldricSeek(gem, s, d.questStep));
                else if (s == StoryData.STAGE_RETURN) ModNetwork.sendDialogue(player, "eldric_return", Dialogues.eldricReturn(gem, d.gemsDelivered));
                else if (s == StoryData.STAGE_BOSS) ModNetwork.sendDialogue(player, "eldric_boss", Dialogues.eldricBoss());
                else if (s == StoryData.STAGE_END) ModNetwork.sendDialogue(player, "eldric_end", Dialogues.eldricEnd());
            }
            case LYRA -> ModNetwork.sendDialogue(player, "lyra", Dialogues.lyraTalk(s, d.gemsDelivered));
            case BRAM -> ModNetwork.sendDialogue(player, "bram", Dialogues.bramTalk(s, d.gemsDelivered));
            case SILAS -> {
                if (s == StoryData.STAGE_VILLAGE || s == StoryData.STAGE_SEEK)
                    ModNetwork.sendDialogue(player, "silas_compass", Dialogues.silasCompass(gem, s));
                else if (s == StoryData.STAGE_RETURN) {
                    if (count(player, gem.item()) > 0) ModNetwork.sendDialogue(player, "silas_receive", Dialogues.silasReceive(gem));
                    else ModNetwork.sendDialogue(player, "silas_nogem", Dialogues.silasNoGem(gem));
                } else ModNetwork.sendDialogue(player, "silas_idle", Dialogues.silasIdle(s));
            }
            case ANCIANO -> elderInteract(player, npc, d);
        }
    }

    private static void elderInteract(ServerPlayer player, NpcEntity npc, StoryData d) {
        int gi = npc.getVillage();
        if (gi != d.currentGem || d.stage != StoryData.STAGE_VILLAGE) {
            boolean past = gi < d.currentGem || d.stage > StoryData.STAGE_VILLAGE;
            if (gi == d.currentGem && d.stage < StoryData.STAGE_VILLAGE) past = false;
            ModNetwork.sendDialogue(player, "elder_other", Dialogues.elderOther(gi, past));
            return;
        }
        Chapters.Chapter ch = Chapters.get(gi);
        switch (d.questStep) {
            case StoryData.Q_MEET -> ModNetwork.sendDialogue(player, "elder_intro", Dialogues.elderIntro(gi));
            case StoryData.Q_FETCH -> {
                if (hasRequirements(player, ch)) ModNetwork.sendDialogue(player, "elder_fetch_done", Dialogues.elderFetchDone(gi));
                else ModNetwork.sendDialogue(player, "elder_wait", Dialogues.elderFetchWait(gi, progress(player, ch)));
            }
            case StoryData.Q_HUNT -> {
                if (d.killCount >= ch.killCount()) {
                    ModNetwork.sendDialogue(player, "elder_hunt_done", Dialogues.elderHuntDone(gi, towerDirection(d, gi)));
                } else ModNetwork.sendDialogue(player, "elder_wait", Dialogues.elderHuntWait(gi, d.killCount));
            }
            default -> {
                if (count(player, ModItems.FRAGMENTO_MAPA.get()) >= 3) ModNetwork.sendDialogue(player, "elder_map", Dialogues.elderMap(gi));
                else ModNetwork.sendDialogue(player, "elder_wait", Dialogues.elderTowerWait(gi, towerDirection(d, gi)));
            }
        }
    }

    public static void onDialogueFinished(ServerPlayer player, String id) {
        StoryData d = StoryData.get(player.server);
        int gi = d.currentGem;
        Chapters.Chapter ch = Chapters.get(gi);
        boolean inVillage = d.stage == StoryData.STAGE_VILLAGE;
        switch (id) {
            case "eldric_intro" -> {
                if (d.stage == StoryData.STAGE_TALK_ELDER) startChapter(player, 0);
            }
            case "silas_compass" -> {
                if (inVillage && d.villagePos[gi] != null) {
                    give(player, compass(d.villagePos[gi], "Brújula: " + ch.village(), GemType.byIndex(gi).color));
                } else if (d.stage == StoryData.STAGE_SEEK && d.compassPos[gi] != null) {
                    give(player, compass(d.compassPos[gi], "Brújula imprecisa", ChatFormatting.DARK_PURPLE));
                }
            }
            case "eldric_boss" -> {
                if (d.stage == StoryData.STAGE_BOSS && d.castlePos != null)
                    give(player, compass(d.castlePos, "Brújula: Fortaleza del Eclipse", ChatFormatting.DARK_PURPLE));
            }
            case "silas_receive" -> {
                if (d.stage == StoryData.STAGE_RETURN) deliverGem(player);
            }
            case "elder_intro" -> {
                if (inVillage && d.questStep == StoryData.Q_MEET) {
                    d.questStep = StoryData.Q_FETCH;
                    d.setDirty();
                    player.sendSystemMessage(Component.literal("» Misión: consigue los materiales que pide " + ch.elder() + ".").withStyle(ChatFormatting.YELLOW));
                }
            }
            case "elder_fetch_done" -> {
                if (inVillage && d.questStep == StoryData.Q_FETCH && hasRequirements(player, ch)) {
                    for (Chapters.Req r : ch.fetch()) remove(player, r.item(), r.count());
                    give(player, new ItemStack(ModItems.FRAGMENTO_MAPA.get()));
                    d.questStep = StoryData.Q_HUNT;
                    d.killCount = 0;
                    d.setDirty();
                    fragmentSound(player);
                    player.sendSystemMessage(Component.literal("» Fragmento 1/3 conseguido. Misión: elimina " + ch.killCount() + " " + ch.killName() + ".")
                            .withStyle(ChatFormatting.YELLOW));
                }
            }
            case "elder_hunt_done" -> {
                if (inVillage && d.questStep == StoryData.Q_HUNT && d.killCount >= ch.killCount()) {
                    give(player, new ItemStack(ModItems.FRAGMENTO_MAPA.get()));
                    d.questStep = StoryData.Q_TOWER;
                    d.setDirty();
                    fragmentSound(player);
                    buildTowerFor(player.server.overworld(), d, gi);
                    player.sendSystemMessage(Component.literal("» Fragmento 2/3 conseguido. Misión: encuentra la torre de vigía " + towerDirection(d, gi) + ".")
                            .withStyle(ChatFormatting.YELLOW));
                }
            }
            case "elder_map" -> {
                if (inVillage && d.questStep == StoryData.Q_TOWER && count(player, ModItems.FRAGMENTO_MAPA.get()) >= 3) {
                    remove(player, ModItems.FRAGMENTO_MAPA.get(), 3);
                    startDungeon(player, d, gi);
                }
            }
            default -> {
            }
        }
    }

    // ================================================================== Misiones del pueblo
    private static boolean hasRequirements(ServerPlayer p, Chapters.Chapter ch) {
        for (Chapters.Req r : ch.fetch()) if (count(p, r.item()) < r.count()) return false;
        return true;
    }

    private static String progress(ServerPlayer p, Chapters.Chapter ch) {
        StringBuilder sb = new StringBuilder();
        for (Chapters.Req r : ch.fetch()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(Math.min(count(p, r.item()), r.count())).append("/").append(r.count()).append(" ").append(r.name());
        }
        return sb.toString();
    }

    /** Llamado cuando un jugador mata a cualquier criatura: cuenta para la misión de caza. */
    public static void onMobKilled(ServerPlayer killer, LivingEntity dead) {
        StoryData d = StoryData.get(killer.server);
        if (d.stage != StoryData.STAGE_VILLAGE || d.questStep != StoryData.Q_HUNT) return;
        Chapters.Chapter ch = Chapters.get(d.currentGem);
        if (dead.getType() != ch.killType() || d.killCount >= ch.killCount()) return;
        d.killCount++;
        d.setDirty();
        killer.displayClientMessage(Component.literal(ch.killName() + ": " + d.killCount + "/" + ch.killCount()).withStyle(ChatFormatting.GOLD), true);
        if (d.killCount >= ch.killCount()) {
            for (ServerPlayer p : killer.server.getPlayerList().getPlayers()) {
                p.sendSystemMessage(Component.literal("» ¡Caza completada! Vuelve con " + ch.elder() + " en " + ch.village() + ".")
                        .withStyle(ChatFormatting.YELLOW));
            }
            killer.serverLevel().playSound(null, killer.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
    }

    private static void buildTowerFor(ServerLevel level, StoryData d, int gi) {
        if (d.towerPos[gi] != null) return;
        RandomSource r = RandomSource.create(d.villagePos[gi].asLong() + 17);
        double angle = r.nextInt(360);
        BlockPos t = TownBuilder.findLand(level, offset(d.villagePos[gi], angle, 150 + r.nextInt(60)), angle);
        d.towerPos[gi] = t;
        d.setDirty();
        schedule(2, s -> TownBuilder.buildTower(level, t));
    }

    private static String towerDirection(StoryData d, int gi) {
        BlockPos v = d.villagePos[gi], t = d.towerPos[gi];
        if (v == null) return "cerca del pueblo";
        if (t == null) {
            RandomSource r = RandomSource.create(v.asLong() + 17);
            double angle = r.nextInt(360);
            int dist = 150 + r.nextInt(60);
            t = offset(v, angle, dist);
        }
        int dx = t.getX() - v.getX(), dz = t.getZ() - v.getZ();
        int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz) / 10.0) * 10;
        return "al " + directionName(dx, dz) + " del pueblo, a unos " + dist + " bloques";
    }

    // ================================================================== Mazmorra
    private static void startDungeon(ServerPlayer player, StoryData d, int gi) {
        ServerLevel level = player.server.overworld();
        GemType g = GemType.byIndex(gi);
        if (d.basePos[gi] == null) {
            RandomSource r = RandomSource.create(d.villagePos[gi].asLong() + 99);
            double angle = r.nextInt(360);
            BlockPos guess = offset(d.villagePos[gi], angle, 260 + gi * 50 + r.nextInt(80));
            BlockPos surface = TownBuilder.findLand(level, guess, angle);
            DungeonBuilder.Result res = DungeonBuilder.generate(level, surface, g);
            d.basePos[gi] = res.surface();
            d.baseRoom[gi] = res.entranceRoom();
            double ca = r.nextInt(360);
            d.compassPos[gi] = offset(res.surface(), ca, 40 + r.nextInt(35));
        }
        d.stage = StoryData.STAGE_SEEK;
        d.setDirty();
        if (count(player, ModItems.MAPA_ECLIPSE.get()) == 0) give(player, new ItemStack(ModItems.MAPA_ECLIPSE.get()));
        give(player, compass(d.compassPos[gi], "Brújula imprecisa", ChatFormatting.DARK_PURPLE));
        level.playSound(null, player.blockPosition(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0F, 0.8F);
        for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
            title(p, Component.literal("El Mapa del Eclipse").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD),
                    Component.literal("Busca el " + g.baseName).withStyle(ChatFormatting.GRAY));
            p.sendSystemMessage(Component.literal("» La brújula te lleva a la zona. Usa el Mapa del Eclipse (clic derecho) para saber si estás cerca.")
                    .withStyle(ChatFormatting.YELLOW));
        }
    }

    /** Mapa del Eclipse: frío o caliente según la distancia a la entrada oculta. */
    public static void readEclipseMap(ServerPlayer player) {
        StoryData d = StoryData.get(player.server);
        BlockPos target = null;
        if (d.stage == StoryData.STAGE_SEEK) target = d.basePos[d.currentGem];
        else if (d.stage == StoryData.STAGE_END) {
            double best = Double.MAX_VALUE;
            for (int i = 0; i < StoryData.N; i++) {
                if (d.scatterPos[i] == null || d.scatterFound[i]) continue;
                double dist = horizontal(player, d.scatterPos[i]);
                if (dist < best) { best = dist; target = d.scatterPos[i]; }
            }
        }
        if (target == null) {
            player.displayClientMessage(Component.literal("El mapa está en blanco... ahora mismo no siente ninguna gema.").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (player.level().dimension() != Level.OVERWORLD) {
            player.displayClientMessage(Component.literal("El mapa no funciona en esta dimensión.").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        BlockPos b = target;
        double dx = player.getX() - b.getX(), dz = player.getZ() - b.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        String msg;
        ChatFormatting color;
        float pitch;
        if (dist > 400) { msg = "❄ Helado... la gema está muy, muy lejos."; color = ChatFormatting.AQUA; pitch = 0.5F; }
        else if (dist > 250) { msg = "❄ Frío."; color = ChatFormatting.AQUA; pitch = 0.6F; }
        else if (dist > 150) { msg = "~ Templado."; color = ChatFormatting.WHITE; pitch = 0.8F; }
        else if (dist > 80) { msg = "♨ Caliente."; color = ChatFormatting.GOLD; pitch = 1.0F; }
        else if (dist > 35) { msg = "♨ ¡Muy caliente!"; color = ChatFormatting.RED; pitch = 1.3F; }
        else if (dist > 8) { msg = "🔥 ¡Ardiendo! Está muy cerca."; color = ChatFormatting.DARK_RED; pitch = 1.6F; }
        else { msg = "🔥 ¡Aquí mismo! Busca bajo tus pies..."; color = ChatFormatting.LIGHT_PURPLE; pitch = 2.0F; }
        player.displayClientMessage(Component.literal(msg).withStyle(color, ChatFormatting.BOLD), true);
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, pitch);
    }

    /** El guardián se despierta: cinemática corta. Devuelve los ticks que debe quedarse quieto. */
    public static int onGuardianAwake(GuardianBossEntity boss) {
        if (!(boss.level() instanceof ServerLevel level)) return 0;
        String cin = Cinematics.guardian(boss.getGem().ordinal());
        Vec3 anchor = boss.position();
        for (ServerPlayer p : nearby(level, anchor, 20)) playCinematic(p, cin, anchor);
        return Cinematics.duration(cin) + 10;
    }

    public static void onPedestalUse(ServerPlayer player, BlockPos pos, BlockState state) {
        int gemIndex = state.getValue(PedestalBlock.GEM) - 1;
        if (gemIndex < 0) {
            player.displayClientMessage(Component.literal("El pedestal está vacío.").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        StoryData d = StoryData.get(player.server);
        if (d.stage != StoryData.STAGE_SEEK || d.currentGem != gemIndex) {
            player.displayClientMessage(Component.literal("Un sello antiguo protege esta gema. Aún no es su momento.").withStyle(ChatFormatting.DARK_PURPLE), true);
            return;
        }
        GemType g = GemType.byIndex(gemIndex);
        ServerLevel level = player.serverLevel();
        level.setBlock(pos, state.setValue(PedestalBlock.GEM, 0), 3);
        give(player, new ItemStack(g.item()));
        d.stage = StoryData.STAGE_RETURN;
        d.setDirty();
        level.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.2F);

        String cin = Cinematics.gemFound(gemIndex);
        Vec3 anchor = Vec3.atBottomCenterOf(pos);
        for (ServerPlayer p : nearby(level, anchor, 32)) playCinematic(p, cin, anchor);

        schedule(Cinematics.duration(cin) + 5, server -> {
            spawnGuardians(level, pos, g);
            for (ServerPlayer p : nearby(level, anchor, 64)) {
                title(p, Component.literal("¡" + g.gemName + " obtenida!").withStyle(g.color, ChatFormatting.BOLD),
                        Component.literal("¡Cuidado! Los guardianes despiertan").withStyle(ChatFormatting.RED));
            }
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                p.sendSystemMessage(Component.literal("» Vuelve al campamento y entrégale la gema a Silas.").withStyle(ChatFormatting.YELLOW));
            }
        });
    }

    private static void spawnGuardians(ServerLevel level, BlockPos pedestal, GemType g) {
        for (int i = 0; i < g.guardianCount; i++) {
            Entity e = g.guardian.create(level);
            if (!(e instanceof Mob mob)) continue;
            double a = (Math.PI * 2 / g.guardianCount) * i;
            mob.moveTo(pedestal.getX() + 0.5 + Math.cos(a) * 3, pedestal.getY(), pedestal.getZ() + 0.5 + Math.sin(a) * 3, 0, 0);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pedestal), MobSpawnType.EVENT, null, null);
            mob.setCustomName(Component.literal("Guardián de la Orden").withStyle(ChatFormatting.DARK_PURPLE));
            mob.setPersistenceRequired();
            level.addFreshEntity(mob);
            level.sendParticles(ParticleTypes.LARGE_SMOKE, mob.getX(), mob.getY() + 1, mob.getZ(), 20, 0.3, 0.5, 0.3, 0.02);
        }
    }

    // ================================================================== Entregar gemas al "aliado"
    private static void deliverGem(ServerPlayer player) {
        StoryData d = StoryData.get(player.server);
        GemType g = GemType.byIndex(d.currentGem);
        if (!remove(player, g.item(), 1)) {
            player.sendSystemMessage(Component.literal("No llevas la " + g.gemName + ".").withStyle(ChatFormatting.RED));
            return;
        }
        d.gemsDelivered++;
        d.setDirty();
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.0F, 0.6F);
        player.sendSystemMessage(Component.literal("Gemas entregadas a Silas: " + d.gemsDelivered + "/" + StoryData.N).withStyle(ChatFormatting.LIGHT_PURPLE));
        if (d.gemsDelivered < StoryData.N) startChapter(player, d.currentGem + 1);
        else betrayal(player);
    }

    // ================================================================== La traición
    private static void betrayal(ServerPlayer player) {
        StoryData d = StoryData.get(player.server);
        ServerLevel level = player.server.overworld();
        d.stage = StoryData.STAGE_BOSS;
        d.castlePhase = StoryData.C_DEFENSES;
        d.crystalsLeft = 4;
        d.setDirty();

        Entity silas = d.silasId != null ? level.getEntity(d.silasId) : null;
        BlockPos silasPos = silas != null ? silas.blockPosition()
                : d.campPos.offset(CampBuilder.SILAS[0], 0, CampBuilder.SILAS[1]);
        Vec3 anchor = Vec3.atBottomCenterOf(silasPos);

        int dur = Cinematics.duration(Cinematics.BETRAYAL);
        for (ServerPlayer p : nearby(level, anchor, 64)) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur + 40, 4, false, false));
            playCinematic(p, Cinematics.BETRAYAL, anchor);
        }
        schedule(200, s -> level.sendParticles(ParticleTypes.REVERSE_PORTAL, anchor.x, anchor.y + 1, anchor.z, 200, 0.5, 1.0, 0.5, 0.2));
        schedule(dur - 30, s -> {
            // Silas desaparece en un remolino de portal
            Entity old = d.silasId != null ? level.getEntity(d.silasId) : null;
            if (old != null) old.discard();
            level.sendParticles(ParticleTypes.PORTAL, anchor.x, anchor.y + 1, anchor.z, 400, 0.6, 1.2, 0.6, 1.0);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, anchor.x, anchor.y + 1, anchor.z, 1, 0, 0, 0, 0);
            level.playSound(null, silasPos, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 2.0F, 0.5F);
            for (int i = 0; i < 3; i++) {
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                if (bolt != null) {
                    bolt.moveTo(anchor.add(i * 3 - 3, 0, 4));
                    bolt.setVisualOnly(true);
                    level.addFreshEntity(bolt);
                }
            }
        });
        schedule(dur + 10, s -> {
            if (d.castlePos == null) {
                BlockPos guess = offset(d.campPos, 315, 750);
                BlockPos castle = TownBuilder.findLand(level, guess, 315);
                d.castlePos = castle;
                d.setDirty();
                CastleBuilder.build(level, castle);
            }
            for (ServerPlayer p : s.getPlayerList().getPlayers()) {
                title(p, Component.literal("Capítulo Final").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD),
                        Component.literal("La Fortaleza del Eclipse").withStyle(ChatFormatting.LIGHT_PURPLE));
                p.sendSystemMessage(Component.literal("» ¡Silas era el traidor y ha huido con las ocho gemas a su fortaleza!")
                        .withStyle(ChatFormatting.RED));
                p.sendSystemMessage(Component.literal("» Prepárate bien: equípate en la ciudad, y luego sigue la brújula de la Fortaleza.")
                        .withStyle(ChatFormatting.YELLOW));
                give(p, compass(d.castlePos, "Brújula: Fortaleza del Eclipse", ChatFormatting.DARK_PURPLE));
            }
        });
    }

    // ================================================================== La Fortaleza del Eclipse
    public static void onCrystalDestroyed(ServerLevel level, BlockPos pos) {
        StoryData d = StoryData.get(level.getServer());
        if (d.stage != StoryData.STAGE_BOSS || d.castlePhase != StoryData.C_DEFENSES) return;
        d.crystalsLeft = Math.max(0, d.crystalsLeft - 1);
        d.setDirty();
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1, 0, 0, 0, 0);
        level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 2.0F, 0.5F);
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
            p.sendSystemMessage(Component.literal("» Cristal de defensa destruido. Quedan " + d.crystalsLeft + ".").withStyle(ChatFormatting.LIGHT_PURPLE));
        }
        if (d.crystalsLeft == 0 && d.castlePos != null) {
            d.castlePhase = StoryData.C_GATE_OPEN;
            d.setDirty();
            BlockPos gate = d.castlePos.offset(0, 2, 22);
            com.gemasdeldestino.block.DungeonUtil.breakBlocks(level, gate, 3, 3, 4, com.gemasdeldestino.registry.ModBlocks.SELLO.get());
            level.playSound(null, gate, SoundEvents.WITHER_BREAK_BLOCK, SoundSource.BLOCKS, 2.0F, 0.6F);
            for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
                title(p, Component.literal("¡La puerta se abre!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal("Entra en el Salón del Trono").withStyle(ChatFormatting.GRAY));
            }
        }
    }

    private static void startArena(ServerLevel level, StoryData d) {
        d.castlePhase = StoryData.C_GUARDIANS;
        d.setDirty();
        BlockPos c = d.castlePos;
        Vec3 anchor = Vec3.atBottomCenterOf(c);
        int dur = Cinematics.duration(Cinematics.THRONE);
        for (ServerPlayer p : nearby(level, anchor, 40)) playCinematic(p, Cinematics.THRONE, anchor);
        schedule(dur + 5, s -> {
            GemType[] all = GemType.values();
            for (int i = 0; i < all.length; i++) {
                GuardianBossEntity g = ModEntities.GUARDIAN.get().create(level);
                if (g == null) continue;
                double a = Math.PI * 2 * i / all.length;
                g.moveTo(c.getX() + 0.5 + Math.cos(a) * 7, c.getY(), c.getZ() + 0.5 + Math.sin(a) * 7, 0, 0);
                g.setupArena(all[i]);
                level.addFreshEntity(g);
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, g.getX(), g.getY() + 1, g.getZ(), 40, 0.4, 1.0, 0.4, 0.05);
            }
            level.playSound(null, c, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 2.0F, 0.8F);
            for (ServerPlayer p : nearby(level, anchor, 60)) {
                title(p, Component.literal("Los Ocho Guardianes").withStyle(ChatFormatting.RED, ChatFormatting.BOLD),
                        Component.literal("Han vuelto de entre los muertos").withStyle(ChatFormatting.GRAY));
            }
        });
    }

    public static void onArenaGuardianDied(GuardianBossEntity dead) {
        if (!(dead.level() instanceof ServerLevel level)) return;
        StoryData d = StoryData.get(level.getServer());
        if (d.stage != StoryData.STAGE_BOSS || d.castlePhase != StoryData.C_GUARDIANS || d.castlePos == null) return;
        int alive = level.getEntitiesOfClass(GuardianBossEntity.class, new AABB(d.castlePos).inflate(40),
                g -> g != dead && g.isAlive() && g.isArena()).size();
        for (ServerPlayer p : nearby(level, dead.position(), 60)) {
            p.displayClientMessage(Component.literal(dead.getGem().bossName() + " ha caído. Quedan " + alive + " guardianes.")
                    .withStyle(ChatFormatting.GOLD), true);
        }
        if (alive > 0) return;
        d.castlePhase = StoryData.C_FUSION;
        d.setDirty();
        BlockPos c = d.castlePos;
        Vec3 anchor = Vec3.atBottomCenterOf(c);
        schedule(60, s -> {
            NpcEntity ghost = ModEntities.SILAS.get().create(level);
            if (ghost != null) {
                BlockPos t = CastleBuilder.throne(c);
                ghost.moveTo(t.getX() + 0.5, t.getY(), t.getZ() + 0.5, 0, 0);
                ghost.setCustomName(Component.literal("Silas").withStyle(ChatFormatting.DARK_PURPLE));
                ghost.addTag("gemas_aparicion");
                level.addFreshEntity(ghost);
            }
            for (ServerPlayer p : nearby(level, anchor, 60)) playCinematic(p, Cinematics.FUSION, anchor);
        });
        schedule(60 + Cinematics.duration(Cinematics.FUSION), s -> {
            removeGhosts(level, c);
            FusionBossEntity boss = ModEntities.QUIMERA.get().create(level);
            if (boss != null) {
                boss.moveTo(anchor.x, anchor.y, anchor.z, 180, 0);
                level.addFreshEntity(boss);
            }
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, anchor.x, anchor.y + 2, anchor.z, 3, 1, 1, 1, 0);
            level.playSound(null, c, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 2.0F, 0.6F);
            for (ServerPlayer p : nearby(level, anchor, 60)) {
                title(p, Component.literal("La Quimera del Eclipse").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD),
                        Component.literal("Ocho guardianes. Un solo cuerpo.").withStyle(ChatFormatting.GRAY));
            }
        });
    }

    private static void removeGhosts(ServerLevel level, BlockPos c) {
        for (NpcEntity n : level.getEntitiesOfClass(NpcEntity.class, new AABB(c).inflate(30), n -> n.getTags().contains("gemas_aparicion"))) n.discard();
    }

    public static void onFusionDefeated(FusionBossEntity boss) {
        if (!(boss.level() instanceof ServerLevel level)) return;
        StoryData d = StoryData.get(level.getServer());
        if (d.castlePos == null) return;
        d.castlePhase = StoryData.C_SILAS;
        d.setDirty();
        BlockPos c = d.castlePos;
        Vec3 anchor = Vec3.atBottomCenterOf(c);
        BlockPos t = CastleBuilder.throne(c);
        schedule(40, s -> {
            NpcEntity ghost = ModEntities.SILAS.get().create(level);
            if (ghost != null) {
                ghost.moveTo(t.getX() + 0.5, t.getY(), t.getZ() + 0.5, 0, 0);
                ghost.setCustomName(Component.literal("Silas").withStyle(ChatFormatting.DARK_PURPLE));
                ghost.addTag("gemas_aparicion");
                level.addFreshEntity(ghost);
            }
            for (ServerPlayer p : nearby(level, anchor, 60)) playCinematic(p, Cinematics.SILAS_FINAL, anchor);
        });
        schedule(40 + Cinematics.duration(Cinematics.SILAS_FINAL), s -> {
            removeGhosts(level, c);
            SilasBossEntity silas = ModEntities.SILAS_JEFE.get().create(level);
            if (silas != null) {
                silas.moveTo(t.getX() + 0.5, t.getY(), t.getZ() + 0.5, 0, 0);
                level.addFreshEntity(silas);
            }
            level.playSound(null, t, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 2.0F, 1.0F);
            for (ServerPlayer p : nearby(level, anchor, 60)) {
                title(p, Component.literal("Silas, Señor del Eclipse").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD),
                        Component.literal("El combate final").withStyle(ChatFormatting.GRAY));
            }
        });
    }

    public static void onBossDefeated(SilasBossEntity boss) {
        if (!(boss.level() instanceof ServerLevel level)) return;
        StoryData d = StoryData.get(level.getServer());
        d.stage = StoryData.STAGE_END;
        d.setDirty();
        boss.spawnAtLocation(new ItemStack(Items.NETHERITE_INGOT, 4));
        boss.spawnAtLocation(new ItemStack(Items.TOTEM_OF_UNDYING, 2));
        boss.spawnAtLocation(new ItemStack(Items.EMERALD, 64));

        BlockPos c = d.castlePos != null ? d.castlePos : boss.blockPosition();
        Vec3 anchor = Vec3.atBottomCenterOf(c);
        schedule(50, s -> {
            for (ServerPlayer p : nearby(level, anchor, 80)) playCinematic(p, Cinematics.ENDING, anchor);
        });
        // Las gemas salen disparadas hacia el cielo
        for (int i = 0; i < StoryData.N; i++) {
            final int gi = i;
            schedule(160 + i * 6, s -> {
                level.sendParticles(ParticleTypes.END_ROD, anchor.x, anchor.y + 3, anchor.z, 60, 0.2, 8.0, 0.2, 0.3);
                level.playSound(null, c, SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.AMBIENT, 2.0F, 0.6F + gi * 0.1F);
            });
        }
        // Se esconden en cráteres por todo el mundo (epílogo)
        schedule(260, s -> scatterGems(level, d, c));
        schedule(50 + Cinematics.duration(Cinematics.ENDING) + 10, s -> {
            for (ServerPlayer p : s.getPlayerList().getPlayers()) {
                title(p, Component.literal("FIN").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal("Gracias por jugar a Las Gemas del Destino").withStyle(ChatFormatting.GRAY));
                p.sendSystemMessage(Component.literal("» Epílogo: las ocho gemas han caído en cráteres por todo el mundo. "
                        + "Usa el Mapa del Eclipse para encontrarlas de nuevo.").withStyle(ChatFormatting.LIGHT_PURPLE));
                if (count(p, ModItems.MAPA_ECLIPSE.get()) == 0) give(p, new ItemStack(ModItems.MAPA_ECLIPSE.get()));
            }
        });
    }

    private static void scatterGems(ServerLevel level, StoryData d, BlockPos from) {
        RandomSource r = RandomSource.create(from.asLong() ^ 0xD15L);
        for (int i = 0; i < StoryData.N; i++) {
            if (d.scatterPos[i] != null) continue;
            double angle = i * 45 + r.nextInt(30);
            BlockPos guess = offset(from, angle, 350 + r.nextInt(900));
            BlockPos top = TownBuilder.findLand(level, guess, angle);
            d.scatterPos[i] = top;
            final GemType g = GemType.byIndex(i);
            schedule(5 + i * 3, s -> crater(level, top, g));
        }
        d.setDirty();
    }

    /** Pequeño cráter con la gema escondida en un cofre en el fondo. */
    private static void crater(ServerLevel level, BlockPos top, GemType g) {
        com.gemasdeldestino.world.Builder b = new com.gemasdeldestino.world.Builder(level, top);
        for (int x = -4; x <= 4; x++)
            for (int y = -4; y <= 3; y++)
                for (int z = -4; z <= 4; z++) {
                    double dist = Math.sqrt(x * x + (y + 1) * (y + 1) * 1.6 + z * z);
                    if (dist < 4.0) b.set(x, y, z, net.minecraft.world.level.block.Blocks.AIR);
                    else if (dist < 5.0 && y < 0) b.set(x, y, z, level.random.nextInt(3) == 0
                            ? net.minecraft.world.level.block.Blocks.MAGMA_BLOCK : net.minecraft.world.level.block.Blocks.CRYING_OBSIDIAN);
                }
        b.set(0, -4, 0, net.minecraft.world.level.block.Blocks.CHEST);
        if (level.getBlockEntity(b.at(0, -4, 0)) instanceof net.minecraft.world.level.block.entity.ChestBlockEntity ch) {
            ch.setItem(13, new ItemStack(g.item()));
        }
        b.set(1, -3, 1, net.minecraft.world.level.block.Blocks.AMETHYST_CLUSTER);
        b.set(-1, -3, -1, net.minecraft.world.level.block.Blocks.AMETHYST_CLUSTER);
    }

    // ================================================================== Llegadas y pistas
    public static void onPlayerTick(ServerPlayer player) {
        if (player.tickCount % 20 != 0 || player.level().dimension() != Level.OVERWORLD) return;
        StoryData d = StoryData.get(player.server);
        if (d.stage == StoryData.STAGE_NONE) return;
        int gi = d.currentGem;

        for (int i = 0; i < 2; i++) {
            if (d.cityPos[i] != null && !d.citySeen[i] && horizontal(player, d.cityPos[i]) < 45) {
                d.citySeen[i] = true;
                d.setDirty();
                String name = i == 0 ? "Valdoria" : "Ciudadela de Aurora";
                title(player, Component.literal(name).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal("Ciudad comercial").withStyle(ChatFormatting.GRAY));
                player.sendSystemMessage(Component.literal("» Los comerciantes cambian esmeraldas por armas, armaduras, pociones y libros encantados.")
                        .withStyle(ChatFormatting.GREEN));
            }
        }
        if (d.stage == StoryData.STAGE_BOSS && d.castlePos != null) {
            if (!d.castleSeen && horizontal(player, d.castlePos) < 90) {
                d.castleSeen = true;
                d.setDirty();
                Vec3 anchor = Vec3.atBottomCenterOf(d.castlePos);
                for (ServerPlayer p : nearby(player.serverLevel(), anchor, 120)) playCinematic(p, Cinematics.FORTRESS, anchor);
            }
            if (d.castlePhase == StoryData.C_GATE_OPEN && CastleBuilder.inHall(d.castlePos, player.blockPosition())) {
                startArena(player.serverLevel(), d);
            }
        }
        if (d.stage == StoryData.STAGE_END) {
            for (int i = 0; i < StoryData.N; i++) {
                if (d.scatterPos[i] != null && !d.scatterFound[i] && horizontal(player, d.scatterPos[i]) < 4) {
                    d.scatterFound[i] = true;
                    d.setDirty();
                    player.sendSystemMessage(Component.literal("» Has encontrado el cráter de la " + GemType.byIndex(i).gemName + ".")
                            .withStyle(ChatFormatting.LIGHT_PURPLE));
                }
            }
        }
        if (d.stage == StoryData.STAGE_VILLAGE && d.villagePos[gi] != null && !d.villageSeen[gi]
                && horizontal(player, d.villagePos[gi]) < 40) {
            d.villageSeen[gi] = true;
            d.setDirty();
            Vec3 anchor = Vec3.atBottomCenterOf(d.villagePos[gi]);
            for (ServerPlayer p : nearby(player.serverLevel(), anchor, 60)) playCinematic(p, Cinematics.village(gi), anchor);
        }
        if (d.stage == StoryData.STAGE_SEEK) {
            BlockPos base = d.basePos[gi];
            if (base != null && !d.hintShown[gi] && horizontal(player, base) < 10 && Math.abs(player.getY() - base.getY()) < 8) {
                d.hintShown[gi] = true;
                d.setDirty();
                player.sendSystemMessage(Component.literal("Sientes una energía extraña bajo tus pies... ¿qué esconde el suelo?")
                        .withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC));
                player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.AMBIENT, 1.0F, 0.6F);
            }
            BlockPos room = d.baseRoom[gi];
            if (room != null && !d.dungeonSeen[gi] && player.blockPosition().closerThan(room, 6)) {
                d.dungeonSeen[gi] = true;
                d.setDirty();
                Vec3 anchor = Vec3.atBottomCenterOf(room);
                for (ServerPlayer p : nearby(player.serverLevel(), anchor, 20)) playCinematic(p, Cinematics.dungeon(gi), anchor);
                schedule(Cinematics.duration(Cinematics.dungeon(gi)) + 5, s -> {
                    for (ServerPlayer p : nearby(player.serverLevel(), anchor, 30)) {
                        title(p, Component.literal(GemType.byIndex(gi).baseName).withStyle(GemType.byIndex(gi).color, ChatFormatting.BOLD),
                                Component.literal("Resuelve los enigmas y derrota al guardián").withStyle(ChatFormatting.GRAY));
                    }
                });
            }
        }
    }

    // ================================================================== Utilidades
    public static void playCinematic(ServerPlayer p, String id, Vec3 anchor) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, Cinematics.duration(id) + 20, 4, false, false));
        ModNetwork.sendCinematic(p, id, anchor);
    }

    private static List<ServerPlayer> nearby(ServerLevel level, Vec3 pos, double radius) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : level.players()) if (p.position().distanceTo(pos) <= radius) out.add(p);
        return out;
    }

    private static double horizontal(ServerPlayer p, BlockPos pos) {
        double dx = p.getX() - (pos.getX() + 0.5), dz = p.getZ() - (pos.getZ() + 0.5);
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static BlockPos offset(BlockPos from, double angleDeg, double dist) {
        double a = Math.toRadians(angleDeg);
        return new BlockPos(from.getX() + (int) (Math.cos(a) * dist), from.getY(), from.getZ() + (int) (Math.sin(a) * dist));
    }

    /** Dirección en palabras (norte = -Z, este = +X). */
    public static String directionName(double dx, double dz) {
        double deg = Math.toDegrees(Math.atan2(dx, -dz));
        if (deg < 0) deg += 360;
        String[] names = {"norte", "noreste", "este", "sureste", "sur", "suroeste", "oeste", "noroeste"};
        return names[(int) Math.round(deg / 45.0) % 8];
    }

    public static ItemStack compass(BlockPos target, String name, ChatFormatting color) {
        ItemStack compass = new ItemStack(Items.COMPASS);
        var tag = compass.getOrCreateTag();
        tag.put("LodestonePos", NbtUtils.writeBlockPos(target));
        Level.RESOURCE_KEY_CODEC.encodeStart(NbtOps.INSTANCE, Level.OVERWORLD).result()
                .ifPresent(n -> tag.put("LodestoneDimension", n));
        tag.putBoolean("LodestoneTracked", false);
        compass.setHoverName(Component.literal(name).withStyle(color));
        return compass;
    }

    public static void title(ServerPlayer p, Component title, Component subtitle) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
        p.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    public static void give(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }

    public static int count(ServerPlayer player, Item item) {
        Inventory inv = player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) if (inv.getItem(i).is(item)) n += inv.getItem(i).getCount();
        return n;
    }

    public static boolean remove(ServerPlayer player, Item item, int amount) {
        if (count(player, item) < amount) return false;
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize() && amount > 0; i++) {
            ItemStack st = inv.getItem(i);
            if (st.is(item)) {
                int take = Math.min(amount, st.getCount());
                st.shrink(take);
                amount -= take;
            }
        }
        return true;
    }

    private static void fragmentSound(ServerPlayer player) {
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6F, 1.4F);
    }

    private StoryManager() {}
}
