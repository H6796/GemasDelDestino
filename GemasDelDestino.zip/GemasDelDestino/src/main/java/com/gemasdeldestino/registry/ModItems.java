package com.gemasdeldestino.registry;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.item.EclipseMapItem;
import com.gemasdeldestino.item.GemItem;
import com.gemasdeldestino.item.LoreItem;
import com.gemasdeldestino.item.GemType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, GemasMod.MODID);

    public static final RegistryObject<Item> GEMA_FUEGO = gem("gema_fuego", GemType.FUEGO);
    public static final RegistryObject<Item> GEMA_TORMENTA = gem("gema_tormenta", GemType.TORMENTA);
    public static final RegistryObject<Item> GEMA_VIENTO = gem("gema_viento", GemType.VIENTO);
    public static final RegistryObject<Item> GEMA_TIERRA = gem("gema_tierra", GemType.TIERRA);
    public static final RegistryObject<Item> GEMA_HIELO = gem("gema_hielo", GemType.HIELO);
    public static final RegistryObject<Item> GEMA_LUZ = gem("gema_luz", GemType.LUZ);
    public static final RegistryObject<Item> GEMA_TIEMPO = gem("gema_tiempo", GemType.TIEMPO);
    public static final RegistryObject<Item> GEMA_VACIO = gem("gema_vacio", GemType.VACIO);

    public static final RegistryObject<Item> FRAGMENTO_MAPA = ITEMS.register("fragmento_mapa", () -> new LoreItem(
            new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON),
            "Un trozo de un mapa antiguo de los guardianes.", "Reúne 3 y llévaselos al anciano del pueblo."));
    public static final RegistryObject<Item> MAPA_ECLIPSE = ITEMS.register("mapa_eclipse", () -> new EclipseMapItem(
            new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> LLAVE_SELLO = ITEMS.register("llave_sello", () -> new LoreItem(
            new Item.Properties().stacksTo(16).rarity(Rarity.RARE),
            "La suelta el guardián de cada mazmorra.", "Abre la cerradura de la cámara de la gema."));

    private static RegistryObject<Item> gem(String name, GemType type) {
        return ITEMS.register(name, () -> new GemItem(type,
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    }

    private ModItems() {}
}
