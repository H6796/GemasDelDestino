package com.gemasdeldestino.registry;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.entity.NpcEntity;
import com.gemasdeldestino.entity.FusionBossEntity;
import com.gemasdeldestino.entity.GuardianBossEntity;
import com.gemasdeldestino.entity.SilasBossEntity;
import com.gemasdeldestino.entity.TraderEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = GemasMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GemasMod.MODID);

    public static final RegistryObject<EntityType<NpcEntity>> ELDRIC = npc("eldric");
    public static final RegistryObject<EntityType<NpcEntity>> LYRA = npc("lyra");
    public static final RegistryObject<EntityType<NpcEntity>> BRAM = npc("bram");
    public static final RegistryObject<EntityType<NpcEntity>> SILAS = npc("silas");
    public static final RegistryObject<EntityType<NpcEntity>> ANCIANO = npc("anciano");

    public static final RegistryObject<EntityType<TraderEntity>> COMERCIANTE = ENTITIES.register("comerciante",
            () -> EntityType.Builder.<TraderEntity>of(TraderEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("comerciante"));

    public static final RegistryObject<EntityType<GuardianBossEntity>> GUARDIAN = ENTITIES.register("guardian",
            () -> EntityType.Builder.<GuardianBossEntity>of(GuardianBossEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.4F).fireImmune().clientTrackingRange(10).build("guardian"));

    public static final RegistryObject<EntityType<SilasBossEntity>> SILAS_JEFE = ENTITIES.register("silas_jefe",
            () -> EntityType.Builder.<SilasBossEntity>of(SilasBossEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.5F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .build("silas_jefe"));

    public static final RegistryObject<EntityType<FusionBossEntity>> QUIMERA = ENTITIES.register("quimera",
            () -> EntityType.Builder.<FusionBossEntity>of(FusionBossEntity::new, MobCategory.MONSTER)
                    .sized(1.4F, 4.2F).fireImmune().clientTrackingRange(16).build("quimera"));

    private static RegistryObject<EntityType<NpcEntity>> npc(String name) {
        return ENTITIES.register(name, () -> EntityType.Builder.<NpcEntity>of(NpcEntity::new, MobCategory.MISC)
                .sized(0.6F, 1.95F)
                .clientTrackingRange(10)
                .build(name));
    }

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ELDRIC.get(), NpcEntity.createAttributes().build());
        event.put(LYRA.get(), NpcEntity.createAttributes().build());
        event.put(BRAM.get(), NpcEntity.createAttributes().build());
        event.put(SILAS.get(), NpcEntity.createAttributes().build());
        event.put(ANCIANO.get(), NpcEntity.createAttributes().build());
        event.put(COMERCIANTE.get(), TraderEntity.createAttributes().build());
        event.put(GUARDIAN.get(), GuardianBossEntity.createAttributes().build());
        event.put(QUIMERA.get(), FusionBossEntity.createAttributes().build());
        event.put(SILAS_JEFE.get(), SilasBossEntity.createAttributes().build());
    }

    private ModEntities() {}
}
