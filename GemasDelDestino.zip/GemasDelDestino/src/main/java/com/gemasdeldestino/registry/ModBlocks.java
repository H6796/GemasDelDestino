package com.gemasdeldestino.registry;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.block.ChallengeAltarBlock;
import com.gemasdeldestino.block.KeyDoorBlock;
import com.gemasdeldestino.block.PedestalBlock;
import com.gemasdeldestino.block.PuzzleCoreBlock;
import com.gemasdeldestino.block.RuneBlock;
import com.gemasdeldestino.block.SealBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, GemasMod.MODID);

    /** Propiedades de un bloque irrompible (como la roca madre). */
    private static BlockBehaviour.Properties unbreakable(MapColor color, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(-1.0F, 3600000.0F).sound(sound).noLootTable();
    }

    /** Pedestal donde descansa cada gema dentro de su mazmorra. */
    public static final RegistryObject<Block> PEDESTAL = BLOCKS.register("pedestal",
            () -> new PedestalBlock(unbreakable(MapColor.COLOR_BLACK, SoundType.DEEPSLATE_BRICKS)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(PedestalBlock.GEM) > 0 ? 13 : 3)));

    // Muros y suelos irrompibles de las mazmorras (así no se pueden saltar los puzzles cavando)
    public static final RegistryObject<Block> MURO_FUEGO = BLOCKS.register("muro_fuego", () -> new Block(unbreakable(MapColor.NETHER, SoundType.NETHER_BRICKS)));
    public static final RegistryObject<Block> MURO_TORMENTA = BLOCKS.register("muro_tormenta", () -> new Block(unbreakable(MapColor.DEEPSLATE, SoundType.DEEPSLATE_TILES)));
    public static final RegistryObject<Block> MURO_VIENTO = BLOCKS.register("muro_viento", () -> new Block(unbreakable(MapColor.QUARTZ, SoundType.STONE)));
    public static final RegistryObject<Block> MURO_TIERRA = BLOCKS.register("muro_tierra", () -> new Block(unbreakable(MapColor.STONE, SoundType.STONE)));
    public static final RegistryObject<Block> MURO_VACIO = BLOCKS.register("muro_vacio", () -> new Block(unbreakable(MapColor.COLOR_BLACK, SoundType.STONE)));
    public static final RegistryObject<Block> MURO_HIELO = BLOCKS.register("muro_hielo", () -> new Block(unbreakable(MapColor.ICE, SoundType.GLASS)));
    public static final RegistryObject<Block> MURO_LUZ = BLOCKS.register("muro_luz", () -> new Block(unbreakable(MapColor.QUARTZ, SoundType.STONE)));
    public static final RegistryObject<Block> MURO_TIEMPO = BLOCKS.register("muro_tiempo", () -> new Block(unbreakable(MapColor.DIAMOND, SoundType.STONE)));
    public static final RegistryObject<Block> SUELO_HIELO = BLOCKS.register("suelo_hielo", () -> new Block(unbreakable(MapColor.SNOW, SoundType.SNOW)));
    public static final RegistryObject<Block> SUELO_LUZ = BLOCKS.register("suelo_luz", () -> new Block(unbreakable(MapColor.GOLD, SoundType.METAL)));
    public static final RegistryObject<Block> SUELO_TIEMPO = BLOCKS.register("suelo_tiempo", () -> new Block(unbreakable(MapColor.WARPED_STEM, SoundType.STONE)));
    public static final RegistryObject<Block> SUELO_FUEGO = BLOCKS.register("suelo_fuego", () -> new Block(unbreakable(MapColor.COLOR_BLACK, SoundType.POLISHED_DEEPSLATE)));
    public static final RegistryObject<Block> SUELO_TORMENTA = BLOCKS.register("suelo_tormenta", () -> new Block(unbreakable(MapColor.COLOR_ORANGE, SoundType.COPPER)));
    public static final RegistryObject<Block> SUELO_VIENTO = BLOCKS.register("suelo_viento", () -> new Block(unbreakable(MapColor.QUARTZ, SoundType.STONE)));
    public static final RegistryObject<Block> SUELO_TIERRA = BLOCKS.register("suelo_tierra", () -> new Block(unbreakable(MapColor.DIRT, SoundType.PACKED_MUD)));
    public static final RegistryObject<Block> SUELO_VACIO = BLOCKS.register("suelo_vacio", () -> new Block(unbreakable(MapColor.SAND, SoundType.STONE)));

    /** Muro de la Fortaleza del Eclipse (irrompible). */
    public static final RegistryObject<Block> MURO_ECLIPSE = BLOCKS.register("muro_eclipse",
            () -> new Block(unbreakable(MapColor.COLOR_BLACK, SoundType.DEEPSLATE_BRICKS)));

    /** Cristal de defensa de la fortaleza: hay que romper los cuatro para abrir la puerta. */
    public static final RegistryObject<Block> CRISTAL_DEFENSA = BLOCKS.register("cristal_defensa",
            () -> new com.gemasdeldestino.block.DefenseCrystalBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_MAGENTA)
                    .strength(6.0F, 1200.0F).sound(SoundType.AMETHYST).lightLevel(s -> 15).noLootTable()));

    /** Luz irrompible del techo de las mazmorras. */
    public static final RegistryObject<Block> LUZ = BLOCKS.register("luz_runica",
            () -> new Block(unbreakable(MapColor.COLOR_YELLOW, SoundType.GLASS).lightLevel(s -> 15)));

    /** Barrera rúnica que bloquea una puerta hasta resolver el puzzle de la sala. */
    public static final RegistryObject<Block> SELLO = BLOCKS.register("sello_runico",
            () -> new SealBlock(unbreakable(MapColor.COLOR_PURPLE, SoundType.AMETHYST).lightLevel(s -> 10)));

    /** Puerta que solo se abre con la Llave del Sello que suelta el minijefe. */
    public static final RegistryObject<Block> CERRADURA = BLOCKS.register("cerradura_sello",
            () -> new KeyDoorBlock(unbreakable(MapColor.GOLD, SoundType.METAL).lightLevel(s -> 6)));

    /** Runa que cambia de símbolo al hacer clic. */
    public static final RegistryObject<Block> RUNA = BLOCKS.register("runa",
            () -> new RuneBlock(unbreakable(MapColor.STONE, SoundType.STONE).lightLevel(s -> 7)));

    /** Núcleo oculto en el suelo que guarda la solución del puzzle de runas. */
    public static final RegistryObject<Block> NUCLEO = BLOCKS.register("nucleo_runico",
            () -> new PuzzleCoreBlock(unbreakable(MapColor.STONE, SoundType.STONE)));

    /** Altar de desafío: oleadas de enemigos que, al superarlas, rompen los sellos. */
    public static final RegistryObject<Block> ALTAR = BLOCKS.register("altar_desafio",
            () -> new ChallengeAltarBlock(unbreakable(MapColor.COLOR_RED, SoundType.LODESTONE)
                    .lightLevel(s -> s.getValue(ChallengeAltarBlock.STATE) > 0 ? 12 : 4)));

    private ModBlocks() {}
}
