package com.gemasdeldestino.registry;

import com.gemasdeldestino.GemasMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GemasMod.MODID);

    public static final RegistryObject<CreativeModeTab> GEMAS = TABS.register("gemas", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.gemasdeldestino"))
            .icon(() -> new ItemStack(ModItems.GEMA_VACIO.get()))
            .displayItems((params, output) -> {
                output.accept(ModItems.GEMA_FUEGO.get());
                output.accept(ModItems.GEMA_TORMENTA.get());
                output.accept(ModItems.GEMA_VIENTO.get());
                output.accept(ModItems.GEMA_TIERRA.get());
                output.accept(ModItems.GEMA_HIELO.get());
                output.accept(ModItems.GEMA_LUZ.get());
                output.accept(ModItems.GEMA_TIEMPO.get());
                output.accept(ModItems.GEMA_VACIO.get());
                output.accept(ModItems.FRAGMENTO_MAPA.get());
                output.accept(ModItems.MAPA_ECLIPSE.get());
                output.accept(ModItems.LLAVE_SELLO.get());
            })
            .build());

    private ModTabs() {}
}
