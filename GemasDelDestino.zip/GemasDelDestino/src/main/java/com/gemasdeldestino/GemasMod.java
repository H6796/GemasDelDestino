package com.gemasdeldestino;

import com.gemasdeldestino.network.ModNetwork;
import com.gemasdeldestino.registry.ModBlocks;
import com.gemasdeldestino.registry.ModEntities;
import com.gemasdeldestino.registry.ModItems;
import com.gemasdeldestino.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Las Gemas del Destino - un mod estilo "Story Mode" para Minecraft 1.20.1 (Forge).
 */
@Mod(GemasMod.MODID)
public class GemasMod {
    public static final String MODID = "gemasdeldestino";

    public GemasMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModTabs.TABS.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
