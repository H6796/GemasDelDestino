package com.gemasdeldestino.cinematic;

import com.gemasdeldestino.story.DialogueLine;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Una cinemática: lista de planos de cámara con subtítulos.
 * Todas las posiciones son relativas a un punto ancla que envía el servidor.
 */
public class Cinematic {

    /**
     * Un plano: la cámara viaja de {@code from} a {@code to} mirando de {@code lookFrom} a {@code lookTo}.
     * {@code sound} es opcional: chime, thunder, wither, beacon, totem, portal, levelup.
     */
    public record Shot(Vec3 from, Vec3 to, Vec3 lookFrom, Vec3 lookTo, int ticks,
                       @Nullable DialogueLine line, @Nullable String sound) {}

    public final String id;
    public final List<Shot> shots = new ArrayList<>();

    public Cinematic(String id) {
        this.id = id;
    }

    public Cinematic shot(double fx, double fy, double fz, double tx, double ty, double tz,
                          double lx, double ly, double lz, int ticks, @Nullable DialogueLine line) {
        return shot(new Vec3(fx, fy, fz), new Vec3(tx, ty, tz), new Vec3(lx, ly, lz), new Vec3(lx, ly, lz), ticks, line, null);
    }

    public Cinematic shot(Vec3 from, Vec3 to, Vec3 lookFrom, Vec3 lookTo, int ticks, @Nullable DialogueLine line, @Nullable String sound) {
        shots.add(new Shot(from, to, lookFrom, lookTo, ticks, line, sound));
        return this;
    }

    public Cinematic sound(String sound) {
        Shot last = shots.remove(shots.size() - 1);
        shots.add(new Shot(last.from(), last.to(), last.lookFrom(), last.lookTo(), last.ticks(), last.line(), sound));
        return this;
    }

    public int totalTicks() {
        int t = 0;
        for (Shot s : shots) t += s.ticks();
        return t;
    }
}
