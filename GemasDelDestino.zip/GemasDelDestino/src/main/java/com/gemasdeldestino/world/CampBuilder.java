package com.gemasdeldestino.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Construye el campamento de los héroes: hoguera, tiendas, forja de Bram, atril de Eldric y el "cofre" de Silas.
 */
public final class CampBuilder {

    /** Desplazamientos de cada NPC respecto al centro del campamento (x, z). */
    public static final int[] ELDRIC = {0, -4};
    public static final int[] LYRA = {4, 1};
    public static final int[] BRAM = {-4, 1};
    public static final int[] SILAS = {0, 4};

    /** Construye el campamento cerca de {@code near} y devuelve el centro (primer bloque de aire sobre el suelo). */
    public static BlockPos build(ServerLevel level, BlockPos near) {
        level.getChunk(near.getX() >> 4, near.getZ() >> 4);
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, near);
        Builder b = new Builder(level, top);

        // Explanada de 15x15
        for (int x = -7; x <= 7; x++) {
            for (int z = -7; z <= 7; z++) {
                b.fill(x, 0, z, x, 8, z, Blocks.AIR);
                b.set(x, -1, z, (x * x + z * z) <= 9 ? Blocks.COARSE_DIRT : Blocks.GRASS_BLOCK);
                for (int y = -2; y >= -5; y--) {
                    if (b.get(x, y, z).isAir() || !b.get(x, y, z).getFluidState().isEmpty()) b.set(x, y, z, Blocks.DIRT);
                }
            }
        }

        // Hoguera central y troncos para sentarse
        b.set(0, 0, 0, Blocks.CAMPFIRE);
        BlockState logX = Blocks.OAK_LOG.defaultBlockState().setValue(BlockStateProperties.AXIS, Direction.Axis.X);
        BlockState logZ = Blocks.OAK_LOG.defaultBlockState().setValue(BlockStateProperties.AXIS, Direction.Axis.Z);
        b.set(-1, 0, 2, logX); b.set(1, 0, 2, logX);
        b.set(-1, 0, -2, logX); b.set(1, 0, -2, logX);
        b.set(2, 0, 0, logZ); b.set(-2, 0, 0, logZ);

        // Tiendas
        tent(b, -5, -6, Blocks.YELLOW_WOOL);   // Eldric (detrás, al norte)
        tent(b, 5, -6, Blocks.LIGHT_BLUE_WOOL); // Lyra
        tent(b, -5, 5, Blocks.ORANGE_WOOL);     // Bram
        tent(b, 5, 5, Blocks.PURPLE_WOOL);      // Silas

        // Atril de Eldric
        b.set(2, 0, -5, Blocks.LECTERN);
        b.set(-2, 0, -5, Blocks.BOOKSHELF);

        // Forja de Bram
        b.set(-6, 0, 1, Blocks.ANVIL);
        b.set(-6, 0, 2, Blocks.BLAST_FURNACE.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.EAST));
        b.set(-6, 0, 0, Blocks.SMITHING_TABLE);

        // Mesa de Lyra
        b.set(6, 0, 1, Blocks.CARTOGRAPHY_TABLE);
        b.set(6, 0, 2, Blocks.CRAFTING_TABLE);

        // "Cofre de las gemas" de Silas (siempre vacío... sospechoso)
        b.set(2, 0, 5, Blocks.CHEST.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH));
        b.set(-2, 0, 5, Blocks.ENCHANTING_TABLE);

        // Farolillos en las esquinas
        for (int[] c : new int[][]{{-7, -7}, {7, -7}, {-7, 7}, {7, 7}, {0, -7}, {0, 7}, {-7, 0}, {7, 0}}) {
            b.set(c[0], 0, c[1], Blocks.OAK_FENCE);
            b.set(c[0], 1, c[1], Blocks.LANTERN);
        }
        return top;
    }

    /** Tienda en forma de A, abierta hacia el centro. */
    private static void tent(Builder b, int cx, int cz, Block wool) {
        for (int dz = -1; dz <= 1; dz++) {
            b.set(cx - 2, 0, cz + dz, wool);
            b.set(cx + 2, 0, cz + dz, wool);
            b.set(cx - 1, 1, cz + dz, wool);
            b.set(cx + 1, 1, cz + dz, wool);
            b.set(cx, 2, cz + dz, wool);
        }
        BlockState bed = Blocks.WHITE_BED.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH);
        b.set(cx, 0, cz, bed.setValue(BlockStateProperties.BED_PART, net.minecraft.world.level.block.state.properties.BedPart.HEAD));
        b.set(cx, 0, cz + 1, bed.setValue(BlockStateProperties.BED_PART, net.minecraft.world.level.block.state.properties.BedPart.FOOT));
    }

    private CampBuilder() {}
}
