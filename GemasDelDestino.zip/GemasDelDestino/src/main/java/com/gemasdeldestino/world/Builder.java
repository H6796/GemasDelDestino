package com.gemasdeldestino.world;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Pequeña ayuda para colocar bloques relativos a un origen. */
public class Builder {
    protected final ServerLevel level;
    protected final BlockPos origin;

    public Builder(ServerLevel level, BlockPos origin) {
        this.level = level;
        this.origin = origin;
    }

    public BlockPos at(int x, int y, int z) {
        return origin.offset(x, y, z);
    }

    public void set(int x, int y, int z, BlockState state) {
        BlockPos p = at(x, y, z);
        if (level.isOutsideBuildHeight(p)) return;
        level.setBlock(p, state, Block.UPDATE_CLIENTS);
    }

    public void set(int x, int y, int z, Block block) {
        set(x, y, z, block.defaultBlockState());
    }

    public void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    set(x, y, z, state);
    }

    public void fill(int x1, int y1, int z1, int x2, int y2, int z2, Block block) {
        fill(x1, y1, z1, x2, y2, z2, block.defaultBlockState());
    }

    public BlockState get(int x, int y, int z) {
        return level.getBlockState(at(x, y, z));
    }
}
