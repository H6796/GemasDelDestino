package com.gemasdeldestino.world;

import com.gemasdeldestino.registry.ModBlocks;
import com.gemasdeldestino.story.Lore;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * La Fortaleza del Eclipse: el castillo de Silas.
 *
 *  - Foso de lava con un único puente al sur.
 *  - Muralla irrompible de 12 bloques con la puerta sellada.
 *  - Cuatro torres con generadores de monstruos y un Cristal de defensa en lo alto de cada una.
 *    Al romper los cuatro cristales, el sello de la puerta desaparece.
 *  - Patio lleno de monstruos de la Orden.
 *  - Torre del homenaje con el Salón del Trono: la arena del combate final.
 */
public final class CastleBuilder {
    /** Centro del salón del trono relativo al centro del castillo. */
    public static final int THRONE_Z = -10;
    /** Mitad del lado interior del salón (la arena). */
    public static final int HALL = 12;

    public static void build(ServerLevel level, BlockPos c) {
        RandomSource r = RandomSource.create(c.asLong() ^ 0xEC11L);
        BlockState wall = ModBlocks.MURO_ECLIPSE.get().defaultBlockState();
        int t = TownBuilder.flatten(level, c, 36, 40, 1, Blocks.BLACKSTONE);

        // Foso de lava y puente
        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            for (int x = -32; x <= 32; x++)
                for (int z = -32; z <= 32; z++) {
                    int ring = Math.max(Math.abs(x), Math.abs(z));
                    if (ring >= 29 && ring <= 31) {
                        b.set(x, -4, z, wall);
                        b.fill(x, -3, z, x, -1, z, Blocks.LAVA);
                    } else if (ring <= 28) {
                        b.set(x, -1, z, ring <= 21 ? Blocks.POLISHED_BLACKSTONE_BRICKS : Blocks.BLACKSTONE);
                    }
                }
            b.fill(-2, -1, 24, 2, -1, 32, Blocks.POLISHED_BLACKSTONE_BRICKS);
            b.fill(-3, 0, 29, -3, 0, 31, Blocks.POLISHED_BLACKSTONE_BRICK_WALL);
            b.fill(3, 0, 29, 3, 0, 31, Blocks.POLISHED_BLACKSTONE_BRICK_WALL);
        });

        // Muralla exterior con almenas y la puerta sellada
        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            for (int i = -23; i <= 23; i++) {
                for (int d = 22; d <= 23; d++) {
                    for (int[] p : new int[][]{{i, -d}, {i, d}, {-d, i}, {d, i}}) b.fill(p[0], 0, p[1], p[0], 11, p[1], wall);
                }
                if ((i & 1) == 0) {
                    for (int[] p : new int[][]{{i, -23}, {i, 23}, {-23, i}, {23, i}}) b.set(p[0], 12, p[1], wall);
                }
            }
            b.fill(-2, 0, 22, 2, 5, 23, ModBlocks.SELLO.get().defaultBlockState());
            for (int x = -4; x <= 4; x += 8) b.fill(x, 0, 24, x, 8, 24, Blocks.CRYING_OBSIDIAN);
            b.set(-4, 9, 24, Blocks.SOUL_LANTERN);
            b.set(4, 9, 24, Blocks.SOUL_LANTERN);
        });

        // Cuatro torres con cristal de defensa
        int[][] towers = {{-22, -22, -1, -1}, {22, -22, 1, -1}, {-22, 22, -1, 1}, {22, 22, 1, 1}};
        for (int[] tw : towers) {
            StoryManager.schedule(t++, s -> tower(level, c.offset(tw[0], 0, tw[1]), tw[2], wall, r));
        }

        // Patio: braseros, estatuas y generadores
        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            for (int[] p : new int[][]{{-17, -17}, {17, -17}, {-17, 17}, {17, 17}, {-17, 0}, {17, 0}}) {
                b.fill(p[0], 0, p[1], p[0], 2, p[1], Blocks.POLISHED_BLACKSTONE_BRICKS);
                b.set(p[0], 3, p[1], Blocks.SOUL_CAMPFIRE);
            }
            for (int z = 14; z <= 21; z++) b.fill(-1, -1, z, 1, -1, z, Blocks.PURPLE_TERRACOTTA);
            spawner(b, level, -18, 0, 10, EntityType.WITHER_SKELETON, r);
            spawner(b, level, 18, 0, 10, EntityType.BLAZE, r);
            spawner(b, level, 0, 0, 20, EntityType.SKELETON, r);
        });

        // Torre del homenaje: carcasa
        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            b.fill(-13, 0, -13, 13, 18, 13, wall);
            b.fill(-HALL, 0, -HALL, HALL, 17, HALL, Blocks.AIR);
            b.fill(-HALL, -1, -HALL, HALL, -1, HALL, Blocks.POLISHED_BLACKSTONE);
            for (int i = -13; i <= 13; i += 2) {
                b.set(i, 19, -13, wall); b.set(i, 19, 13, wall); b.set(-13, 19, i, wall); b.set(13, 19, i, wall);
            }
            b.fill(-2, 0, 13, 2, 5, 13, Blocks.AIR); // gran puerta
            for (int[] k : new int[][]{{-13, -13}, {13, -13}, {-13, 13}, {13, 13}}) {
                b.fill(k[0] - 2, 0, k[1] - 2, k[0] + 2, 26, k[1] + 2, wall);
                b.set(k[0], 27, k[1], Blocks.SOUL_LANTERN);
            }
            // Aguja central
            b.fill(-1, 19, -1, 1, 30, 1, wall);
            b.fill(0, 31, 0, 0, 38, 0, Blocks.CRYING_OBSIDIAN);
            b.set(0, 39, 0, Blocks.END_ROD);
        });

        // Salón del trono
        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            for (int x = -9; x <= 9; x += 9)
                for (int z = -6; z <= 6; z += 6)
                    if (x != 0) b.fill(x, 0, z, x, 17, z, wall);
            for (int x = -9; x <= 9; x += 6)
                for (int z = -9; z <= 9; z += 6)
                    b.set(x, 17, z, ModBlocks.LUZ.get());
            for (int z = THRONE_Z + 3; z <= 12; z++) b.set(0, 0, z, Blocks.PURPLE_CARPET);
            // Estrado y trono
            b.fill(-5, 0, -12, 5, 0, THRONE_Z + 1, Blocks.POLISHED_BLACKSTONE_BRICKS);
            b.fill(-3, 1, -12, 3, 1, THRONE_Z, Blocks.POLISHED_BLACKSTONE_BRICKS);
            b.set(0, 2, THRONE_Z - 1, Blocks.GILDED_BLACKSTONE);
            b.fill(0, 3, -12, 0, 6, -12, Blocks.CRYING_OBSIDIAN);
            b.fill(-1, 3, -12, -1, 4, -12, Blocks.CRYING_OBSIDIAN);
            b.fill(1, 3, -12, 1, 4, -12, Blocks.CRYING_OBSIDIAN);
            b.set(-3, 2, -12, Blocks.SOUL_LANTERN);
            b.set(3, 2, -12, Blocks.SOUL_LANTERN);
            for (int x : new int[]{-11, 11})
                for (int z = -8; z <= 8; z += 4) b.set(x, 3, z, Blocks.CRYING_OBSIDIAN);
            b.set(-10, 0, 10, Blocks.LECTERN.defaultBlockState().setValue(LecternBlock.HAS_BOOK, true));
            if (level.getBlockEntity(b.at(-10, 0, 10)) instanceof LecternBlockEntity l) {
                l.setBook(Lore.book("La Última Página", "S.",
                        "Si has llegado hasta aquí, has destruido mis defensas.\n\nImpresionante.\n\nPero los ocho guardianes me obedecen ahora. "
                                + "Y cuando caigan, sus almas me pertenecerán.\n\n- S."));
            }
        });

        // Guarnición del patio
        StoryManager.schedule(t + 3, s -> {
            EntityType<?>[] garrison = {EntityType.WITHER_SKELETON, EntityType.WITHER_SKELETON, EntityType.VINDICATOR, EntityType.VINDICATOR,
                    EntityType.VINDICATOR, EntityType.EVOKER, EntityType.PILLAGER, EntityType.PILLAGER, EntityType.RAVAGER, EntityType.BLAZE};
            int[][] spots = {{-18, -5}, {18, -5}, {-18, 5}, {18, 5}, {-8, 17}, {8, 17}, {-15, 16}, {15, 16}, {0, -18}, {-10, -18}};
            for (int i = 0; i < garrison.length; i++) {
                spawnMob(level, garrison[i], c.offset(spots[i][0], 0, spots[i][1]));
            }
            for (var p : level.players()) {
                if (p.blockPosition().closerThan(c, 300)) {
                    p.sendSystemMessage(Component.literal("La tierra tiembla... la Fortaleza del Eclipse se alza en el horizonte.")
                            .withStyle(ChatFormatting.DARK_PURPLE));
                }
            }
        });
    }

    private static void tower(ServerLevel level, BlockPos tc, int sx, BlockState wall, RandomSource r) {
        Builder b = new Builder(level, tc);
        b.fill(-4, 0, -4, 4, 24, 4, wall);
        b.fill(-3, 0, -3, 3, 23, 3, Blocks.AIR);
        b.fill(-3, -1, -3, 3, -1, 3, Blocks.POLISHED_BLACKSTONE);
        for (int i = -4; i <= 4; i += 2) {
            b.set(i, 25, -4, wall); b.set(i, 25, 4, wall); b.set(-4, 25, i, wall); b.set(4, 25, i, wall);
        }
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
        for (int y = 0; y <= 24; y++) b.set(0, y, -3, ladder);
        b.fill(4 * sx, 0, -1, 4 * sx, 2, 1, Blocks.AIR); // puerta hacia fuera
        for (int y = 5; y < 23; y += 6) b.set(4 * sx, y, 0, Blocks.AIR); // aspilleras
        spawner(b, level, 2, 0, 2, EntityType.WITHER_SKELETON, r);
        spawner(b, level, -2, 12, 2, EntityType.SKELETON, r);
        b.fill(-2, 11, 1, 2, 11, 3, Blocks.POLISHED_BLACKSTONE);
        // Cima: cristal de defensa y generadores
        b.fill(-1, 25, -1, 1, 25, 1, Blocks.CRYING_OBSIDIAN);
        b.set(0, 26, 0, ModBlocks.CRISTAL_DEFENSA.get());
        spawner(b, level, 2, 25, 2, EntityType.BLAZE, r);
        spawner(b, level, -2, 25, 2, EntityType.SKELETON, r);
        b.set(2, 25, -2, Blocks.SOUL_LANTERN);
    }

    private static void spawner(Builder b, ServerLevel level, int x, int y, int z, EntityType<?> type, RandomSource r) {
        b.set(x, y, z, Blocks.SPAWNER);
        if (level.getBlockEntity(b.at(x, y, z)) instanceof SpawnerBlockEntity sp) sp.setEntityId(type, r);
    }

    private static void spawnMob(ServerLevel level, EntityType<?> type, BlockPos pos) {
        Entity e = type.create(level);
        if (!(e instanceof Mob mob)) return;
        mob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360, 0);
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
        mob.setPersistenceRequired();
        mob.setCustomName(Component.literal("Soldado del Eclipse").withStyle(ChatFormatting.DARK_PURPLE));
        level.addFreshEntity(mob);
    }

    public static BlockPos throne(BlockPos c) {
        return c.offset(0, 0, THRONE_Z + 4);
    }

    /** ¿Está esta posición dentro del salón del trono? */
    public static boolean inHall(BlockPos c, BlockPos p) {
        return Math.abs(p.getX() - c.getX()) <= HALL && Math.abs(p.getZ() - c.getZ()) <= HALL
                && p.getY() >= c.getY() - 1 && p.getY() <= c.getY() + 16;
    }

    private CastleBuilder() {}
}
