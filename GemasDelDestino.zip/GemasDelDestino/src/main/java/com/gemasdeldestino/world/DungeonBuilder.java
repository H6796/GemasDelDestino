package com.gemasdeldestino.world;

import com.gemasdeldestino.block.ChallengeAltarBlock;
import com.gemasdeldestino.block.PedestalBlock;
import com.gemasdeldestino.block.PuzzleCoreBlock;
import com.gemasdeldestino.block.RuneBlock;
import com.gemasdeldestino.entity.GuardianBossEntity;
import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.registry.ModBlocks;
import com.gemasdeldestino.registry.ModEntities;
import com.gemasdeldestino.story.Lore;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Generador de mazmorras por salas.
 *
 * La mazmorra es una cuadrícula de salas de 15x15 conectadas como un laberinto (árbol de expansión).
 * El camino principal va de la ENTRADA a la CÁMARA de la gema y pasa por salas de puzzle (runas o
 * desafío) cuyas puertas están selladas, y por la sala del GUARDIÁN (minijefe), que suelta la llave
 * de la cámara. El resto de salas son ramas opcionales: combate, parkour, laberinto, tesoro,
 * biblioteca y descanso. Muros, suelos y techos son irrompibles para que no se pueda hacer trampa.
 */
public final class DungeonBuilder {
    public static final int CELL = 15;
    public static final int DEPTH = 40;
    private static final int[][] SIZES = {{4, 3}, {4, 4}, {5, 4}, {5, 5}, {5, 5}, {6, 5}, {6, 5}, {6, 6}};

    public enum Room { ENTRADA, COMBATE, PARKOUR, LABERINTO, TESORO, BIBLIOTECA, DESCANSO, RUNAS, DESAFIO, GUARDIAN, CAMARA }

    /** Datos que la historia necesita recordar de la mazmorra. */
    public record Result(BlockPos surface, BlockPos entranceRoom, BlockPos pedestal, int rooms) {}

    public static Result generate(ServerLevel level, BlockPos surface, GemType g) {
        int gi = g.ordinal();
        long seed = level.getSeed() ^ surface.asLong() ^ (gi * 31L);
        RandomSource r = RandomSource.create(seed);
        int gw = SIZES[gi][0], gh = SIZES[gi][1], n = gw * gh;

        int entrance = r.nextInt(n);
        int ex = entrance % gw, ez = entrance / gw;
        int floorY = Math.max(level.getMinBuildHeight() + 8, surface.getY() - DEPTH);
        BlockPos origin = new BlockPos(surface.getX() - ex * CELL - 7, floorY, surface.getZ() - ez * CELL - 7);

        // ---- Árbol de expansión (laberinto de salas) con DFS aleatorio
        boolean[] visited = new boolean[n];
        List<int[]> edges = new ArrayList<>();
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i < n; i++) adj.add(new ArrayList<>());
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(entrance);
        visited[entrance] = true;
        while (!stack.isEmpty()) {
            int c = stack.peek();
            List<Integer> options = new ArrayList<>();
            int cx = c % gw, cz = c / gw;
            if (cx > 0 && !visited[c - 1]) options.add(c - 1);
            if (cx < gw - 1 && !visited[c + 1]) options.add(c + 1);
            if (cz > 0 && !visited[c - gw]) options.add(c - gw);
            if (cz < gh - 1 && !visited[c + gw]) options.add(c + gw);
            if (options.isEmpty()) {
                stack.pop();
                continue;
            }
            int next = options.get(r.nextInt(options.size()));
            visited[next] = true;
            edges.add(new int[]{c, next});
            adj.get(c).add(next);
            adj.get(next).add(c);
            stack.push(next);
        }

        // ---- Distancias desde la entrada: la sala más lejana será la cámara de la gema
        int[] dist = new int[n];
        int[] prev = new int[n];
        Arrays.fill(dist, -1);
        Arrays.fill(prev, -1);
        Deque<Integer> queue = new ArrayDeque<>();
        queue.add(entrance);
        dist[entrance] = 0;
        while (!queue.isEmpty()) {
            int c = queue.poll();
            for (int nb : adj.get(c)) {
                if (dist[nb] < 0) {
                    dist[nb] = dist[c] + 1;
                    prev[nb] = c;
                    queue.add(nb);
                }
            }
        }
        int vault = entrance;
        for (int i = 0; i < n; i++) if (dist[i] > dist[vault]) vault = i;
        List<Integer> path = new ArrayList<>();
        for (int c = vault; c != -1; c = prev[c]) path.add(c);
        Collections.reverse(path);

        // ---- Tipos de sala
        Room[] types = new Room[n];
        types[entrance] = Room.ENTRADA;
        types[vault] = Room.CAMARA;
        Set<Long> sealed = new HashSet<>();
        long keyEdge = -1;
        if (path.size() >= 3) {
            int boss = path.get(path.size() - 2);
            types[boss] = Room.GUARDIAN;
            keyEdge = edgeKey(boss, vault);
        }
        int puzzles = Math.max(0, Math.min(2 + gi / 2, path.size() - 3));
        for (int j = 1; j <= puzzles; j++) {
            int idx = (int) Math.round(j * (path.size() - 2) / (double) (puzzles + 1));
            idx = Math.max(1, Math.min(path.size() - 3, idx));
            int cell = path.get(idx);
            if (types[cell] != null) continue;
            types[cell] = (j % 2 == 1) ? Room.RUNAS : Room.DESAFIO;
            sealed.add(edgeKey(cell, path.get(idx + 1)));
        }
        List<Integer> free = new ArrayList<>();
        for (int i = 0; i < n; i++) if (types[i] == null) free.add(i);
        Collections.shuffle(free, new java.util.Random(seed));
        Room[] guaranteed = {Room.DESCANSO, Room.BIBLIOTECA, Room.TESORO};
        for (int i = 0; i < free.size(); i++) {
            int cell = free.get(i);
            if (i < guaranteed.length) {
                types[cell] = guaranteed[i];
                continue;
            }
            int roll = r.nextInt(100);
            types[cell] = roll < 38 ? Room.COMBATE : roll < 58 ? Room.PARKOUR : roll < 74 ? Room.LABERINTO
                    : roll < 88 ? Room.TESORO : roll < 95 ? Room.BIBLIOTECA : Room.DESCANSO;
        }

        // ---- Programar la construcción (una sala por tick para no congelar el servidor)
        int t = 2;
        for (int i = 0; i < n; i++) {
            final int cell = i;
            final Room type = types[i];
            final BlockPos o = cellOrigin(origin, cell, gw);
            StoryManager.schedule(t++, s -> buildCell(level, o, type, g, RandomSource.create(seed + cell * 7919L)));
        }
        final long finalKeyEdge = keyEdge;
        final BlockPos entranceOrigin = cellOrigin(origin, entrance, gw);
        StoryManager.schedule(t++, s -> {
            for (int[] e : edges) carveDoor(level, origin, gw, e[0], e[1], g,
                    sealed.contains(edgeKey(e[0], e[1])), edgeKey(e[0], e[1]) == finalKeyEdge);
            buildShaft(level, surface, entranceOrigin, g, RandomSource.create(seed + 3));
        });
        if (path.size() >= 3) {
            final BlockPos bossPos = cellOrigin(origin, path.get(path.size() - 2), gw).offset(7, 1, 7);
            StoryManager.schedule(t++, s -> {
                GuardianBossEntity boss = ModEntities.GUARDIAN.get().create(level);
                if (boss != null) {
                    boss.moveTo(bossPos.getX() + 0.5, bossPos.getY(), bossPos.getZ() + 0.5, 180, 0);
                    boss.setup(g);
                    level.addFreshEntity(boss);
                }
            });
        }
        BlockPos vaultO = cellOrigin(origin, vault, gw);
        return new Result(surface, entranceOrigin.offset(7, 1, 7), vaultO.offset(7, 1, 7), n);
    }

    private static long edgeKey(int a, int b) {
        return ((long) Math.min(a, b) << 32) | Math.max(a, b);
    }

    private static BlockPos cellOrigin(BlockPos origin, int cell, int gw) {
        return origin.offset((cell % gw) * CELL, 0, (cell / gw) * CELL);
    }

    // =====================================================================================
    // Puertas
    // =====================================================================================
    private static void carveDoor(ServerLevel level, BlockPos origin, int gw, int a, int b, GemType g, boolean seal, boolean key) {
        int lo = Math.min(a, b), hi = Math.max(a, b);
        BlockPos o = cellOrigin(origin, lo, gw);
        Builder bd = new Builder(level, o);
        BlockState fill = key ? ModBlocks.CERRADURA.get().defaultBlockState()
                : seal ? ModBlocks.SELLO.get().defaultBlockState() : Blocks.AIR.defaultBlockState();
        if (hi == lo + 1) { // vecino al este
            bd.fill(14, 1, 6, 15, 3, 8, fill);
        } else {           // vecino al sur
            bd.fill(6, 1, 14, 8, 3, 15, fill);
        }
    }

    // =====================================================================================
    // Pozo de entrada (oculto bajo una alfombra)
    // =====================================================================================
    private static void buildShaft(ServerLevel level, BlockPos surface, BlockPos entranceCell, GemType g, RandomSource r) {
        Builder b = new Builder(level, entranceCell);
        BlockState wall = g.dungeonWall().defaultBlockState();
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
        int top = surface.getY() - entranceCell.getY() - 2;
        for (int y = 7; y <= top; y++) {
            for (int x = 6; x <= 8; x++)
                for (int z = 6; z <= 8; z++)
                    if (x != 7 || z != 7) b.set(x, y, z, wall);
            b.set(7, y, 7, ladder);
        }
        for (int y = 1; y <= 6; y++) b.set(7, y, 7, ladder);

        // Superficie
        Builder s = new Builder(level, surface);
        s.fill(-1, 0, -1, 1, 3, 1, Blocks.AIR);
        s.set(0, -1, 0, g.trapdoor.defaultBlockState()
                .setValue(BlockStateProperties.HALF, Half.TOP)
                .setValue(BlockStateProperties.OPEN, false)
                .setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH));
        s.set(0, 0, 0, g == GemType.TIERRA ? Blocks.MOSS_CARPET : g.carpet);

        // En los primeros capítulos hay unas pequeñas ruinas. Después, nada: solo la alfombra.
        if (g.ordinal() < 3) {
            Block[] ruin = {Blocks.MOSSY_COBBLESTONE, Blocks.CRACKED_STONE_BRICKS, Blocks.COBBLESTONE, Blocks.MOSSY_STONE_BRICKS};
            int[][] spots = {{-3, -3}, {3, -3}, {-3, 3}, {3, 3}, {0, -4}, {-4, 0}, {4, 1}, {2, 4}};
            for (int[] p : spots) {
                if (r.nextInt(3) == 0) continue;
                int h = 1 + r.nextInt(g.ordinal() == 0 ? 3 : 2);
                for (int y = 0; y < h; y++) s.set(p[0], y, p[1], ruin[r.nextInt(ruin.length)]);
            }
        }
    }

    // =====================================================================================
    // Salas
    // =====================================================================================
    private static void buildCell(ServerLevel level, BlockPos o, Room type, GemType g, RandomSource r) {
        Builder b = new Builder(level, o);
        BlockState wall = g.dungeonWall().defaultBlockState();
        BlockState floor = g.dungeonFloor().defaultBlockState();
        b.fill(0, 0, 0, 14, 7, 14, wall);
        b.fill(1, 0, 1, 13, 0, 13, floor);
        b.fill(1, 1, 1, 13, 6, 13, Blocks.AIR);
        if (g == GemType.VACIO) {
            b.set(7, 7, 7, ModBlocks.LUZ.get());
        } else {
            for (int[] p : new int[][]{{4, 4}, {10, 4}, {4, 10}, {10, 10}}) b.set(p[0], 7, p[1], ModBlocks.LUZ.get());
        }
        int gi = g.ordinal();

        switch (type) {
            case ENTRADA -> {
                b.fill(7, 1, 6, 7, 6, 6, wall);
                lectern(b, level, 2, 1, 2, Lore.entranceBook(g));
                chest(b, level, 12, 1, 2, null, new ItemStack(Items.TORCH, 32), new ItemStack(Items.BREAD, 8),
                        PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.HEALING));
            }
            case COMBATE -> {
                spawner(b, level, 7, 1, 7, r.nextBoolean() ? g.spawnerMob : g.secondMob(), r);
                for (int[] p : new int[][]{{4, 4}, {10, 4}, {4, 10}, {10, 10}}) b.fill(p[0], 1, p[1], p[0], 6, p[1], wall);
                if (gi >= 2) spawner(b, level, 2, 1, 12, g.secondMob(), r);
                if (r.nextInt(3) == 0) chest(b, level, 12, 1, 12, BuiltInLootTables.SIMPLE_DUNGEON);
                for (int i = 0; i < 4; i++) {
                    int x = 2 + r.nextInt(11), z = 2 + r.nextInt(11);
                    if ((x < 5 || x > 9) && (z < 5 || z > 9)) b.set(x, 1, z, Blocks.COBWEB);
                }
            }
            case PARKOUR -> buildParkour(b, g, wall, floor);
            case LABERINTO -> buildMaze(b, wall, r);
            case TESORO -> {
                ResourceLocation[] loot = {g.treasureLoot(), BuiltInLootTables.SIMPLE_DUNGEON, BuiltInLootTables.ABANDONED_MINESHAFT};
                int[][] corners = {{2, 2}, {12, 2}, {2, 12}, {12, 12}};
                for (int i = 0; i < corners.length; i++) {
                    if (i == 3 && r.nextBoolean()) continue;
                    chest(b, level, corners[i][0], 1, corners[i][1], loot[i % loot.length]);
                }
                b.set(2, 1, 7, Blocks.GOLD_BLOCK);
                if (r.nextBoolean()) b.set(12, 1, 7, Blocks.EMERALD_BLOCK);
                if (r.nextBoolean()) spawner(b, level, 7, 1, 7, EntityType.CAVE_SPIDER, r);
            }
            case BIBLIOTECA -> {
                for (int y = 1; y <= 3; y++) {
                    for (int i : new int[]{1, 2, 3, 4, 10, 11, 12, 13}) {
                        b.set(i, y, 1, Blocks.BOOKSHELF);
                        b.set(i, y, 13, Blocks.BOOKSHELF);
                        b.set(1, y, i, Blocks.BOOKSHELF);
                        b.set(13, y, i, Blocks.BOOKSHELF);
                    }
                }
                lectern(b, level, 7, 1, 7, Lore.libraryBook(g, r.nextInt(3)));
                b.set(3, 1, 3, Blocks.ENCHANTING_TABLE);
                b.set(11, 1, 11, Blocks.CANDLE.defaultBlockState().setValue(BlockStateProperties.CANDLES, 3).setValue(BlockStateProperties.LIT, true));
                if (r.nextBoolean()) chest(b, level, 11, 1, 3, BuiltInLootTables.STRONGHOLD_LIBRARY);
            }
            case DESCANSO -> {
                b.set(7, 1, 7, Blocks.CAMPFIRE);
                BlockState bed = Blocks.RED_BED.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH);
                b.set(2, 1, 2, bed.setValue(BlockStateProperties.BED_PART, BedPart.HEAD));
                b.set(2, 1, 3, bed.setValue(BlockStateProperties.BED_PART, BedPart.FOOT));
                chest(b, level, 12, 1, 2, null, new ItemStack(Items.COOKED_BEEF, 12), new ItemStack(Items.GOLDEN_CARROT, 6),
                        PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.HEALING),
                        PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.REGENERATION), new ItemStack(Items.ARROW, 24));
                b.set(12, 1, 12, Blocks.CRAFTING_TABLE);
                b.set(11, 1, 12, Blocks.FURNACE);
                b.set(2, 1, 12, Blocks.ANVIL);
                b.set(3, 1, 12, Blocks.SMITHING_TABLE);
            }
            case RUNAS -> buildRunePuzzle(b, level, g, r);
            case DESAFIO -> {
                b.set(7, 1, 7, ModBlocks.ALTAR.get().defaultBlockState().setValue(ChallengeAltarBlock.GEM, gi));
                for (int[] p : new int[][]{{3, 3}, {11, 3}, {3, 11}, {11, 11}}) {
                    b.set(p[0], 1, p[1], g.accent);
                    b.set(p[0], 2, p[1], Blocks.SOUL_LANTERN);
                }
                lectern(b, level, 2, 1, 7, Lore.challengeHint());
            }
            case GUARDIAN -> {
                for (int[] p : new int[][]{{3, 3}, {11, 3}, {3, 11}, {11, 11}}) b.fill(p[0], 1, p[1], p[0], 6, p[1], wall);
                for (int[] p : new int[][]{{3, 4}, {11, 4}, {3, 10}, {11, 10}}) b.set(p[0], 1, p[1], Blocks.SOUL_LANTERN);
                b.set(1, 1, 1, Blocks.CHAIN);
                b.set(13, 1, 13, Blocks.CHAIN);
            }
            case CAMARA -> {
                b.set(7, 1, 7, ModBlocks.PEDESTAL.get().defaultBlockState().setValue(PedestalBlock.GEM, gi + 1));
                for (int[] p : new int[][]{{5, 5}, {9, 5}, {5, 9}, {9, 9}}) b.set(p[0], 1, p[1], g.accent);
                chest(b, level, 12, 1, 2, g.treasureLoot());
                chest(b, level, 12, 1, 12, BuiltInLootTables.STRONGHOLD_CORRIDOR);
                lectern(b, level, 2, 1, 2, Lore.journal(g));
                b.set(2, 1, 12, Blocks.SOUL_LANTERN);
            }
        }
    }

    /** Sala de saltos sobre un peligro distinto en cada mazmorra. */
    private static void buildParkour(Builder b, GemType g, BlockState wall, BlockState floor) {
        int spacing = g.ordinal() < 2 ? 2 : 3;
        boolean lava = g == GemType.FUEGO;
        int depth = lava ? 0 : 5;
        // Carcasa del foso
        b.fill(1, -depth - 1, 1, 13, -1, 13, wall);
        b.fill(2, -depth, 2, 12, 0, 12, lava ? Blocks.LAVA.defaultBlockState() : Blocks.AIR.defaultBlockState());
        if (!lava) {
            BlockState bottom = switch (g) {
                case TORMENTA -> Blocks.WATER.defaultBlockState();
                case VACIO -> Blocks.MAGMA_BLOCK.defaultBlockState();
                default -> Blocks.COBWEB.defaultBlockState();
            };
            b.fill(2, -depth, 2, 12, -depth, 12, bottom);
            BlockState ladderE = Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.EAST);
            BlockState ladderW = Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.WEST);
            for (int y = -depth + 1; y <= 0; y++) {
                b.set(2, y, 3, ladderE);
                b.set(12, y, 11, ladderW);
            }
        }
        // Piedras para saltar en forma de cruz
        for (int c = 2; c <= 12; c++) {
            if ((c - 2) % spacing != 0) continue;
            b.fill(7, -depth, c, 7, 0, c, floor);
            b.fill(c, -depth, 7, c, 0, 7, floor);
        }
    }

    /** Laberinto con muros irrompibles hasta el techo. */
    private static void buildMaze(Builder b, BlockState wall, RandomSource r) {
        b.fill(1, 1, 1, 13, 6, 13, wall);
        boolean[][] seen = new boolean[7][7];
        Deque<int[]> st = new ArrayDeque<>();
        st.push(new int[]{3, 3});
        seen[3][3] = true;
        carve(b, 3, 3);
        while (!st.isEmpty()) {
            int[] c = st.peek();
            List<int[]> opts = new ArrayList<>();
            int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            for (int[] d : dirs) {
                int nx = c[0] + d[0], nz = c[1] + d[1];
                if (nx >= 0 && nx < 7 && nz >= 0 && nz < 7 && !seen[nx][nz]) opts.add(new int[]{nx, nz});
            }
            if (opts.isEmpty()) {
                st.pop();
                continue;
            }
            int[] nxt = opts.get(r.nextInt(opts.size()));
            seen[nxt[0]][nxt[1]] = true;
            carve(b, nxt[0], nxt[1]);
            carve(b, c[0] + nxt[0], c[1] + nxt[1], true);
            st.push(nxt);
        }
        // Entradas desde las cuatro puertas posibles
        b.fill(1, 1, 6, 1, 3, 8, Blocks.AIR);
        b.fill(13, 1, 6, 13, 3, 8, Blocks.AIR);
        b.fill(6, 1, 1, 8, 3, 1, Blocks.AIR);
        b.fill(6, 1, 13, 8, 3, 13, Blocks.AIR);
        b.set(7, 6, 7, ModBlocks.LUZ.get());
    }

    private static void carve(Builder b, int cx, int cz) {
        int x = 1 + cx * 2, z = 1 + cz * 2;
        b.fill(x, 1, z, x, 4, z, Blocks.AIR);
    }

    /** Hueco entre dos celdas del laberinto: recibe la suma de coordenadas de ambas celdas. */
    private static void carve(Builder b, int sumX, int sumZ, boolean between) {
        int x = 1 + sumX, z = 1 + sumZ;
        b.fill(x, 1, z, x, 4, z, Blocks.AIR);
    }

    /** Puzzle de runas: hay que copiar el mural de colores del muro norte. */
    private static void buildRunePuzzle(Builder b, ServerLevel level, GemType g, RandomSource r) {
        boolean reversed = g.ordinal() >= 2;
        int pattern = r.nextInt(256);
        b.set(7, 0, 7, ModBlocks.NUCLEO.get().defaultBlockState()
                .setValue(PuzzleCoreBlock.PATTERN, pattern).setValue(PuzzleCoreBlock.REVERSED, reversed));
        Block[] colors = {Blocks.RED_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.LIME_CONCRETE, Blocks.YELLOW_CONCRETE};
        int[] xs = {4, 6, 8, 10};
        for (int i = 0; i < 4; i++) {
            int sym = PuzzleCoreBlock.symbolAt(pattern, i);
            int start = (sym + 1 + r.nextInt(3)) % 4; // nunca empieza resuelta
            b.set(xs[i], 1, 10, ModBlocks.RUNA.get().defaultBlockState().setValue(RuneBlock.SYMBOL, start));
            int muralX = reversed ? xs[3 - i] : xs[i];
            b.set(muralX, 4, 1, colors[sym]);
            b.set(muralX, 3, 1, Blocks.CHISELED_STONE_BRICKS);
        }
        lectern(b, level, 12, 1, 12, Lore.runeHint(reversed));
    }

    // =====================================================================================
    // Utilidades
    // =====================================================================================
    private static void spawner(Builder b, ServerLevel level, int x, int y, int z, EntityType<?> type, RandomSource r) {
        b.set(x, y, z, Blocks.SPAWNER);
        if (level.getBlockEntity(b.at(x, y, z)) instanceof SpawnerBlockEntity sp) sp.setEntityId(type, r);
    }

    private static void chest(Builder b, ServerLevel level, int x, int y, int z, ResourceLocation loot, ItemStack... items) {
        b.set(x, y, z, Blocks.CHEST.defaultBlockState());
        if (level.getBlockEntity(b.at(x, y, z)) instanceof ChestBlockEntity c) {
            for (int i = 0; i < items.length; i++) c.setItem(i * 2, items[i]);
            if (loot != null) c.setLootTable(loot, level.random.nextLong());
        }
    }

    private static void lectern(Builder b, ServerLevel level, int x, int y, int z, ItemStack book) {
        b.set(x, y, z, Blocks.LECTERN.defaultBlockState().setValue(LecternBlock.HAS_BOOK, true));
        if (level.getBlockEntity(b.at(x, y, z)) instanceof LecternBlockEntity l) l.setBook(book);
    }

    private DungeonBuilder() {}
}
