package com.gemasdeldestino.world;

import com.gemasdeldestino.entity.NpcEntity;
import com.gemasdeldestino.entity.TraderEntity;
import com.gemasdeldestino.entity.TraderEntity.Profession;
import com.gemasdeldestino.registry.ModEntities;
import com.gemasdeldestino.registry.ModItems;
import com.gemasdeldestino.story.Chapters;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;

import java.util.ArrayList;
import java.util.List;

/**
 * Construye pueblos (uno por capítulo), ciudades (centros de comercio) y torres de vigía.
 * Todo se construye por partes, repartido en varios ticks, para no congelar el servidor.
 */
public final class TownBuilder {

    public record Palette(Block planks, Block log, Block roof, Block base, Block wool, Block door) {}

    public static Palette villagePalette(int gi) {
        return switch (gi) {
            case 0 -> new Palette(Blocks.ACACIA_PLANKS, Blocks.ACACIA_LOG, Blocks.ORANGE_TERRACOTTA, Blocks.RED_SANDSTONE, Blocks.RED_WOOL, Blocks.ACACIA_DOOR);
            case 1 -> new Palette(Blocks.SPRUCE_PLANKS, Blocks.SPRUCE_LOG, Blocks.COBBLED_DEEPSLATE, Blocks.COBBLESTONE, Blocks.CYAN_WOOL, Blocks.SPRUCE_DOOR);
            case 2 -> new Palette(Blocks.BIRCH_PLANKS, Blocks.BIRCH_LOG, Blocks.WHITE_TERRACOTTA, Blocks.CALCITE, Blocks.WHITE_WOOL, Blocks.BIRCH_DOOR);
            case 3 -> new Palette(Blocks.DARK_OAK_PLANKS, Blocks.DARK_OAK_LOG, Blocks.MOSS_BLOCK, Blocks.MOSSY_COBBLESTONE, Blocks.GREEN_WOOL, Blocks.DARK_OAK_DOOR);
            case 4 -> new Palette(Blocks.SPRUCE_PLANKS, Blocks.STRIPPED_SPRUCE_LOG, Blocks.SNOW_BLOCK, Blocks.STONE_BRICKS, Blocks.LIGHT_BLUE_WOOL, Blocks.SPRUCE_DOOR);
            case 5 -> new Palette(Blocks.SMOOTH_SANDSTONE, Blocks.QUARTZ_PILLAR, Blocks.YELLOW_TERRACOTTA, Blocks.SANDSTONE, Blocks.YELLOW_WOOL, Blocks.BIRCH_DOOR);
            case 6 -> new Palette(Blocks.CHERRY_PLANKS, Blocks.CHERRY_LOG, Blocks.PRISMARINE_BRICKS, Blocks.POLISHED_ANDESITE, Blocks.CYAN_WOOL, Blocks.CHERRY_DOOR);
            default -> new Palette(Blocks.DEEPSLATE_BRICKS, Blocks.POLISHED_BLACKSTONE, Blocks.PURPUR_BLOCK, Blocks.COBBLED_DEEPSLATE, Blocks.PURPLE_WOOL, Blocks.WARPED_DOOR);
        };
    }

    private static final Palette CITY = new Palette(Blocks.OAK_PLANKS, Blocks.SPRUCE_LOG, Blocks.BRICKS, Blocks.STONE_BRICKS, Blocks.YELLOW_WOOL, Blocks.SPRUCE_DOOR);

    private static final String[] NAMES = {"Marta", "Tomás", "Lucía", "Andrés", "Elena", "Pablo", "Inés", "Rodrigo", "Clara",
            "Mateo", "Sofía", "Diego", "Noa", "Hugo", "Vera", "Iker", "Alba", "Gael", "Carmen", "Bruno", "Nerea", "Óscar"};

    enum Interior { CASA, TABERNA, HERRERIA, TEMPLO, AYUNTAMIENTO, BIBLIOTECA, JOYERIA }

    private record Spawn(BlockPos pos, Profession profession) {}

    // =====================================================================================
    // Búsqueda de terreno
    // =====================================================================================
    /** Busca un punto en tierra firme cerca de {@code near}, alejándose en espiral si hay agua. */
    public static BlockPos findLand(ServerLevel level, BlockPos near, double baseAngleDeg) {
        BlockPos fallback = null;
        for (int attempt = 0; attempt < 14; attempt++) {
            double a = Math.toRadians(baseAngleDeg + attempt * 47);
            int d = attempt == 0 ? 0 : 40 + attempt * 25;
            int x = near.getX() + (int) (Math.cos(a) * d), z = near.getZ() + (int) (Math.sin(a) * d);
            level.getChunk(x >> 4, z >> 4);
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
            if (fallback == null) fallback = top;
            boolean dry = level.getBlockState(top.below()).getFluidState().isEmpty();
            if (dry && top.getY() >= level.getSeaLevel() && top.getY() < level.getSeaLevel() + 40) return top;
        }
        return fallback;
    }

    /** Aplana un cuadrado de radio {@code r}, repartido en varios ticks. Devuelve el siguiente tick libre. */
    static int flatten(ServerLevel level, BlockPos c, int r, int clearHeight, int startTick, Block ground) {
        int t = startTick;
        for (int x0 = -r; x0 <= r; x0 += 6) {
            final int fx = x0;
            StoryManager.schedule(t++, s -> {
                Builder b = new Builder(level, c);
                for (int x = fx; x < Math.min(fx + 6, r + 1); x++) {
                    for (int z = -r; z <= r; z++) {
                        b.fill(x, 0, z, x, clearHeight, z, Blocks.AIR);
                        b.set(x, -1, z, ground);
                        for (int y = -2; y >= -6; y--) {
                            BlockState st = b.get(x, y, z);
                            if (st.isAir() || !st.getFluidState().isEmpty() || st.canBeReplaced()) b.set(x, y, z, Blocks.DIRT);
                        }
                    }
                }
            });
        }
        return t;
    }

    // =====================================================================================
    // Pueblos
    // =====================================================================================
    public static void buildVillage(ServerLevel level, BlockPos c, int gi) {
        Palette p = villagePalette(gi);
        RandomSource r = RandomSource.create(c.asLong());
        int t = flatten(level, c, 23, 14, 1, Blocks.GRASS_BLOCK);
        List<Spawn> traders = new ArrayList<>();

        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            // Plaza, caminos y pozo
            b.fill(-4, -1, -4, 4, -1, 4, Blocks.DIRT_PATH);
            b.fill(-1, -1, -22, 1, -1, 22, Blocks.DIRT_PATH);
            b.fill(-22, -1, -1, 22, -1, 1, Blocks.DIRT_PATH);
            well(b);
            for (int d : new int[]{7, 13, 20}) {
                lamp(b, 2, d); lamp(b, -2, -d); lamp(b, d, -2); lamp(b, -d, 2);
            }
            int[][] stalls = {{-7, -7}, {7, -7}, {-7, 7}, {7, 7}};
            Block[] wools = {p.wool(), Blocks.WHITE_WOOL, p.wool(), Blocks.WHITE_WOOL};
            for (int i = 0; i < stalls.length; i++) stall(b, stalls[i][0], stalls[i][1], wools[i]);
            farm(b, 13, 13);
        });

        int[][] houses = {
                {-10, -19, 3}, {4, -19, 4}, {13, -10, 2}, {13, 4, 1},
                {-10, 13, 3}, {4, 13, 4}, {-19, -10, 2}, {-19, 4, 1}};
        Direction[] dirs = {null, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
        for (int[] h : houses) {
            StoryManager.schedule(t++, s -> house(new Builder(level, c), h[0], 0, h[1], 7, 7, dirs[h[2]], p, Interior.CASA, r));
        }

        Profession[][] sets = {
                {Profession.HERRERO, Profession.GRANJERO, Profession.ALQUIMISTA, Profession.TABERNERO},
                {Profession.CARTOGRAFO, Profession.ARMERO, Profession.GRANJERO, Profession.TABERNERO},
                {Profession.JOYERO, Profession.ALQUIMISTA, Profession.BIBLIOTECARIO, Profession.GRANJERO},
                {Profession.HERRERO, Profession.ARMERO, Profession.ALQUIMISTA, Profession.JOYERO},
                {Profession.TABERNERO, Profession.ARMERO, Profession.GRANJERO, Profession.ALQUIMISTA},
                {Profession.ALQUIMISTA, Profession.JOYERO, Profession.BIBLIOTECARIO, Profession.HERRERO},
                {Profession.CARTOGRAFO, Profession.JOYERO, Profession.HERRERO, Profession.ARMERO},
                {Profession.JOYERO, Profession.ALQUIMISTA, Profession.ARMERO, Profession.BIBLIOTECARIO}};
        int[][] stalls = {{-7, -7}, {7, -7}, {-7, 7}, {7, 7}};
        for (int i = 0; i < 4; i++) traders.add(new Spawn(c.offset(stalls[i][0], 0, stalls[i][1] + (stalls[i][1] < 0 ? -2 : 2)), sets[gi % sets.length][i]));

        StoryManager.schedule(t + 2, s -> {
            spawnTraders(level, traders, r, 8);
            NpcEntity elder = ModEntities.ANCIANO.get().create(level);
            if (elder != null) {
                Chapters.Chapter ch = Chapters.get(gi);
                elder.setVillage(gi);
                elder.moveTo(c.getX() + 0.5, c.getY(), c.getZ() - 3.5, 0, 0);
                elder.setCustomName(Component.literal(ch.elder()).withStyle(ChatFormatting.GOLD));
                elder.setCustomNameVisible(true);
                level.addFreshEntity(elder);
            }
        });
    }

    // =====================================================================================
    // Ciudades
    // =====================================================================================
    public static void buildCity(ServerLevel level, BlockPos c, String name) {
        RandomSource r = RandomSource.create(c.asLong() ^ 0x5EEDL);
        int t = flatten(level, c, 37, 20, 1, Blocks.GRASS_BLOCK);
        List<Spawn> traders = new ArrayList<>();

        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            // Calles principales y plaza
            b.fill(-2, -1, -36, 2, -1, 36, Blocks.STONE_BRICKS);
            b.fill(-36, -1, -2, 36, -1, 2, Blocks.STONE_BRICKS);
            b.fill(-9, -1, -9, 9, -1, 9, Blocks.SMOOTH_STONE);
            // Fuente
            b.fill(-3, -1, -3, 3, 0, 3, Blocks.STONE_BRICKS);
            b.fill(-2, 0, -2, 2, 0, 2, Blocks.WATER);
            b.fill(0, 0, 0, 0, 3, 0, Blocks.CHISELED_STONE_BRICKS);
            b.set(0, 4, 0, Blocks.WATER);
            for (int d = 6; d <= 33; d += 7) {
                lamp(b, 3, d); lamp(b, -3, -d); lamp(b, d, -3); lamp(b, -d, 3);
            }
            int[][] stalls = {{-6, -6}, {6, -6}, {-6, 6}, {6, 6}};
            Block[] wools = {Blocks.RED_WOOL, Blocks.BLUE_WOOL, Blocks.YELLOW_WOOL, Blocks.GREEN_WOOL};
            for (int i = 0; i < 4; i++) stall(b, stalls[i][0], stalls[i][1], wools[i]);
        });

        // Murallas con torres y puertas
        StoryManager.schedule(t++, s -> {
            Builder b = new Builder(level, c);
            for (int i = -35; i <= 35; i++) {
                for (int[] w : new int[][]{{i, -35}, {i, 35}, {-35, i}, {35, i}}) {
                    b.fill(w[0], 0, w[1], w[0], 4, w[1], Blocks.STONE_BRICKS);
                    if ((i & 1) == 0) b.set(w[0], 5, w[1], Blocks.STONE_BRICK_WALL);
                }
            }
            for (int[] k : new int[][]{{-35, -35}, {35, -35}, {-35, 35}, {35, 35}}) {
                b.fill(k[0] - 2, 0, k[1] - 2, k[0] + 2, 8, k[1] + 2, Blocks.STONE_BRICKS);
                b.fill(k[0] - 1, 9, k[1] - 1, k[0] + 1, 9, k[1] + 1, Blocks.STONE_BRICK_WALL);
                b.set(k[0], 10, k[1], Blocks.LANTERN);
            }
            b.fill(-2, 0, -35, 2, 3, -35, Blocks.AIR);
            b.fill(-2, 0, 35, 2, 3, 35, Blocks.AIR);
            b.fill(-35, 0, -2, -35, 3, 2, Blocks.AIR);
            b.fill(35, 0, -2, 35, 3, 2, Blocks.AIR);
        });

        int[][] quads = {{1, 1}, {-1, 1}, {1, -1}, {-1, -1}};
        Interior[] bigTypes = {Interior.TABERNA, Interior.HERRERIA, Interior.TEMPLO, Interior.AYUNTAMIENTO};
        Interior[] dTypes = {Interior.BIBLIOTECA, Interior.JOYERIA, Interior.CASA, Interior.CASA};
        Profession[][] inside = {{Profession.TABERNERO}, {Profession.HERRERO, Profession.ARMERO}, {Profession.ALQUIMISTA}, {Profession.CARTOGRAFO}};
        Profession[][] insideD = {{Profession.BIBLIOTECARIO}, {Profession.JOYERO}, {}, {}};
        for (int q = 0; q < 4; q++) {
            int sx = quads[q][0], sz = quads[q][1];
            Direction door = sx > 0 ? Direction.WEST : Direction.EAST;
            int[][] rects = {{12, 12, 11, 9}, {25, 12, 7, 7}, {12, 24, 7, 7}, {22, 23, 10, 9}};
            Interior[] kinds = {bigTypes[q], Interior.CASA, Interior.CASA, dTypes[q]};
            for (int i = 0; i < rects.length; i++) {
                int w = rects[i][2], d = rects[i][3];
                int x0 = sx > 0 ? rects[i][0] : -(rects[i][0] + w - 1);
                int z0 = sz > 0 ? rects[i][1] : -(rects[i][1] + d - 1);
                Interior kind = kinds[i];
                StoryManager.schedule(t++, s -> house(new Builder(level, c), x0, 0, z0, w, d, door, CITY, kind, r));
                Profession[] who = i == 0 ? inside[q] : i == 3 ? insideD[q] : new Profession[0];
                for (int k = 0; k < who.length; k++)
                    traders.add(new Spawn(c.offset(x0 + w / 2 + k, 0, z0 + 2), who[k]));
            }
        }
        Profession[] market = {Profession.GRANJERO, Profession.CARTOGRAFO, Profession.ALQUIMISTA, Profession.JOYERO};
        int[][] stalls = {{-6, -6}, {6, -6}, {-6, 6}, {6, 6}};
        for (int i = 0; i < 4; i++) traders.add(new Spawn(c.offset(stalls[i][0], 0, stalls[i][1] + (stalls[i][1] < 0 ? -2 : 2)), market[i]));

        StoryManager.schedule(t + 2, s -> {
            spawnTraders(level, traders, r, 6);
            for (int i = 0; i < 2; i++) {
                IronGolem golem = EntityType.IRON_GOLEM.create(level);
                if (golem != null) {
                    golem.setPlayerCreated(true);
                    golem.moveTo(c.getX() + (i == 0 ? 10.5 : -9.5), c.getY(), c.getZ() + 0.5, 0, 0);
                    golem.setPersistenceRequired();
                    level.addFreshEntity(golem);
                }
            }
            for (var p : level.players()) {
                if (p.blockPosition().closerThan(c, 200)) {
                    p.sendSystemMessage(Component.literal("Las puertas de " + name + " se abren a los viajeros.").withStyle(ChatFormatting.GOLD));
                }
            }
        });
    }

    // =====================================================================================
    // Torre de vigía (tercera misión de cada pueblo)
    // =====================================================================================
    public static void buildTower(ServerLevel level, BlockPos top) {
        Builder b = new Builder(level, top.offset(-3, 0, -3));
        RandomSource r = RandomSource.create(top.asLong());
        Block[] stone = {Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS};
        int h = 16;
        for (int x = 0; x <= 6; x++)
            for (int z = 0; z <= 6; z++) {
                b.set(x, -1, z, Blocks.COBBLESTONE);
                for (int y = 0; y <= h; y++) {
                    boolean edge = x == 0 || x == 6 || z == 0 || z == 6;
                    b.set(x, y, z, edge || y == h ? stone[r.nextInt(3)].defaultBlockState() : Blocks.AIR.defaultBlockState());
                }
                if ((x == 0 || x == 6 || z == 0 || z == 6) && ((x + z) & 1) == 0) b.set(x, h + 1, z, Blocks.STONE_BRICK_WALL);
            }
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
        for (int y = 0; y <= h; y++) b.set(3, y, 1, ladder);
        b.set(3, h + 1, 1, Blocks.AIR);
        b.fill(3, 0, 6, 3, 1, 6, Blocks.AIR);
        for (int y = 3; y < h; y += 4) b.set(0, y, 3, Blocks.AIR);
        b.set(5, 0, 5, Blocks.SPAWNER);
        if (level.getBlockEntity(b.at(5, 0, 5)) instanceof SpawnerBlockEntity sp) sp.setEntityId(EntityType.SKELETON, r);
        b.set(1, 0, 5, Blocks.CHEST);
        if (level.getBlockEntity(b.at(1, 0, 5)) instanceof ChestBlockEntity ch) ch.setLootTable(BuiltInLootTables.SIMPLE_DUNGEON, r.nextLong());
        b.set(3, h + 1, 4, Blocks.CHEST);
        if (level.getBlockEntity(b.at(3, h + 1, 4)) instanceof ChestBlockEntity ch) {
            ch.setItem(13, new ItemStack(ModItems.FRAGMENTO_MAPA.get()));
            ch.setItem(11, new ItemStack(Items.EMERALD, 6));
            ch.setItem(15, new ItemStack(Items.GOLDEN_APPLE, 1));
        }
        b.set(5, h + 1, 5, Blocks.CAMPFIRE);
    }

    // =====================================================================================
    // Piezas
    // =====================================================================================
    private static void house(Builder b, int x0, int y, int z0, int w, int d, Direction door, Palette p, Interior kind, RandomSource r) {
        Block walls = kind == Interior.TEMPLO ? Blocks.QUARTZ_BRICKS : p.planks();
        Block corner = kind == Interior.TEMPLO ? Blocks.QUARTZ_PILLAR : p.log();
        b.fill(x0, y - 1, z0, x0 + w - 1, y - 1, z0 + d - 1, p.base());
        for (int x = x0; x < x0 + w; x++) {
            for (int z = z0; z < z0 + d; z++) {
                boolean ex = x == x0 || x == x0 + w - 1, ez = z == z0 || z == z0 + d - 1;
                for (int yy = y; yy <= y + 3; yy++) {
                    if (ex && ez) b.set(x, yy, z, corner);
                    else if (ex || ez) b.set(x, yy, z, (yy == y + 1 && ((ex ? z - z0 : x - x0) % 3 == 1)) ? Blocks.GLASS : walls);
                    else b.set(x, yy, z, Blocks.AIR);
                }
                if (!ex && !ez) b.set(x, y - 1, z, p.planks());
            }
        }
        // Tejado a dos aguas (escalonado)
        Block roof = kind == Interior.TEMPLO ? Blocks.SMOOTH_QUARTZ : p.roof();
        for (int k = 0; x0 - 1 + k <= x0 + w - k; k++) {
            b.fill(x0 - 1 + k, y + 4 + k, z0 - 1, x0 + w - k, y + 4 + k, z0 + d, roof);
        }
        // Puerta
        int dx, dz;
        switch (door) {
            case NORTH -> { dx = x0 + w / 2; dz = z0; }
            case SOUTH -> { dx = x0 + w / 2; dz = z0 + d - 1; }
            case WEST -> { dx = x0; dz = z0 + d / 2; }
            default -> { dx = x0 + w - 1; dz = z0 + d / 2; }
        }
        BlockState doorState = p.door().defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, door.getOpposite());
        b.set(dx, y, dz, doorState.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER));
        b.set(dx, y + 1, dz, doorState.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.UPPER));
        b.set(dx + door.getStepX(), y - 1, dz + door.getStepZ(), Blocks.DIRT_PATH);
        b.set(x0 + w / 2, y + 3, z0 + d / 2, Blocks.LANTERN.defaultBlockState().setValue(BlockStateProperties.HANGING, true));

        int ax = x0 + 1, bx = x0 + w - 2, az = z0 + 1, bz = z0 + d - 2;
        switch (kind) {
            case CASA -> {
                BlockState bed = Blocks.WHITE_BED.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH);
                b.set(ax, y, az, bed.setValue(BlockStateProperties.BED_PART, BedPart.HEAD));
                b.set(ax, y, az + 1, bed.setValue(BlockStateProperties.BED_PART, BedPart.FOOT));
                b.set(bx, y, az, Blocks.CRAFTING_TABLE);
                b.set(bx, y, bz, Blocks.FURNACE);
                b.set(ax, y, bz, Blocks.CHEST);
                if (b.level.getBlockEntity(b.at(ax, y, bz)) instanceof ChestBlockEntity ch)
                    ch.setLootTable(BuiltInLootTables.VILLAGE_PLAINS_HOUSE, r.nextLong());
            }
            case TABERNA -> {
                for (int x = ax + 1; x < bx; x += 3) {
                    b.set(x, y, z0 + d / 2, Blocks.OAK_FENCE);
                    b.set(x, y + 1, z0 + d / 2, Blocks.OAK_PRESSURE_PLATE);
                }
                b.fill(ax, y, az, bx, y, az, Blocks.BARREL);
                b.set(bx, y, bz, Blocks.SMOKER);
            }
            case HERRERIA -> {
                b.set(ax, y, az, Blocks.ANVIL);
                b.set(ax + 1, y, az, Blocks.BLAST_FURNACE);
                b.set(bx, y, az, Blocks.LAVA_CAULDRON);
                b.set(bx, y, bz, Blocks.GRINDSTONE);
                b.set(ax, y, bz, Blocks.SMITHING_TABLE);
            }
            case TEMPLO -> {
                b.set(ax, y, az, Blocks.BREWING_STAND);
                b.set(bx, y, az, Blocks.ENCHANTING_TABLE);
                b.set(bx, y, bz, Blocks.CAULDRON);
                b.set(ax, y, bz, Blocks.BELL);
            }
            case AYUNTAMIENTO -> {
                b.set(ax, y, az, Blocks.CARTOGRAPHY_TABLE);
                b.set(bx, y, az, Blocks.LECTERN);
                b.fill(ax, y, bz, bx, y, bz, Blocks.BOOKSHELF);
            }
            case BIBLIOTECA -> {
                for (int yy = y; yy <= y + 2; yy++) {
                    b.fill(ax, yy, az, bx, yy, az, Blocks.BOOKSHELF);
                    b.fill(ax, yy, bz, bx, yy, bz, Blocks.BOOKSHELF);
                }
                b.set(x0 + w / 2, y, z0 + d / 2 + 1, Blocks.LECTERN);
            }
            case JOYERIA -> {
                b.set(ax, y, az, Blocks.AMETHYST_CLUSTER);
                b.set(bx, y, az, Blocks.EMERALD_BLOCK);
                b.set(ax, y, bz, Blocks.GOLD_BLOCK);
                b.set(bx, y, bz, Blocks.BARREL);
            }
        }
    }

    private static void well(Builder b) {
        b.fill(-1, -2, -1, 1, 0, 1, Blocks.COBBLESTONE);
        b.set(0, -2, 0, Blocks.WATER);
        b.set(0, -1, 0, Blocks.WATER);
        b.set(0, 0, 0, Blocks.WATER);
        for (int[] k : new int[][]{{-1, -1}, {1, -1}, {-1, 1}, {1, 1}}) b.fill(k[0], 1, k[1], k[0], 2, k[1], Blocks.OAK_FENCE);
        b.fill(-1, 3, -1, 1, 3, 1, Blocks.COBBLESTONE_SLAB);
    }

    private static void lamp(Builder b, int x, int z) {
        b.fill(x, 0, z, x, 2, z, Blocks.OAK_FENCE);
        b.set(x, 3, z, Blocks.LANTERN);
    }

    private static void stall(Builder b, int cx, int cz, Block wool) {
        for (int[] k : new int[][]{{-1, -1}, {1, -1}, {-1, 1}, {1, 1}}) b.fill(cx + k[0], 0, cz + k[1], cx + k[0], 1, cz + k[1], Blocks.OAK_FENCE);
        b.fill(cx - 1, 2, cz - 1, cx + 1, 2, cz + 1, wool);
        b.set(cx, 0, cz, Blocks.BARREL);
    }

    private static void farm(Builder b, int x0, int z0) {
        for (int x = 0; x < 9; x++)
            for (int z = 0; z < 9; z++) {
                if (x == 4 && z == 4) {
                    b.set(x0 + x, -1, z0 + z, Blocks.WATER);
                    continue;
                }
                b.set(x0 + x, -1, z0 + z, Blocks.FARMLAND);
                b.set(x0 + x, 0, z0 + z, Blocks.WHEAT.defaultBlockState().setValue(CropBlock.AGE, 7));
            }
    }

    private static void spawnTraders(ServerLevel level, List<Spawn> spots, RandomSource r, int radius) {
        for (Spawn s : spots) {
            TraderEntity t = ModEntities.COMERCIANTE.get().create(level);
            if (t == null) continue;
            t.setProfession(s.profession());
            t.moveTo(s.pos().getX() + 0.5, s.pos().getY(), s.pos().getZ() + 0.5, r.nextFloat() * 360, 0);
            t.setHome(s.pos(), radius);
            t.setCustomName(Component.literal(NAMES[r.nextInt(NAMES.length)] + " · " + s.profession().title).withStyle(ChatFormatting.GREEN));
            t.setCustomNameVisible(true);
            level.addFreshEntity(t);
        }
    }

    private TownBuilder() {}
}
