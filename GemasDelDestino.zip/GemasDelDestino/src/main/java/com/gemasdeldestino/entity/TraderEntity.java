package com.gemasdeldestino.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.LookAtTradingPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TradeWithPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Comerciante de pueblos y ciudades. Cada oficio vende y compra cosas distintas a cambio de esmeraldas.
 */
public class TraderEntity extends AbstractVillager {

    public enum Profession {
        HERRERO("Herrero"), ARMERO("Armero"), ALQUIMISTA("Alquimista"), GRANJERO("Granjero"),
        CARTOGRAFO("Cartógrafo"), JOYERO("Joyero"), TABERNERO("Tabernero"), BIBLIOTECARIO("Bibliotecario");

        public final String title;

        Profession(String title) {
            this.title = title;
        }

        public String texture() {
            return name().toLowerCase();
        }
    }

    private static final EntityDataAccessor<Integer> PROFESSION =
            SynchedEntityData.defineId(TraderEntity.class, EntityDataSerializers.INT);
    private BlockPos home = null;

    public TraderEntity(EntityType<? extends TraderEntity> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20.0D).add(Attributes.MOVEMENT_SPEED, 0.5D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PROFESSION, 0);
    }

    public Profession getProfession() {
        Profession[] v = Profession.values();
        return v[Math.max(0, Math.min(v.length - 1, entityData.get(PROFESSION)))];
    }

    public void setProfession(Profession p) {
        entityData.set(PROFESSION, p.ordinal());
    }

    public void setHome(BlockPos pos, int radius) {
        this.home = pos;
        restrictTo(pos, radius);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new TradeWithPlayerGoal(this));
        this.goalSelector.addGoal(1, new LookAtTradingPlayerGoal(this));
        this.goalSelector.addGoal(2, new MoveTowardsRestrictionGoal(this, 0.5D));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.35D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.isAlive() && !this.isTrading()) {
            if (hand == InteractionHand.MAIN_HAND) player.awardStat(Stats.TALKED_TO_VILLAGER);
            if (!this.level().isClientSide && !this.getOffers().isEmpty()) {
                this.setTradingPlayer(player);
                this.openTradingScreen(player, this.getDisplayName(), 1);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------------ Tratos
    private static ItemStack em(int n) {
        return new ItemStack(Items.EMERALD, n);
    }

    private static ItemStack it(Item item, int n) {
        return new ItemStack(item, n);
    }

    private static ItemStack potion(Item base, Potion p) {
        return PotionUtils.setPotion(new ItemStack(base), p);
    }

    private static ItemStack book(Enchantment e, int lvl) {
        return EnchantedBookItem.createForEnchantment(new EnchantmentInstance(e, lvl));
    }

    private static void sell(MerchantOffers o, int price, ItemStack result) {
        o.add(new MerchantOffer(em(price), result, 9999, 2, 0.05F));
    }

    private static void buy(MerchantOffers o, ItemStack cost, int emeralds) {
        o.add(new MerchantOffer(cost, em(emeralds), 9999, 2, 0.05F));
    }

    @Override
    protected void updateTrades() {
        MerchantOffers o = this.getOffers();
        switch (getProfession()) {
            case HERRERO -> {
                buy(o, it(Items.IRON_INGOT, 6), 1);
                buy(o, it(Items.COAL, 15), 1);
                sell(o, 3, it(Items.IRON_SWORD, 1));
                sell(o, 3, it(Items.IRON_PICKAXE, 1));
                sell(o, 3, it(Items.IRON_AXE, 1));
                sell(o, 4, it(Items.SHIELD, 1));
                sell(o, 3, it(Items.BOW, 1));
                sell(o, 4, it(Items.CROSSBOW, 1));
                sell(o, 1, it(Items.ARROW, 16));
                sell(o, 16, it(Items.DIAMOND_SWORD, 1));
                sell(o, 18, it(Items.DIAMOND_PICKAXE, 1));
            }
            case ARMERO -> {
                buy(o, it(Items.LEATHER, 6), 1);
                buy(o, it(Items.IRON_INGOT, 6), 1);
                sell(o, 4, it(Items.IRON_HELMET, 1));
                sell(o, 7, it(Items.IRON_CHESTPLATE, 1));
                sell(o, 6, it(Items.IRON_LEGGINGS, 1));
                sell(o, 3, it(Items.IRON_BOOTS, 1));
                sell(o, 14, it(Items.DIAMOND_HELMET, 1));
                sell(o, 24, it(Items.DIAMOND_CHESTPLATE, 1));
                sell(o, 20, it(Items.DIAMOND_LEGGINGS, 1));
                sell(o, 12, it(Items.DIAMOND_BOOTS, 1));
            }
            case ALQUIMISTA -> {
                buy(o, it(Items.ROTTEN_FLESH, 24), 1);
                buy(o, it(Items.SPIDER_EYE, 8), 1);
                buy(o, it(Items.GUNPOWDER, 8), 1);
                sell(o, 3, potion(Items.POTION, Potions.HEALING));
                sell(o, 6, potion(Items.POTION, Potions.STRONG_HEALING));
                sell(o, 5, potion(Items.SPLASH_POTION, Potions.HEALING));
                sell(o, 5, potion(Items.POTION, Potions.REGENERATION));
                sell(o, 6, potion(Items.POTION, Potions.STRENGTH));
                sell(o, 4, potion(Items.POTION, Potions.FIRE_RESISTANCE));
                sell(o, 3, potion(Items.POTION, Potions.NIGHT_VISION));
                sell(o, 4, potion(Items.POTION, Potions.SWIFTNESS));
                sell(o, 2, it(Items.BLAZE_POWDER, 2));
            }
            case GRANJERO -> {
                buy(o, it(Items.WHEAT, 20), 1);
                buy(o, it(Items.CARROT, 20), 1);
                buy(o, it(Items.POTATO, 20), 1);
                buy(o, it(Items.PUMPKIN, 6), 1);
                sell(o, 1, it(Items.BREAD, 6));
                sell(o, 1, it(Items.COOKED_BEEF, 4));
                sell(o, 1, it(Items.BAKED_POTATO, 8));
                sell(o, 3, it(Items.GOLDEN_CARROT, 4));
                sell(o, 2, it(Items.CAKE, 1));
            }
            case CARTOGRAFO -> {
                buy(o, it(Items.PAPER, 24), 1);
                buy(o, it(Items.GLASS_PANE, 11), 1);
                sell(o, 2, it(Items.COMPASS, 1));
                sell(o, 2, it(Items.MAP, 1));
                sell(o, 3, it(Items.CLOCK, 1));
                sell(o, 4, it(Items.SPYGLASS, 1));
                sell(o, 6, it(Items.RECOVERY_COMPASS, 1));
            }
            case JOYERO -> {
                buy(o, it(Items.DIAMOND, 1), 5);
                buy(o, it(Items.GOLD_INGOT, 3), 1);
                buy(o, it(Items.LAPIS_LAZULI, 12), 1);
                buy(o, it(Items.AMETHYST_SHARD, 6), 1);
                sell(o, 4, it(Items.ENDER_PEARL, 1));
                sell(o, 8, it(Items.GOLDEN_APPLE, 1));
                sell(o, 40, it(Items.TOTEM_OF_UNDYING, 1));
                sell(o, 12, book(Enchantments.SHARPNESS, 3));
                sell(o, 12, book(Enchantments.ALL_DAMAGE_PROTECTION, 3));
                sell(o, 10, book(Enchantments.UNBREAKING, 3));
                sell(o, 8, book(Enchantments.FALL_PROTECTION, 4));
                sell(o, 10, book(Enchantments.POWER_ARROWS, 3));
                sell(o, 30, book(Enchantments.MENDING, 1));
            }
            case TABERNERO -> {
                buy(o, it(Items.STRING, 14), 1);
                buy(o, it(Items.SUGAR_CANE, 20), 1);
                buy(o, it(Items.BONE, 16), 1);
                sell(o, 1, it(Items.HONEY_BOTTLE, 2));
                sell(o, 1, it(Items.COOKIE, 8));
                sell(o, 1, it(Items.PUMPKIN_PIE, 2));
                sell(o, 2, it(Items.RABBIT_STEW, 1));
                sell(o, 1, it(Items.FEATHER, 6));
            }
            case BIBLIOTECARIO -> {
                buy(o, it(Items.BOOK, 4), 1);
                buy(o, it(Items.INK_SAC, 5), 1);
                sell(o, 3, it(Items.EXPERIENCE_BOTTLE, 2));
                sell(o, 6, it(Items.BOOKSHELF, 1));
                sell(o, 10, it(Items.NAME_TAG, 1));
                sell(o, 1, it(Items.LANTERN, 1));
                sell(o, 9, book(Enchantments.BLOCK_EFFICIENCY, 3));
                sell(o, 9, book(Enchantments.FIRE_PROTECTION, 3));
            }
        }
    }

    @Override
    protected void rewardTradeXp(MerchantOffer offer) {
        if (offer.shouldRewardExp()) {
            int xp = 3 + this.random.nextInt(4);
            this.level().addFreshEntity(new ExperienceOrb(this.level(), getX(), getY() + 0.5D, getZ(), xp));
        }
    }

    @Override
    public boolean showProgressBar() {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        return null;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Oficio", entityData.get(PROFESSION));
        if (home != null) tag.putLong("Casa", home.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(PROFESSION, tag.getInt("Oficio"));
        if (tag.contains("Casa")) setHome(BlockPos.of(tag.getLong("Casa")), 12);
    }
}
