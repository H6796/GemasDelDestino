package com.gemasdeldestino.entity;

import com.gemasdeldestino.registry.ModEntities;
import com.gemasdeldestino.story.StoryData;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * NPC del campamento: Eldric, Lyra, Bram y Silas (el traidor infiltrado).
 * Son invulnerables, no se mueven y hablan con clic derecho.
 */
public class NpcEntity extends PathfinderMob {

    public enum Role { ELDRIC, LYRA, BRAM, SILAS, ANCIANO }

    /** Para los ancianos: índice del pueblo (capítulo) al que pertenecen. */
    private int village = 0;

    public int getVillage() {
        return village;
    }

    public void setVillage(int v) {
        this.village = v;
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Pueblo", village);
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        village = tag.getInt("Pueblo");
    }

    public NpcEntity(EntityType<? extends NpcEntity> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D);
    }

    public Role getRole() {
        EntityType<?> t = getType();
        if (t == ModEntities.ELDRIC.get()) return Role.ELDRIC;
        if (t == ModEntities.LYRA.get()) return Role.LYRA;
        if (t == ModEntities.BRAM.get()) return Role.BRAM;
        if (t == ModEntities.ANCIANO.get()) return Role.ANCIANO;
        return Role.SILAS;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 10.0F, 1.0F));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            StoryManager.onNpcInteract(sp, this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void tick() {
        super.tick();
        // Pista sutil: cuantas más gemas recibe Silas, más se nota la energía oscura a su alrededor.
        if (!level().isClientSide && getRole() == Role.SILAS && tickCount % 10 == 0 && level() instanceof ServerLevel sl) {
            int gems = StoryData.get(sl.getServer()).gemsDelivered;
            if (gems >= 2 && random.nextInt(6 - Math.min(gems, 5)) == 0) {
                sl.sendParticles(gems >= 4 ? ParticleTypes.REVERSE_PORTAL : ParticleTypes.SMOKE,
                        getX(), getY() + 1.0, getZ(), gems, 0.3, 0.6, 0.3, 0.01);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void doPush(net.minecraft.world.entity.Entity entity) {
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean requiresCustomPersistence() {
        return true;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }
}
