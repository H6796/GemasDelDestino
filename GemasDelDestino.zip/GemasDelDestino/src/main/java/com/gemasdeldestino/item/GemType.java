package com.gemasdeldestino.item;

import com.gemasdeldestino.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * Las ocho Gemas del Destino y el aspecto de la base secreta donde se esconde cada una.
 */
public enum GemType {
    FUEGO("Gema de Fuego", "Templo de Ceniza", ChatFormatting.RED, 0xFF5A2A, 40,
            Blocks.NETHER_BRICKS, Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.GILDED_BLACKSTONE, Blocks.SHROOMLIGHT,
            Blocks.RED_CARPET, Blocks.CRIMSON_TRAPDOOR, EntityType.MAGMA_CUBE, EntityType.BLAZE, 3),
    TORMENTA("Gema de la Tormenta", "Cámara de las Tormentas", ChatFormatting.AQUA, 0x4FD8FF, 80,
            Blocks.DEEPSLATE_TILES, Blocks.CUT_COPPER, Blocks.OXIDIZED_COPPER, Blocks.SEA_LANTERN,
            Blocks.CYAN_CARPET, Blocks.SPRUCE_TRAPDOOR, EntityType.CREEPER, EntityType.WITCH, 2),
    VIENTO("Gema del Viento", "Santuario del Viento", ChatFormatting.WHITE, 0xDDFFF4, 30,
            Blocks.QUARTZ_BRICKS, Blocks.SMOOTH_QUARTZ, Blocks.CALCITE, Blocks.GLOWSTONE,
            Blocks.WHITE_CARPET, Blocks.BIRCH_TRAPDOOR, EntityType.SKELETON, EntityType.PHANTOM, 3),
    TIERRA("Gema de la Tierra", "Cripta de la Tierra", ChatFormatting.GREEN, 0x5BC236, 60,
            Blocks.MOSSY_STONE_BRICKS, Blocks.PACKED_MUD, Blocks.MOSS_BLOCK, Blocks.OCHRE_FROGLIGHT,
            Blocks.GREEN_CARPET, Blocks.OAK_TRAPDOOR, EntityType.ZOMBIE, EntityType.VINDICATOR, 2),
    HIELO("Gema del Hielo", "Glaciar Eterno", ChatFormatting.BLUE, 0x9FE7FF, 60,
            Blocks.PACKED_ICE, Blocks.SNOW_BLOCK, Blocks.BLUE_ICE, Blocks.SEA_LANTERN,
            Blocks.LIGHT_BLUE_CARPET, Blocks.SPRUCE_TRAPDOOR, EntityType.STRAY, EntityType.PILLAGER, 3),
    LUZ("Gema de la Luz", "Catedral de la Luz", ChatFormatting.YELLOW, 0xFFF27A, 100,
            Blocks.QUARTZ_BLOCK, Blocks.GOLD_BLOCK, Blocks.CHISELED_QUARTZ_BLOCK, Blocks.GLOWSTONE,
            Blocks.YELLOW_CARPET, Blocks.BIRCH_TRAPDOOR, EntityType.HUSK, EntityType.EVOKER, 2),
    TIEMPO("Gema del Tiempo", "Relojería Olvidada", ChatFormatting.DARK_AQUA, 0x2EC4A6, 120,
            Blocks.PRISMARINE_BRICKS, Blocks.DARK_PRISMARINE, Blocks.PRISMARINE, Blocks.SEA_LANTERN,
            Blocks.CYAN_CARPET, Blocks.WARPED_TRAPDOOR, EntityType.WITHER_SKELETON, EntityType.RAVAGER, 1),
    VACIO("Gema del Vacío", "Abismo del Vacío", ChatFormatting.DARK_PURPLE, 0x9B4DFF, 50,
            Blocks.OBSIDIAN, Blocks.END_STONE_BRICKS, Blocks.CRYING_OBSIDIAN, Blocks.PEARLESCENT_FROGLIGHT,
            Blocks.PURPLE_CARPET, Blocks.DARK_OAK_TRAPDOOR, EntityType.ENDERMITE, EntityType.VEX, 3);

    public final String gemName;
    public final String baseName;
    public final ChatFormatting color;
    public final int rgb;
    public final int cooldown;
    public final Block wall, floor, accent, light, carpet, trapdoor;
    public final EntityType<?> spawnerMob;
    public final EntityType<?> guardian;
    public final int guardianCount;

    GemType(String gemName, String baseName, ChatFormatting color, int rgb, int cooldown,
            Block wall, Block floor, Block accent, Block light, Block carpet, Block trapdoor,
            EntityType<?> spawnerMob, EntityType<?> guardian, int guardianCount) {
        this.gemName = gemName;
        this.baseName = baseName;
        this.color = color;
        this.rgb = rgb;
        this.cooldown = cooldown;
        this.wall = wall;
        this.floor = floor;
        this.accent = accent;
        this.light = light;
        this.carpet = carpet;
        this.trapdoor = trapdoor;
        this.spawnerMob = spawnerMob;
        this.guardian = guardian;
        this.guardianCount = guardianCount;
    }

    public Item item() {
        return switch (this) {
            case FUEGO -> ModItems.GEMA_FUEGO.get();
            case TORMENTA -> ModItems.GEMA_TORMENTA.get();
            case VIENTO -> ModItems.GEMA_VIENTO.get();
            case TIERRA -> ModItems.GEMA_TIERRA.get();
            case HIELO -> ModItems.GEMA_HIELO.get();
            case LUZ -> ModItems.GEMA_LUZ.get();
            case TIEMPO -> ModItems.GEMA_TIEMPO.get();
            case VACIO -> ModItems.GEMA_VACIO.get();
        };
    }

    /** Muro irrompible de la mazmorra de esta gema. */
    public Block dungeonWall() {
        return switch (this) {
            case FUEGO -> com.gemasdeldestino.registry.ModBlocks.MURO_FUEGO.get();
            case TORMENTA -> com.gemasdeldestino.registry.ModBlocks.MURO_TORMENTA.get();
            case VIENTO -> com.gemasdeldestino.registry.ModBlocks.MURO_VIENTO.get();
            case TIERRA -> com.gemasdeldestino.registry.ModBlocks.MURO_TIERRA.get();
            case HIELO -> com.gemasdeldestino.registry.ModBlocks.MURO_HIELO.get();
            case LUZ -> com.gemasdeldestino.registry.ModBlocks.MURO_LUZ.get();
            case TIEMPO -> com.gemasdeldestino.registry.ModBlocks.MURO_TIEMPO.get();
            case VACIO -> com.gemasdeldestino.registry.ModBlocks.MURO_VACIO.get();
        };
    }

    /** Suelo irrompible de la mazmorra de esta gema. */
    public Block dungeonFloor() {
        return switch (this) {
            case FUEGO -> com.gemasdeldestino.registry.ModBlocks.SUELO_FUEGO.get();
            case TORMENTA -> com.gemasdeldestino.registry.ModBlocks.SUELO_TORMENTA.get();
            case VIENTO -> com.gemasdeldestino.registry.ModBlocks.SUELO_VIENTO.get();
            case TIERRA -> com.gemasdeldestino.registry.ModBlocks.SUELO_TIERRA.get();
            case HIELO -> com.gemasdeldestino.registry.ModBlocks.SUELO_HIELO.get();
            case LUZ -> com.gemasdeldestino.registry.ModBlocks.SUELO_LUZ.get();
            case TIEMPO -> com.gemasdeldestino.registry.ModBlocks.SUELO_TIEMPO.get();
            case VACIO -> com.gemasdeldestino.registry.ModBlocks.SUELO_VACIO.get();
        };
    }

    /** Segundo tipo de monstruo para los generadores de la mazmorra. */
    public EntityType<?> secondMob() {
        return switch (this) {
            case FUEGO -> EntityType.SKELETON;
            case TORMENTA -> EntityType.SPIDER;
            case VIENTO -> EntityType.STRAY;
            case TIERRA -> EntityType.CAVE_SPIDER;
            case HIELO -> EntityType.SKELETON;
            case LUZ -> EntityType.ZOMBIE_VILLAGER;
            case TIEMPO -> EntityType.EVOKER;
            case VACIO -> EntityType.ENDERMAN;
        };
    }

    public net.minecraft.resources.ResourceLocation treasureLoot() {
        return switch (this) {
            case FUEGO -> net.minecraft.world.level.storage.loot.BuiltInLootTables.DESERT_PYRAMID;
            case TORMENTA -> net.minecraft.world.level.storage.loot.BuiltInLootTables.SHIPWRECK_TREASURE;
            case VIENTO -> net.minecraft.world.level.storage.loot.BuiltInLootTables.JUNGLE_TEMPLE;
            case TIERRA -> net.minecraft.world.level.storage.loot.BuiltInLootTables.BASTION_TREASURE;
            case HIELO -> net.minecraft.world.level.storage.loot.BuiltInLootTables.IGLOO_CHEST;
            case LUZ -> net.minecraft.world.level.storage.loot.BuiltInLootTables.WOODLAND_MANSION;
            case TIEMPO -> net.minecraft.world.level.storage.loot.BuiltInLootTables.ANCIENT_CITY;
            case VACIO -> net.minecraft.world.level.storage.loot.BuiltInLootTables.END_CITY_TREASURE;
        };
    }

    public String bossName() {
        return switch (this) {
            case FUEGO -> "Ignar, Guardián de Ceniza";
            case TORMENTA -> "Voltra, la Tempestad";
            case VIENTO -> "Zéfir, el Vendaval";
            case TIERRA -> "Gorrak, el Coloso de Piedra";
            case HIELO -> "Nivalis, la Reina de Escarcha";
            case LUZ -> "Solenne, el Ángel Caído";
            case TIEMPO -> "Kronos, el Relojero Eterno";
            case VACIO -> "Nyx, la Sombra del Vacío";
        };
    }

    public net.minecraft.world.BossEvent.BossBarColor barColor() {
        return switch (this) {
            case FUEGO -> net.minecraft.world.BossEvent.BossBarColor.RED;
            case TORMENTA -> net.minecraft.world.BossEvent.BossBarColor.BLUE;
            case VIENTO -> net.minecraft.world.BossEvent.BossBarColor.WHITE;
            case TIERRA -> net.minecraft.world.BossEvent.BossBarColor.GREEN;
            case HIELO -> net.minecraft.world.BossEvent.BossBarColor.BLUE;
            case LUZ -> net.minecraft.world.BossEvent.BossBarColor.YELLOW;
            case TIEMPO -> net.minecraft.world.BossEvent.BossBarColor.PINK;
            case VACIO -> net.minecraft.world.BossEvent.BossBarColor.PURPLE;
        };
    }

    public static GemType byIndex(int i) {
        GemType[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, i))];
    }
}
