package com.gemasdeldestino.item;

import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Mapa del Eclipse: no marca el lugar exacto. Al usarlo indica si estás "frío" o "caliente"
 * respecto a la entrada oculta de la mazmorra.
 */
public class EclipseMapItem extends Item {
    public EclipseMapItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            StoryManager.readEclipseMap(sp);
            player.getCooldowns().addCooldown(this, 20);
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Clic derecho: siente el calor de la gema escondida.").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Frío... templado... caliente... ¡ardiendo!").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC));
    }
}
