package com.gemasdeldestino.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Una Gema del Destino. Clic derecho = poder activo. Llevarla encima = poder pasivo.
 */
public class GemItem extends Item {
    private final GemType type;

    public GemItem(GemType type, Properties props) {
        super(props);
        this.type = type;
    }

    public GemType getGemType() {
        return type;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel server) {
            if (activate(server, player)) {
                player.getCooldowns().addCooldown(this, type.cooldown);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Ejecuta el poder activo de la gema. Devuelve true si se ha usado. */
    private boolean activate(ServerLevel level, Player player) {
        Vec3 look = player.getLookAngle();
        switch (type) {
            case FUEGO -> {
                // Tres bolas de fuego en abanico
                for (int i = -1; i <= 1; i++) {
                    Vec3 dir = look.yRot((float) Math.toRadians(i * 8));
                    SmallFireball fb = new SmallFireball(level, player, dir.x, dir.y, dir.z);
                    fb.setPos(player.getX() + dir.x, player.getEyeY() - 0.1 + dir.y, player.getZ() + dir.z);
                    level.addFreshEntity(fb);
                }
                level.playSound(null, player.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
                return true;
            }
            case TORMENTA -> {
                HitResult hit = player.pick(48.0D, 1.0F, false);
                if (hit.getType() == HitResult.Type.MISS) {
                    player.displayClientMessage(Component.literal("Apunta a un bloque cercano.").withStyle(ChatFormatting.GRAY), true);
                    return false;
                }
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                if (bolt == null) return false;
                bolt.moveTo(hit.getLocation());
                if (player instanceof ServerPlayer sp) bolt.setCause(sp);
                level.addFreshEntity(bolt);
                return true;
            }
            case VIENTO -> {
                player.setDeltaMovement(look.x * 1.8D, Math.max(0.9D, look.y * 1.5D + 0.6D), look.z * 1.8D);
                player.hurtMarked = true;
                player.fallDistance = 0;
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 80, 0, false, false, true));
                level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(), 30, 0.6, 0.2, 0.6, 0.05);
                level.playSound(null, player.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 1.0F, 1.4F);
                return true;
            }
            case TIERRA -> {
                AABB area = player.getBoundingBox().inflate(7.0D, 3.0D, 7.0D);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive())) {
                    e.hurt(level.damageSources().playerAttack(player), 8.0F);
                    e.knockback(1.6D, player.getX() - e.getX(), player.getZ() - e.getZ());
                    e.setDeltaMovement(e.getDeltaMovement().add(0, 0.5D, 0));
                }
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()),
                        player.getX(), player.getY() + 0.2, player.getZ(), 120, 3.0, 0.2, 3.0, 0.2);
                level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8F, 0.6F);
                return true;
            }
            case HIELO -> {
                AABB area = player.getBoundingBox().inflate(8.0D, 3.0D, 8.0D);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive())) {
                    e.hurt(level.damageSources().freeze(), 5.0F);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 4));
                    e.setTicksFrozen(200);
                }
                level.sendParticles(ParticleTypes.SNOWFLAKE, player.getX(), player.getY() + 1, player.getZ(), 150, 4.0, 1.0, 4.0, 0.05);
                level.playSound(null, player.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.0F, 0.5F);
                return true;
            }
            case LUZ -> {
                AABB area = player.getBoundingBox().inflate(10.0D);
                for (Player ally : level.getEntitiesOfClass(Player.class, area)) {
                    ally.heal(8.0F);
                    ally.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
                }
                for (net.minecraft.world.entity.monster.Monster m : level.getEntitiesOfClass(net.minecraft.world.entity.monster.Monster.class, area)) {
                    m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
                    m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
                    if (m.isInvertedHealAndHarm()) m.hurt(level.damageSources().magic(), 10.0F);
                }
                level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1, player.getZ(), 100, 3.0, 1.5, 3.0, 0.05);
                level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0F, 1.5F);
                return true;
            }
            case TIEMPO -> {
                AABB area = player.getBoundingBox().inflate(14.0D);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && !(e instanceof Player))) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 6));
                    e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 160, 3));
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 1));
                }
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 2));
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 160, 2));
                level.sendParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1, player.getZ(), 200, 6.0, 2.0, 6.0, 0.5);
                level.playSound(null, player.blockPosition(), SoundEvents.BELL_RESONATE, SoundSource.PLAYERS, 1.0F, 0.7F);
                return true;
            }
            case VACIO -> {
                HitResult hit = player.pick(40.0D, 1.0F, false);
                if (!(hit instanceof BlockHitResult bhr) || hit.getType() == HitResult.Type.MISS) {
                    player.displayClientMessage(Component.literal("El Vacío necesita un destino sólido.").withStyle(ChatFormatting.GRAY), true);
                    return false;
                }
                BlockPos target = bhr.getBlockPos().relative(bhr.getDirection());
                level.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 60, 0.4, 0.8, 0.4, 0.3);
                player.teleportTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D);
                player.fallDistance = 0;
                level.playSound(null, target, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
                return true;
            }
        }
        return false;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player player) || player.tickCount % 40 != 0) return;
        MobEffectInstance passive = switch (type) {
            case FUEGO -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 80, 0, true, false, true);
            case TORMENTA -> new MobEffectInstance(MobEffects.DIG_SPEED, 80, 0, true, false, true);
            case VIENTO -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 0, true, false, true);
            case TIERRA -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 80, 0, true, false, true);
            case HIELO -> new MobEffectInstance(MobEffects.WATER_BREATHING, 80, 0, true, false, true);
            case LUZ -> new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false, true);
            case TIEMPO -> new MobEffectInstance(MobEffects.JUMP, 80, 1, true, false, true);
            case VACIO -> new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0, true, false, true);
        };
        player.addEffect(passive);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.literal(type.gemName).withStyle(type.color, ChatFormatting.BOLD);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        String active = switch (type) {
            case FUEGO -> "Clic derecho: lanza tres bolas de fuego.";
            case TORMENTA -> "Clic derecho: invoca un rayo donde miras.";
            case VIENTO -> "Clic derecho: impulso de viento + caída lenta.";
            case TIERRA -> "Clic derecho: onda sísmica que golpea a los enemigos.";
            case HIELO -> "Clic derecho: congela a todos los enemigos cercanos.";
            case LUZ -> "Clic derecho: cura al grupo y debilita a los monstruos.";
            case TIEMPO -> "Clic derecho: ralentiza el tiempo a tu alrededor.";
            case VACIO -> "Clic derecho: teletransporte a donde miras.";
        };
        String passive = switch (type) {
            case FUEGO -> "Pasivo: resistencia al fuego.";
            case TORMENTA -> "Pasivo: prisa minera.";
            case VIENTO -> "Pasivo: velocidad.";
            case TIERRA -> "Pasivo: resistencia.";
            case HIELO -> "Pasivo: respiración acuática.";
            case LUZ -> "Pasivo: regeneración.";
            case TIEMPO -> "Pasivo: salto mejorado.";
            case VACIO -> "Pasivo: visión nocturna.";
        };
        tooltip.add(Component.literal(active).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal(passive).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.literal("Una de las ocho Gemas del Destino.").withStyle(ChatFormatting.ITALIC, type.color));
    }
}
