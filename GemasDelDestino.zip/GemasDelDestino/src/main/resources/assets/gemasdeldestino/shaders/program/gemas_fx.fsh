#version 150

// Shader de "Las Gemas del Destino".
// Modos: 0 = épico (general), 1 = cinemática, 2 = mazmorra, 3 = eclipse (fortaleza y jefes).

uniform sampler2D DiffuseSampler;
uniform vec2 InSize;
uniform float Time;
uniform float Mode;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

// Resplandor (bloom) barato: media de las zonas brillantes alrededor del píxel.
vec3 bloom(vec2 uv) {
    vec3 acc = vec3(0.0);
    float total = 0.0;
    for (int i = 0; i < 12; i++) {
        float a = float(i) * 0.5235988;
        vec2 dir = vec2(cos(a), sin(a));
        for (int r = 1; r <= 3; r++) {
            vec2 off = dir * oneTexel * float(r) * 3.5;
            vec3 c = texture(DiffuseSampler, uv + off).rgb;
            float bright = max(max(c.r, c.g), c.b);
            float weight = 1.0 / float(r);
            acc += c * smoothstep(0.62, 1.0, bright) * weight;
            total += weight;
        }
    }
    return acc / total;
}

void main() {
    int mode = int(Mode + 0.5);
    vec2 uv = texCoord;
    float pulse = 0.5 + 0.5 * sin(Time * 6.2831853);

    // Ondas de calor en el modo eclipse
    if (mode == 3) {
        uv.x += sin(uv.y * 38.0 + Time * 12.566370) * 0.0011;
        uv.y += cos(uv.x * 31.0 + Time * 6.2831853) * 0.0007;
    }

    // Aberración cromática en los bordes
    vec2 fromCenter = uv - vec2(0.5);
    float aberration = mode == 1 ? 1.2 : (mode == 3 ? 1.5 + 2.5 * pulse : (mode == 2 ? 0.6 : 0.0));
    vec3 col;
    if (aberration > 0.0) {
        vec2 o = fromCenter * oneTexel * aberration * 4.0;
        col.r = texture(DiffuseSampler, uv + o).r;
        col.g = texture(DiffuseSampler, uv).g;
        col.b = texture(DiffuseSampler, uv - o).b;
    } else {
        col = texture(DiffuseSampler, uv).rgb;
    }

    // Bloom
    float bloomAmount = mode == 0 ? 0.35 : (mode == 1 ? 0.55 : (mode == 2 ? 0.75 : 0.6));
    col += bloom(uv) * bloomAmount;

    // Etalonaje de color
    float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
    vec3 tint;
    float saturation;
    float contrast;
    if (mode == 0) {
        tint = mix(vec3(0.97, 1.0, 1.06), vec3(1.06, 1.0, 0.92), smoothstep(0.25, 0.85, luma));
        saturation = 1.18;
        contrast = 1.08;
    } else if (mode == 1) {
        // Look de película: sombras azul verdoso, luces anaranjadas
        tint = mix(vec3(0.82, 1.0, 1.14), vec3(1.14, 1.0, 0.82), smoothstep(0.2, 0.8, luma));
        saturation = 1.12;
        contrast = 1.14;
    } else if (mode == 2) {
        tint = vec3(0.86, 0.97, 1.12);
        saturation = 0.82;
        contrast = 1.16;
    } else {
        tint = mix(vec3(0.9, 0.7, 1.25), vec3(1.15, 0.9, 1.1), smoothstep(0.2, 0.9, luma));
        saturation = 1.22;
        contrast = 1.2;
    }
    col = mix(vec3(luma), col, saturation) * tint;
    col = (col - 0.5) * contrast + 0.5;

    // Viñeta
    float aspect = InSize.x / max(InSize.y, 1.0);
    float dist = length(fromCenter * vec2(aspect, 1.0));
    float vignette = mode == 0 ? 0.28 : (mode == 1 ? 0.5 : (mode == 2 ? 0.68 : 0.5 + 0.2 * pulse));
    col *= 1.0 - vignette * smoothstep(0.38, 1.05, dist);

    // Aura morada que late en los bordes (eclipse)
    if (mode == 3) {
        col += vec3(0.28, 0.04, 0.4) * smoothstep(0.55, 1.1, dist) * (0.35 + 0.65 * pulse);
    }

    // Grano de película
    float grain = mode == 0 ? 0.012 : (mode == 1 ? 0.04 : 0.05);
    col += (hash(uv * InSize + vec2(Time * 917.0, Time * 433.0)) - 0.5) * grain;

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
