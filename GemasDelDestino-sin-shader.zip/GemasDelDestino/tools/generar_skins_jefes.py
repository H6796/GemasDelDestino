"""Genera las skins de los minijefes, la Quimera y Silas, su capa brillante y las texturas de aura.

Formato de skin de jugador 64x64 (brazos anchos). Para cada skin se escriben:
  <nombre>.png       la skin
  <nombre>_glow.png  solo los píxeles que brillan (ojos, runas, emblemas)
y para cada aura:
  aura_<nombre>.png  textura 64x32 para la capa de energía (se dibuja en modo aditivo)
"""
import math
import random
import sys
from PIL import Image

OUT = sys.argv[1]

# --------------------------------------------------------------------------- caras del modelo
# (x, y, ancho, alto) de cada cara: top, bottom, right, front, left, back
def box(u, v, w, h, d):
    return {
        'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d),
        'right': (u, v + d, d, h), 'front': (u + d, v + d, w, h),
        'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h),
    }

PARTS = {
    'head': (box(0, 0, 8, 8, 8), box(32, 0, 8, 8, 8)),
    'body': (box(16, 16, 8, 12, 4), box(16, 32, 8, 12, 4)),
    'rarm': (box(40, 16, 4, 12, 4), box(40, 32, 4, 12, 4)),
    'larm': (box(32, 48, 4, 12, 4), box(48, 48, 4, 12, 4)),
    'rleg': (box(0, 16, 4, 12, 4), box(0, 32, 4, 12, 4)),
    'lleg': (box(16, 48, 4, 12, 4), box(0, 48, 4, 12, 4)),
}


def hexc(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


class Skin:
    def __init__(self, seed):
        self.img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        self.glow = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        self.r = random.Random(seed)

    def px(self, x, y, c, glow=False, a=255):
        self.img.putpixel((x, y), (*c, a))
        if glow:
            self.glow.putpixel((x, y), (*c, 255))

    def face(self, part, layer, name):
        return PARTS[part][layer][name]

    def paint(self, part, layer, name, fn):
        """fn(x, y, w, h) -> None | (color, glow) | (color, glow, alpha)"""
        fx, fy, w, h = self.face(part, layer, name)
        for y in range(h):
            for x in range(w):
                res = fn(x, y, w, h)
                if res is None:
                    continue
                c, g = res[0], res[1]
                a = res[2] if len(res) > 2 else 255
                self.px(fx + x, fy + y, c, g, a)

    def noise(self, c, amount=10):
        n = self.r.randint(-amount, amount)
        return tuple(max(0, min(255, v + n)) for v in c)


# --------------------------------------------------------------------------- pintores comunes
def plate(s, t, part, name, w, h, x, y, base=None, light=1.0):
    """Placa de armadura con borde oscuro, brillo arriba y algo de ruido."""
    base = base or t['base']
    k = 1.12 - 0.25 * (y / max(1, h - 1))
    if x == 0 or x == w - 1:
        k *= 0.78
    c = shade(base, k * light)
    return s.noise(c, 7)


def paint_head(s, t):
    S = 'head'
    for f in ('top', 'bottom', 'right', 'left', 'back'):
        def fn(x, y, w, h, f=f):
            c = plate(s, t, S, f, w, h, x, y)
            if f == 'top' and x in (3, 4):
                return (s.noise(t['trim'], 6), False)
            if f in ('right', 'left', 'back') and y == 1:
                return (s.noise(t['trim'], 6), False)
            if f in ('right', 'left') and y in (3, 4) and 2 <= x <= 5:
                return (shade(t['base'], 0.55), False)
            if f == 'bottom':
                return (shade(t['dark'], 0.8), False)
            return (c, False)
        s.paint(S, 0, f, fn)

    style = t.get('face', 'helm')

    def front(x, y, w, h):
        if style == 'hood':
            # Rostro en sombra bajo la capucha
            if y <= 1 or x == 0 or x == 7:
                return (s.noise(t['base'], 6), False)
            if y == 3 and x in (2, 5):
                return (t['glow'], True)
            if y == 3 and x in (1, 6):
                return (shade(t['glow'], 0.55), True)
            if y >= 6 and 2 <= x <= 5:
                return (s.noise(t['trim'], 5), False)
            return (s.noise(shade(t['skin'], 0.55 + 0.05 * y), 4), False)
        if style == 'beast':
            if y in (2, 4) and x in (1, 2, 5, 6):
                return (t['glow'], True)
            if y == 6 and 1 <= x <= 6:
                return ((250, 250, 235) if x % 2 else (40, 10, 10), False)
            return (plate(s, t, S, 'front', w, h, x, y), False)
        # Yelmo
        if y <= 1:
            return (s.noise(t['trim'], 6), False)
        if y == 3 and x in (1, 2, 5, 6):
            return (t['glow'], True)
        if y in (2, 4) and x not in (3, 4):
            return (shade(t['dark'], 0.6), False)
        if x in (3, 4) and 2 <= y <= 6:
            return (s.noise(t['trim'], 6), False)
        if y >= 5 and x not in (3, 4):
            return (shade(t['dark'], 0.7 if (x + y) % 2 else 0.5), False)
        return (plate(s, t, S, 'front', w, h, x, y), False)
    s.paint(S, 0, 'front', front)


def paint_body(s, t):
    S = 'body'
    emblem = t.get('emblem', 'diamond')

    def front(x, y, w, h):
        cx, cy = x - 3.5, y - 3.5
        if emblem == 'diamond' and abs(cx) + abs(cy) <= 2:
            return (t['glow'] if abs(cx) + abs(cy) <= 1 else mix(t['glow'], t['trim'], 0.5), True)
        if emblem == 'eight' and 1 <= y <= 5 and 1 <= x <= 6:
            if y in (2, 4) and 2 <= x <= 5:
                return (t['gems'][(x - 2) + (0 if y == 2 else 4)], True)
            return (s.noise(t['trim'] if y in (1, 5) or x in (1, 6) else shade(t['dark'], 0.8), 5), False)
        if y == 9:
            if x in (3, 4):
                return (t['glow'], True)
            return (s.noise(t['trim'], 6), False)
        if y >= 10:
            return (s.noise(shade(t['dark'], 0.9 if x % 2 else 0.7), 5), False)
        if 6 <= y <= 8:
            return (s.noise(shade(t['base'], 0.85 if y % 2 else 0.7), 6), False)
        if y == 0:
            return (s.noise(t['trim'], 5), False)
        return (plate(s, t, S, 'front', w, h, x, y), False)
    s.paint(S, 0, 'front', front)

    def back(x, y, w, h):
        if x in (3, 4) and y <= 8:
            return (s.noise(t['trim'], 5), False)
        if y == 9:
            return (s.noise(t['trim'], 6), False)
        if y >= 10:
            return (s.noise(t['dark'], 5), False)
        return (plate(s, t, S, 'back', w, h, x, y), False)
    s.paint(S, 0, 'back', back)
    for f in ('right', 'left', 'top', 'bottom'):
        s.paint(S, 0, f, lambda x, y, w, h: ((s.noise(t['trim'], 5) if y == 9 else plate(s, t, S, f, w, h, x, y)), False))


def paint_limb(s, t, part, arm):
    for f in ('top', 'bottom', 'right', 'front', 'left', 'back'):
        def fn(x, y, w, h, f=f):
            if f == 'top':
                return (s.noise(t['trim'] if arm else t['dark'], 5), False)
            if f == 'bottom':
                return (shade(t['dark'], 0.6), False)
            if arm:
                if y <= 2:
                    return (plate(s, t, part, f, w, h, x, y, light=1.1), False)
                if y == 3:
                    return (s.noise(t['trim'], 5), False)
                if y <= 7:
                    if f == 'front' and y == 5 and x in (1, 2):
                        return (t['glow'], True)
                    return (s.noise(t['cloth'], 6), False)
                if y == 8:
                    return (s.noise(t['trim'], 5), False)
                if f == 'front' and y == 10 and x in (1, 2):
                    return (t['glow'], True)
                return (plate(s, t, part, f, w, h, x, y, base=t['dark']), False)
            # pierna
            if y <= 5:
                return (s.noise(t['cloth'], 6), False)
            if y == 6:
                if f == 'front' and x in (1, 2):
                    return (t['glow'], True)
                return (s.noise(t['trim'], 5), False)
            if y <= 9:
                return (plate(s, t, part, f, w, h, x, y), False)
            return (s.noise(shade(t['dark'], 0.75), 5), False)
        s.paint(part, 0, f, fn)


# --------------------------------------------------------------------------- capas exteriores
def overlay(s, t):
    style = t['hat']
    r = s.r

    def hat(f):
        def fn(x, y, w, h):
            if style == 'flames':
                if f == 'top':
                    if r.random() < 0.45:
                        return (r.choice([t['glow'], (255, 200, 60), (255, 120, 20)]), True)
                    return None
                height = 1 + ((x * 5 + (2 if f in ('back', 'left') else 0)) % 4)
                if y < height:
                    return ((255, 230, 110) if y == 0 else (255, 150, 30) if y < height - 1 else (220, 70, 20), True, 235)
                return None
            if style == 'bolt':
                if f == 'top' and x in (3, 4):
                    return (t['glow'], True)
                if f == 'front' and y <= 1 and x in (3, 4):
                    return (t['glow'], True)
                if f in ('right', 'left') and y == 0 and x % 2 == 0:
                    return (t['trim'], False)
                return None
            if style == 'wings':
                if f in ('right', 'left') and 1 <= y <= 5:
                    edge = (x >= 3) if f == 'right' else (x <= 4)
                    if edge and (x + y) % 2 == 0 or (edge and y <= 3):
                        return (mix((250, 250, 255), t['glow'], 0.2 * (y % 3)), False)
                if f == 'top' and (x == 0 or x == 7):
                    return ((240, 245, 255), False)
                return None
            if style == 'leaves':
                if f == 'top':
                    return ((r.choice([(70, 140, 40), (50, 110, 30), (110, 170, 60)]), False) if r.random() < 0.6 else None)
                if y <= 1 and r.random() < 0.7:
                    c = r.choice([(70, 140, 40), (50, 110, 30), (110, 170, 60)])
                    if r.random() < 0.15:
                        return ((240, 90, 120), True)
                    return (c, False)
                return None
            if style == 'crystals':
                if f == 'top' and (x + y) % 3 == 0:
                    return (mix(t['glow'], (255, 255, 255), 0.4), True)
                spike = {0: 3, 1: 1, 2: 0, 3: 2, 4: 0, 5: 1, 6: 3, 7: 2}
                if y <= 3 and y >= spike[x] and x % 2 == 0:
                    return (mix(t['glow'], (255, 255, 255), 0.3 + 0.15 * y), True, 220)
                return None
            if style == 'halo':
                if f == 'top':
                    d = max(abs(x - 3.5), abs(y - 3.5))
                    if d >= 3:
                        return ((255, 230, 120), True)
                    return None
                if y == 0:
                    return ((255, 230, 120), True)
                return None
            if style == 'gear':
                if f == 'top':
                    d = math.hypot(x - 3.5, y - 3.5)
                    if 2.2 <= d <= 3.6 and (x + y) % 2 == 0:
                        return (t['trim'], False)
                    if d < 1.2:
                        return (t['glow'], True)
                    return None
                if y == 0 and x % 2 == 0:
                    return (t['trim'], False)
                if f == 'front' and y == 1 and x in (0, 7):
                    return (t['glow'], True)
                return None
            if style == 'hood':
                if f == 'front':
                    if y == 0 or x == 0 or x == 7:
                        return (s.noise(t['hood'], 5), False)
                    if y == 1 and x in (1, 6):
                        return (s.noise(t['hood'], 5), False)
                    return None
                return (s.noise(shade(t['hood'], 1.0 - 0.04 * y), 5), False)
            if style == 'crown_hood':
                if f == 'front':
                    if y == 0:
                        return ((t['gems'][x % 8]), True) if x % 2 else (t['trim'], False)
                    if x == 0 or x == 7:
                        return (s.noise(t['hood'], 5), False)
                    return None
                if f == 'top':
                    if x in (0, 7) or y in (0, 7):
                        return (t['trim'], False)
                    return (s.noise(t['hood'], 5), False)
                if y == 0:
                    return (t['trim'], False)
                return (s.noise(shade(t['hood'], 1.0 - 0.03 * y), 5), False)
            if style == 'horns':
                if f == 'top' and (x in (0, 1, 6, 7)) and y in (2, 3, 4):
                    return ((60, 40, 50), False)
                if f in ('right', 'left') and y <= 2 and x in (2, 3, 4, 5):
                    return ((80 + 30 * y, 60, 70), False)
                if f == 'front' and y == 0 and x in (0, 7):
                    return ((90, 60, 80), False)
                return None
            return None
        return fn

    for f in ('top', 'right', 'front', 'left', 'back'):
        s.paint('head', 1, f, hat(f))

    # Hombreras en las mangas
    for part in ('rarm', 'larm'):
        for f in ('top', 'right', 'front', 'left', 'back'):
            def sleeve(x, y, w, h, f=f):
                if f == 'top':
                    return (s.noise(t['trim'], 5), False)
                if y <= 2:
                    if y == 0 and x % 2 == 1 and t.get('spikes'):
                        return (t['glow'], True)
                    return (plate(s, t, part, f, w, h, x, y, base=t['light']), False)
                if y == 3:
                    return (s.noise(shade(t['trim'], 0.8), 5), False)
                return None
            s.paint(part, 1, f, sleeve)
    # Capa / faldón en la chaqueta
    if t.get('cape'):
        def cape(x, y, w, h):
            return (s.noise(shade(t['cape'], 1.0 - 0.03 * y), 5), False)
        s.paint('body', 1, 'back', cape)
        s.paint('body', 1, 'front', lambda x, y, w, h: ((t['trim'], False) if y == 0 and x in (0, 7) else None))


def make_skin(name, t, seed):
    s = Skin(seed)
    paint_head(s, t)
    paint_body(s, t)
    for part, arm in (('rarm', True), ('larm', True), ('rleg', False), ('lleg', False)):
        paint_limb(s, t, part, arm)
    overlay(s, t)
    if t.get('gauntlet'):
        # El guantelete de las ocho gemas en el brazo derecho de Silas
        fx, fy, w, h = PARTS['rarm'][0]['front']
        for i, c in enumerate(t['gems']):
            x = fx + (i % 4)
            y = fy + 9 + (i // 4) * 2
            s.px(x, y, c, True)
    if t.get('patch'):
        patch_limbs(s, t)
    s.img.save(f'{OUT}/{name}.png')
    s.glow.save(f'{OUT}/{name}_glow.png')


def patch_limbs(s, t):
    """La Quimera: cada extremidad es de un guardián distinto."""
    for part, key in (('rarm', 0), ('larm', 3), ('rleg', 4), ('lleg', 6)):
        sub = dict(t)
        sub.update(THEMES[GEMS[key]])
        sub['hat'] = None
        paint_limb(s, sub, part, part.endswith('arm'))


# --------------------------------------------------------------------------- temas
GEM_COLORS = [hexc(c) for c in ('ff5a2a', '4fd8ff', 'ddfff4', '5bc236', '9fe7ff', 'fff27a', '2ec4a6', '9b4dff')]
GEMS = ['fuego', 'tormenta', 'viento', 'tierra', 'hielo', 'luz', 'tiempo', 'vacio']

THEMES = {
    'fuego': dict(base=hexc('8a1e10'), dark=hexc('2a0a06'), light=hexc('b8401c'), trim=hexc('d9a23a'),
                  glow=hexc('ffb43a'), cloth=hexc('3a1410'), hat='flames', spikes=True),
    'tormenta': dict(base=hexc('2a4a7a'), dark=hexc('101a2e'), light=hexc('3f6fa8'), trim=hexc('b06a3a'),
                     glow=hexc('7ff0ff'), cloth=hexc('1a2236'), hat='bolt', spikes=True),
    'viento': dict(base=hexc('cfe6e0'), dark=hexc('6d8a86'), light=hexc('f2fbf8'), trim=hexc('9fb8c8'),
                   glow=hexc('a6fff0'), cloth=hexc('8aa7a2'), hat='wings'),
    'tierra': dict(base=hexc('6a5638'), dark=hexc('2e2416'), light=hexc('8a7448'), trim=hexc('4f7a2a'),
                   glow=hexc('a8ff5a'), cloth=hexc('3f3420'), hat='leaves'),
    'hielo': dict(base=hexc('6fa6d8'), dark=hexc('243c66'), light=hexc('bfe4ff'), trim=hexc('e6f6ff'),
                  glow=hexc('bff6ff'), cloth=hexc('2f4d78'), hat='crystals', spikes=True),
    'luz': dict(base=hexc('f2ecd8'), dark=hexc('a08a50'), light=hexc('ffffff'), trim=hexc('e3b43a'),
                glow=hexc('fff27a'), cloth=hexc('d8cfa8'), hat='halo'),
    'tiempo': dict(base=hexc('1f6f66'), dark=hexc('0c2a28'), light=hexc('2fa090'), trim=hexc('c08a3a'),
                   glow=hexc('5cffe0'), cloth=hexc('16403c'), hat='gear'),
    'vacio': dict(base=hexc('2a1640'), dark=hexc('0c0614'), light=hexc('4a2a70'), trim=hexc('7a3cc8'),
                  glow=hexc('d07cff'), cloth=hexc('180c26'), hat='hood', face='hood', skin=hexc('6a5a80'), hood=hexc('1a0c2a')),
}

SILAS = dict(base=hexc('2a1240'), dark=hexc('0e0618'), light=hexc('4a2468'), trim=hexc('d4aa3a'),
             glow=hexc('e070ff'), cloth=hexc('1c0c2c'), hat='crown_hood', face='hood', skin=hexc('9a8478'),
             hood=hexc('22103a'), emblem='eight', gems=GEM_COLORS, gauntlet=True, cape=hexc('3a0c4a'), spikes=True)

QUIMERA = dict(base=hexc('3a2a4a'), dark=hexc('140c1c'), light=hexc('5a4470'), trim=hexc('8a6a3a'),
               glow=hexc('ff4060'), cloth=hexc('241830'), hat='horns', face='beast', emblem='eight', gems=GEM_COLORS,
               patch=True, spikes=True)


def aura(name, colors, seed, density=0.5):
    r = random.Random(seed)
    img = Image.new('RGBA', (64, 32), (0, 0, 0, 255))
    for y in range(32):
        for x in range(64):
            v = math.sin(2 * math.pi * (x * 4 / 64 + y * 3 / 32)) + 0.6 * math.sin(2 * math.pi * (x / 64 - y / 32) + 1.7) + r.uniform(-0.35, 0.35)
            if v > 1.6 - density * 1.6:
                k = min(1.0, (v - (1.6 - density * 1.6)) / 0.9)
                c = colors[(x // 8 + y // 6) % len(colors)]
                img.putpixel((x, y), (*shade(c, 0.35 + 0.65 * k), 255))
    img.save(f'{OUT}/aura_{name}.png')


if __name__ == '__main__':
    for i, g in enumerate(GEMS):
        make_skin('guardian_' + g, THEMES[g], 100 + i)
        aura(g, [THEMES[g]['glow'], THEMES[g]['light']], 200 + i)
    make_skin('silas_jefe', SILAS, 300)
    make_skin('quimera', QUIMERA, 400)
    aura('silas', [hexc('b040ff'), hexc('5a10a0'), hexc('ff60d0')], 301, 0.55)
    aura('quimera', GEM_COLORS, 401, 0.6)
