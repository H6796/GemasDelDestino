# Las Gemas del Destino — Mod para Minecraft Java 1.20.1 (Forge)

Un mod estilo **Minecraft: Story Mode**: 8 gemas mágicas, 8 mazmorras llenas de puzzles y minijefes, pueblos y ciudades con comerciantes, cinemáticas, y un traidor escondido en tu propio grupo.

## La historia

Al entrar por primera vez en un mundo nuevo aparece un **campamento** junto a ti y empieza la cinemática de introducción. También se construye la ciudad de **Valdoria** a unos 260 bloques.

| NPC del campamento | Papel |
|---|---|
| **Eldric el Sabio** | El mentor. Te explica la leyenda y en qué punto estás. |
| **Lyra la Exploradora** | Encuentra huellas sospechosas… |
| **Bram el Herrero** | Le encargaron forjar un guantelete con cinco huecos… |
| **Silas el Erudito** | Te indica cada pueblo y se ofrece a "guardar" las gemas. Es el **líder secreto de la Orden del Eclipse**. |

### El Diario del Destino (tecla J)

No hay brújulas ni mapas: todo está en el **diario**, que se abre y se cierra con la **J** (se puede cambiar en Opciones → Controles). Muestra:
- El objetivo actual y los pasos del capítulo, con lo que ya has hecho y lo que falta (materiales, criaturas cazadas, cristales que quedan…).
- Una rosa de los vientos que gira contigo, con una **flecha** y la **distancia** al destino cuando se conoce: el pueblo, el campamento, la grieta o la fortaleza.
- Un indicador de **frío / caliente** cuando hay que buscar a ciegas: la entrada de la mazmorra y las gemas del epílogo. Suena cada vez que cambia.
- Las ocho gemas, iluminadas a medida que las vas entregando.

El diario se actualiza solo mientras lo tienes abierto, y el juego no se pausa.

### Cada capítulo (hay 8)

1. **Viaja al pueblo.** Silas lo anota en tu diario (están a entre 450 y 1.650 bloques). Al llegar hay una cinemática.
2. **Habla con el anciano.** Te cuenta la historia del lugar y te pide **materiales** → fragmento de mapa 1/3.
3. **Misión de caza.** Elimina cierto número de criaturas (cuenta lo que mate cualquier jugador del grupo) → fragmento 2/3.
4. **Torre de vigía.** El anciano solo te dice la dirección y la distancia aproximada: el diario **no tiene flecha** para la torre. El último fragmento está en lo alto de la torre, que tiene un generador de esqueletos.
5. **El Mapa del Eclipse.** El anciano une los 3 fragmentos y el mapa se graba en tu diario. No marca el sitio exacto: la flecha solo lleva a una **zona aproximada** (a 40-75 bloques de la entrada) y el diario te dice si estás **frío, templado, caliente o ardiendo**.
6. **Encuentra la entrada.** Es una trampilla escondida **bajo una alfombra**. En los capítulos 1 a 3 hay unas pequeñas ruinas cerca; en el 4 y el 5, solo la alfombra.
7. **Supera la mazmorra** (ver abajo), coge la gema del pedestal y escapa de los guardianes.
8. **Vuelve al campamento** y entrégale la gema a Silas.

| Capítulo | Pueblo | Recolectar | Cazar |
|---|---|---|---|
| 1. Fuego | Brasaroja | 32 carbones + 16 lingotes de hierro | 20 zombis |
| 2. Tormenta | Puerto Trueno | 32 lingotes de cobre + 8 de oro | 15 creepers |
| 3. Viento | Cumbreventosa | 24 plumas + 3 diamantes | 25 esqueletos |
| 4. Tierra | Raíz Profunda | 16 obsidianas + 6 varas de blaze | 12 blazes (Nether) |
| 5. Hielo | Escarcha Alta | 32 bloques de nieve + 8 zanahorias doradas | 15 esqueletos glaciales |
| 6. Luz | Valle Solar | 16 piedras luminosas + 4 manzanas de oro | 10 esqueletos wither (Nether) |
| 7. Tiempo | Relojoria | 8 relojes + 48 redstone | 10 phantoms |
| 8. Vacío | Umbral | 12 perlas de ender + 5 diamantes | 20 endermans |

En el capítulo 3 aparece una segunda ciudad, la **Ciudadela de Aurora**.

### El final: la Fortaleza del Eclipse

Al entregar la **octava gema**, Silas **revela su traición** y se **teletransporta** con todas las gemas a su castillo, la **Fortaleza del Eclipse**, que flota **en el End**, sobre el vacío. Junto al campamento se abre una **Grieta del Eclipse** (un portal de obsidiana llorosa) y el diario te guía hasta ella. Crúzala para llegar a la fortaleza. En el islote de llegada hay otra grieta para volver al campamento.

La fortaleza está lejos de la isla del dragón, así que el dragón no aparece. Si el End está desactivado en el servidor, la fortaleza se construye flotando en el cielo del mundo normal.

1. **Las defensas.** La fortaleza tiene:
   - Un islote de llegada y un **puente sobre el vacío** con arcos, farolas y cadenas.
   - Una isla flotante con cascadas de lava que caen al vacío, cristales de amatista colgando por debajo e islotes sueltos alrededor.
   - Murallas irrompibles de 16 bloques con contrafuertes, almenas y estandartes.
   - Una gran puerta sellada entre dos torres, con el **Ojo del Eclipse** encima.
   - Un patio con los **ocho santuarios de las gemas**, jardines de coros, un cementerio de la Orden, braseros, estatuas y muchos soldados (esqueletos wither, vindicadores, evocadores, un devastador, endermans y shulkers).
   - Cuatro torres redondas con generadores de monstruos en cada piso.
   - La torre del homenaje, con torretas, vidrieras y una aguja de 80 bloques con un halo flotante.

   En lo alto de cada torre hay un **Cristal de defensa**: rompe los **cuatro** y se abre la puerta.

   El **Salón del Trono** tiene columnas de púrpura con bóveda de nervaduras, balcones, vidrieras y un rosetón, lámparas colgantes, un círculo ritual en el suelo y el trono de Silas sobre un estrado de tres niveles.
2. **Los ocho guardianes.** Al entrar en el Salón del Trono, Silas resucita a **los 8 minijefes a la vez**.
3. **La fusión.** Cuando caen todos, Silas aparece y los **fusiona en la Quimera del Eclipse**:
   - Es un ultraminijefe gigante, con 800 de vida.
   - Usa al azar los poderes de las ocho gemas.
   - Tiene tres fases.
4. **Silas.** Al derrotar a la Quimera, Silas baja de su trono y lucha él mismo:
   - Tiene 600 de vida y los poderes de las 8 gemas.
   - Cambia de fase al 50 % y al 25 % de vida.
5. **Las gemas se dispersan.** Al vencerle, las ocho gemas salen disparadas por el techo y caen en **cráteres por todo el mundo**. En el epílogo puedes buscarlas con el indicador de calor del diario.

Las pistas sobre el traidor se acumulan poco a poco:
- Lo que dicen Lyra y Bram.
- Lo que cuenta cada anciano.
- Los diarios firmados con una "S".
- Los libros de las bibliotecas de las mazmorras.
- El humo oscuro que va apareciendo alrededor de Silas.

**Duración:** con 8 capítulos y el asalto final, la historia está pensada para durar **más de 20 horas** en supervivencia normal, por los viajes largos, los materiales cada vez más difíciles (diamantes, el Nether, endermans) y las mazmorras de 12 a 30 salas. Depende mucho de tu ritmo: alguien que va directo y con buen equipo puede tardar bastante menos. Este dato es una estimación: el mod todavía no se ha probado jugando.

## Las mazmorras

Cada mazmorra es un **laberinto de salas** (de 12 a 36 salas, más grandes en cada capítulo). Muros, suelos y techos son **irrompibles**, así que no se puede hacer trampa cavando.

Cada mazmorra tiene su propia **decoración** según su gema: columnas, marcos de puerta, molduras, vigas, lámparas, estandartes, antorchas, alfombras y cosas colgando del techo (enredaderas, raíces, cadenas, amatista…). Además, cada tipo de sala tiene sus detalles: estatuas en la entrada, huesos y calaveras en las de combate, montones de oro en las de tesoro, mesas de lectura en las bibliotecas, braseros en la del guardián y un estrado para la gema en la cámara.

| Sala | Qué hay |
|---|---|
| Entrada | Un libro de advertencia y suministros. |
| Combate | Generadores de monstruos y columnas para cubrirse. |
| Parkour | Saltos sobre lava, abismos, agua o bloques de magma. Hay escaleras de mano para salir si te caes. |
| Laberinto | Un laberinto interior distinto cada vez. |
| Tesoro | Cofres con botín (y a veces una trampa de arañas). |
| Biblioteca | Libros con la historia de la Orden y pistas sobre el traidor. |
| Descanso | Cama, hoguera, comida, pociones, yunque y horno. |
| **Puzzle de runas** | Copia el mural de colores tocando las runas. Desde el capítulo 3 el mural se lee **al revés**. La puerta siguiente está sellada hasta que lo resuelvas. |
| **Altar del desafío** | Sobrevive a 3 oleadas de enemigos para romper el sello. |
| **Guardián** | Un **minijefe** con barra de jefe, una cinemática al despertar, habilidades propias y una fase de furia. Suelta la **Llave del Sello**. |
| Cámara | La puerta solo se abre con la llave. Dentro está la gema, cofres de botín y el diario del traidor. |

Cada minijefe lleva una **armadura propia de su elemento** (yelmo de llamas, cresta de rayo, alas, corona de hojas, púas de hielo, halo, engranajes o capucha). Sus ojos, runas y emblema **brillan en la oscuridad**, tiene un **aura de energía** que recorre su cuerpo y lo rodean partículas de su elemento con un anillo de color en el suelo. Cuando le queda poca vida, el aura se intensifica.

La **Quimera** está hecha de piezas de varios guardianes, con cuernos y cuatro ojos, y la rodea un anillo con los colores de las ocho gemas. **Silas** viste una túnica con capucha, corona y capa, lleva el guantelete con las ocho gemas, y las gemas orbitan a su alrededor.

Las texturas se generan con `tools/generar_skins_jefes.py` (Python con Pillow), por si quieres retocar colores o estilos.

Los minijefes son:
- Ignar (fuego).
- Voltra (rayos).
- Zéfir (viento y levitación).
- Gorrak (terremotos y esbirros).
- Nivalis (congelación).
- Solenne (ceguera y curación).
- Kronos (ralentiza el tiempo).
- Nyx (teletransporte y oscuridad).

## Pueblos y ciudades

- **8 pueblos**, cada uno con su estilo (acacia, abeto, abedul, roble oscuro, nieve, arenisca dorada, cerezo y pizarra/púrpura). Tienen casas, plaza con pozo, puestos de mercado, granja y farolas, además de 4 comerciantes y el anciano.
- **2 ciudades amuralladas** con torres, puertas, calles, una fuente, taberna, herrería, templo, ayuntamiento, biblioteca, joyería, unos 10 comerciantes y gólems de hierro.

**Comerciantes** (todos usan esmeraldas):

| Oficio | Vende / compra |
|---|---|
| Herrero | Armas y herramientas |
| Armero | Armaduras de hierro y diamante |
| Alquimista | Pociones |
| Granjero | Comida |
| Cartógrafo | Brújulas, mapas, catalejo |
| Joyero | Libros encantados, manzanas de oro, tótem, perlas de ender; compra diamantes |
| Tabernero | Comida y plumas |
| Bibliotecario | Botellas de experiencia, etiquetas, libros encantados |

## Las 8 gemas

| Gema | Poder activo (clic derecho) | Pasivo |
|---|---|---|
| Fuego | 3 bolas de fuego | Resistencia al fuego |
| Tormenta | Rayo donde miras | Prisa minera |
| Viento | Impulso + caída lenta | Velocidad |
| Tierra | Onda sísmica | Resistencia |
| Hielo | Congela a los enemigos cercanos | Respiración acuática |
| Luz | Cura al grupo y debilita a los monstruos | Regeneración |
| Tiempo | Ralentiza el tiempo a tu alrededor | Salto mejorado |
| Vacío | Teletransporte | Visión nocturna |

## Shaders

El mod ya no trae shader propio. Para que se vea mejor, instala **Oculus** y **Embeddium** desde CurseForge y usa un pack de shaders como Complementary Reimagined, Complementary Unbound o BSL.

## Comandos

- `/gemas estado`: muestra el capítulo y la misión actual.
- *(Solo op, para probar)*:
  - `/gemas iniciar`
  - `/gemas reiniciar`
  - `/gemas npcs`
  - `/gemas capitulo <1-8>`
  - `/gemas final` (te da la última gema para probar el final)
  - `/gemas saltarMision`
  - `/gemas darGema`
  - `/gemas tp <campamento|ciudad|pueblo|torre|mazmorra|fortaleza>`

## Cómo conseguir el .jar

**Con GitHub (sin instalar nada):** sube el zip del proyecto a un repositorio con el archivo `.github/workflows/build.yml` que descomprime el zip y compila. La pestaña **Actions** lo compila sola y en **Artifacts** descargas `GemasDelDestino-jar`.

**En tu PC:** instala Java 17 y ejecuta `gradlew build`. El mod queda en `build/libs/`.

Cópialo a la carpeta `mods` de Minecraft 1.20.1 con Forge 47.x y crea un **mundo nuevo**.
