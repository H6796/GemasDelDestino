package com.gemasdeldestino.story;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.UUID;

/**
 * Progreso de la historia, guardado con el mundo (compartido por todo el grupo de jugadores).
 */
public class StoryData extends SavedData {
    public static final int STAGE_NONE = 0;
    public static final int STAGE_TALK_ELDER = 1;
    public static final int STAGE_VILLAGE = 2;   // misiones del pueblo (questStep 0..3)
    public static final int STAGE_SEEK = 3;      // buscando y recorriendo la mazmorra
    public static final int STAGE_RETURN = 4;    // volver con la gema
    public static final int STAGE_BOSS = 5;      // Fortaleza del Eclipse (ver castlePhase)
    public static final int STAGE_END = 6;

    /** Pasos dentro de STAGE_VILLAGE. */
    public static final int Q_MEET = 0, Q_FETCH = 1, Q_HUNT = 2, Q_TOWER = 3;

    /** Fases dentro de STAGE_BOSS. */
    public static final int C_DEFENSES = 0, C_GATE_OPEN = 1, C_GUARDIANS = 2, C_FUSION = 3, C_SILAS = 4;

    /** Número de gemas / capítulos. */
    public static final int N = 8;

    private static final String NAME = "gemasdeldestino_historia";

    public int stage = STAGE_NONE;
    public int currentGem = 0;
    public int questStep = 0;
    public int killCount = 0;
    public int gemsDelivered = 0;
    public BlockPos campPos = BlockPos.ZERO;
    public final BlockPos[] cityPos = new BlockPos[2];
    public final boolean[] citySeen = new boolean[2];
    public final BlockPos[] villagePos = new BlockPos[N];
    public final BlockPos[] towerPos = new BlockPos[N];
    public final BlockPos[] basePos = new BlockPos[N];       // entrada oculta en la superficie
    public final BlockPos[] baseRoom = new BlockPos[N];      // centro de la sala de entrada
    public final BlockPos[] compassPos = new BlockPos[N];    // punto impreciso de la brújula
    public final boolean[] villageSeen = new boolean[N];
    public final boolean[] dungeonSeen = new boolean[N];
    public final boolean[] hintShown = new boolean[N];
    public UUID silasId = null;

    // Fortaleza del Eclipse y epílogo
    public BlockPos castlePos = null;
    public boolean castleSeen = false;
    public int castlePhase = 0;
    public int crystalsLeft = 4;
    /** La fortaleza está en el End (las partidas antiguas la tenían en el mundo normal). */
    public boolean castleEnd = false;
    /** La construcción de la fortaleza ha terminado y la grieta ya se puede cruzar. */
    public boolean castleReady = false;
    /** Grieta del Eclipse junto al campamento. */
    public BlockPos riftPos = null;
    public final BlockPos[] scatterPos = new BlockPos[N];
    public final boolean[] scatterFound = new boolean[N];

    /** No se guarda: evita arrancar la historia dos veces mientras espera. */
    public boolean starting = false;

    public static StoryData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(StoryData::load, StoryData::new, NAME);
    }

    private static void putPos(CompoundTag tag, String key, BlockPos pos) {
        if (pos != null) tag.putLong(key, pos.asLong());
    }

    private static BlockPos getPos(CompoundTag tag, String key) {
        return tag.contains(key) ? BlockPos.of(tag.getLong(key)) : null;
    }

    public static StoryData load(CompoundTag tag) {
        StoryData d = new StoryData();
        d.stage = tag.getInt("stage");
        d.currentGem = tag.getInt("currentGem");
        d.questStep = tag.getInt("questStep");
        d.killCount = tag.getInt("killCount");
        d.gemsDelivered = tag.getInt("gemsDelivered");
        d.campPos = BlockPos.of(tag.getLong("campPos"));
        for (int i = 0; i < 2; i++) {
            d.cityPos[i] = getPos(tag, "city" + i);
            d.citySeen[i] = tag.getBoolean("citySeen" + i);
        }
        for (int i = 0; i < N; i++) {
            d.villagePos[i] = getPos(tag, "village" + i);
            d.towerPos[i] = getPos(tag, "tower" + i);
            d.basePos[i] = getPos(tag, "basePos" + i);
            d.baseRoom[i] = getPos(tag, "baseRoom" + i);
            d.compassPos[i] = getPos(tag, "compass" + i);
            d.villageSeen[i] = tag.getBoolean("villageSeen" + i);
            d.dungeonSeen[i] = tag.getBoolean("dungeonSeen" + i);
            d.hintShown[i] = tag.getBoolean("hint" + i);
        }
        if (tag.hasUUID("silas")) d.silasId = tag.getUUID("silas");
        d.castlePos = getPos(tag, "castle");
        d.castleSeen = tag.getBoolean("castleSeen");
        d.castlePhase = tag.getInt("castlePhase");
        d.crystalsLeft = tag.contains("crystals") ? tag.getInt("crystals") : 4;
        d.castleEnd = tag.getBoolean("castleEnd");
        d.castleReady = tag.getBoolean("castleReady");
        d.riftPos = getPos(tag, "rift");
        for (int i = 0; i < N; i++) {
            d.scatterPos[i] = getPos(tag, "scatter" + i);
            d.scatterFound[i] = tag.getBoolean("scatterFound" + i);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("stage", stage);
        tag.putInt("currentGem", currentGem);
        tag.putInt("questStep", questStep);
        tag.putInt("killCount", killCount);
        tag.putInt("gemsDelivered", gemsDelivered);
        tag.putLong("campPos", campPos.asLong());
        for (int i = 0; i < 2; i++) {
            putPos(tag, "city" + i, cityPos[i]);
            tag.putBoolean("citySeen" + i, citySeen[i]);
        }
        for (int i = 0; i < N; i++) {
            putPos(tag, "village" + i, villagePos[i]);
            putPos(tag, "tower" + i, towerPos[i]);
            putPos(tag, "basePos" + i, basePos[i]);
            putPos(tag, "baseRoom" + i, baseRoom[i]);
            putPos(tag, "compass" + i, compassPos[i]);
            tag.putBoolean("villageSeen" + i, villageSeen[i]);
            tag.putBoolean("dungeonSeen" + i, dungeonSeen[i]);
            tag.putBoolean("hint" + i, hintShown[i]);
        }
        if (silasId != null) tag.putUUID("silas", silasId);
        putPos(tag, "castle", castlePos);
        tag.putBoolean("castleSeen", castleSeen);
        tag.putInt("castlePhase", castlePhase);
        tag.putInt("crystals", crystalsLeft);
        tag.putBoolean("castleEnd", castleEnd);
        tag.putBoolean("castleReady", castleReady);
        putPos(tag, "rift", riftPos);
        for (int i = 0; i < N; i++) {
            putPos(tag, "scatter" + i, scatterPos[i]);
            tag.putBoolean("scatterFound" + i, scatterFound[i]);
        }
        return tag;
    }

    public void reset() {
        stage = STAGE_NONE;
        currentGem = 0;
        questStep = 0;
        killCount = 0;
        gemsDelivered = 0;
        campPos = BlockPos.ZERO;
        for (int i = 0; i < 2; i++) {
            cityPos[i] = null;
            citySeen[i] = false;
        }
        for (int i = 0; i < N; i++) {
            villagePos[i] = null;
            towerPos[i] = null;
            basePos[i] = null;
            baseRoom[i] = null;
            compassPos[i] = null;
            villageSeen[i] = false;
            dungeonSeen[i] = false;
            hintShown[i] = false;
        }
        silasId = null;
        castlePos = null;
        castleSeen = false;
        castlePhase = 0;
        crystalsLeft = 4;
        castleEnd = false;
        castleReady = false;
        riftPos = null;
        for (int i = 0; i < N; i++) {
            scatterPos[i] = null;
            scatterFound[i] = false;
        }
        starting = false;
        setDirty();
    }
}
