package com.gemasdeldestino.story;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.registry.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

@Mod.EventBusSubscriber(modid = GemasMod.MODID)
public final class StoryEvents {

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) StoryManager.onPlayerJoin(sp);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) StoryManager.tick(server);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.player instanceof ServerPlayer sp) StoryManager.onPlayerTick(sp);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (event.getSource().getEntity() instanceof ServerPlayer killer) StoryManager.onMobKilled(killer, event.getEntity());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        StoryManager.clearTasks();
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static final String[] STAGES = {"Sin empezar", "Hablar con Eldric", "Misiones del pueblo",
            "Buscando la mazmorra", "Volver al campamento", "Fortaleza del Eclipse", "Epílogo"};
    private static final String[] STEPS = {"hablar con el anciano", "recolectar materiales", "cazar", "torre de vigía"};

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("gemas")
                .then(Commands.literal("estado").executes(ctx -> {
                    StoryData d = StoryData.get(ctx.getSource().getServer());
                    GemType g = GemType.byIndex(d.currentGem);
                    String extra = d.stage == StoryData.STAGE_VILLAGE ? " (" + STEPS[Math.min(3, d.questStep)] + ")" : "";
                    ctx.getSource().sendSuccess(() -> Component.literal("Capítulo " + (d.currentGem + 1) + ": " + g.gemName
                            + " | " + STAGES[Math.min(STAGES.length - 1, d.stage)] + extra
                            + " | Gemas entregadas: " + d.gemsDelivered + "/8").withStyle(ChatFormatting.GOLD), false);
                    return 1;
                }))
                .then(Commands.literal("iniciar").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    StoryManager.startStory(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("npcs").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    StoryData d = StoryData.get(p.server);
                    StoryManager.spawnCampNpcs(p.server.overworld(), d, d.stage < StoryData.STAGE_BOSS);
                    ctx.getSource().sendSuccess(() -> Component.literal("NPC del campamento restaurados."), true);
                    return 1;
                }))
                .then(Commands.literal("reiniciar").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    StoryData.get(ctx.getSource().getServer()).reset();
                    ctx.getSource().sendSuccess(() -> Component.literal("Historia reiniciada. Usa /gemas iniciar para empezar de nuevo."), true);
                    return 1;
                }))
                .then(Commands.literal("capitulo").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("numero", IntegerArgumentType.integer(1, 8)).executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            StoryData d = StoryData.get(p.server);
                            int n = IntegerArgumentType.getInteger(ctx, "numero") - 1;
                            d.gemsDelivered = n;
                            StoryManager.startChapter(p, n);
                            return 1;
                        })))
                .then(Commands.literal("saltarMision").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    StoryData d = StoryData.get(p.server);
                    if (d.stage == StoryData.STAGE_VILLAGE) {
                        if (d.questStep == StoryData.Q_HUNT) d.killCount = Chapters.get(d.currentGem).killCount();
                        else if (d.questStep == StoryData.Q_TOWER) StoryManager.give(p, new ItemStack(ModItems.FRAGMENTO_MAPA.get(), 3));
                        else if (d.questStep == StoryData.Q_FETCH)
                            for (Chapters.Req r : Chapters.get(d.currentGem).fetch()) StoryManager.give(p, new ItemStack(r.item(), r.count()));
                        else d.questStep = StoryData.Q_FETCH;
                        d.setDirty();
                        ctx.getSource().sendSuccess(() -> Component.literal("Misión preparada: habla con el anciano."), false);
                    }
                    return 1;
                }))
                .then(Commands.literal("final").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    StoryData d = StoryData.get(p.server);
                    d.currentGem = StoryData.N - 1;
                    d.gemsDelivered = StoryData.N - 1;
                    d.stage = StoryData.STAGE_RETURN;
                    d.setDirty();
                    StoryManager.give(p, new ItemStack(GemType.byIndex(StoryData.N - 1).item()));
                    ctx.getSource().sendSuccess(() -> Component.literal("Tienes la última gema: entrégasela a Silas para empezar el final."), false);
                    return 1;
                }))
                .then(Commands.literal("darGema").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    StoryData d = StoryData.get(p.server);
                    StoryManager.give(p, new ItemStack(GemType.byIndex(d.currentGem).item()));
                    if (d.stage == StoryData.STAGE_SEEK || d.stage == StoryData.STAGE_VILLAGE) {
                        d.stage = StoryData.STAGE_RETURN;
                        d.setDirty();
                    }
                    return 1;
                }))
                .then(Commands.literal("tp").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("destino", StringArgumentType.word())
                                .suggests((c, b) -> {
                                    for (String s : new String[]{"campamento", "ciudad", "pueblo", "torre", "mazmorra", "fortaleza"}) b.suggest(s);
                                    return b.buildFuture();
                                })
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    StoryData d = StoryData.get(p.server);
                                    int gi = d.currentGem;
                                    BlockPos target = switch (StringArgumentType.getString(ctx, "destino")) {
                                        case "campamento" -> d.campPos;
                                        case "ciudad" -> d.cityPos[0];
                                        case "pueblo" -> d.villagePos[gi];
                                        case "torre" -> d.towerPos[gi];
                                        case "mazmorra" -> d.baseRoom[gi];
                                        case "fortaleza" -> d.castlePos == null ? null
                                                : d.castleEnd ? com.gemasdeldestino.world.CastleBuilder.arrivalSpot(d.castlePos).below()
                                                : d.castlePos.offset(0, 0, 26);
                                        default -> null;
                                    };
                                    if (target == null) {
                                        ctx.getSource().sendFailure(Component.literal("Ese lugar todavía no existe."));
                                        return 0;
                                    }
                                    boolean castle = "fortaleza".equals(StringArgumentType.getString(ctx, "destino"));
                                    p.teleportTo(castle ? StoryManager.castleLevel(p.server, d) : p.server.overworld(), target.getX() + 0.5, target.getY() + 1, target.getZ() + 0.5, p.getYRot(), p.getXRot());
                                    return 1;
                                }))));
    }

    private StoryEvents() {}
}
