package com.gemasdeldestino.story;

import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.network.ModNetwork.OpenJournal;
import com.gemasdeldestino.registry.ModItems;
import com.gemasdeldestino.world.CastleBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * El Diario del Destino (tecla J). Sustituye a las brújulas y al Mapa del Eclipse.
 *
 * Se construye en el servidor con el estado de la historia y se envía al cliente:
 *  - Destinos conocidos (pueblo, campamento, grieta, fortaleza): flecha y distancia.
 *  - Torre de vigía: solo la pista del anciano, sin flecha.
 *  - Entrada de la mazmorra y gemas del epílogo: flecha a la zona aproximada como mucho, y el
 *    indicador de frío / caliente. Las coordenadas exactas nunca llegan al cliente.
 */
public final class Journal {

    public static final int GOLD = 0xE8C66A, PURPLE = 0xB07CFF;

    public static OpenJournal build(ServerPlayer p, boolean open) {
        StoryData d = StoryData.get(p.server);
        J j = new J(open);
        int gi = d.currentGem;
        GemType g = GemType.byIndex(gi);
        Chapters.Chapter ch = Chapters.get(gi);

        switch (d.stage) {
            case StoryData.STAGE_NONE -> {
                j.title = "Diario del Destino";
                j.objective = "Tu historia todavía no ha empezado.";
            }
            case StoryData.STAGE_TALK_ELDER -> {
                j.title = "Prólogo";
                j.objective = "Habla con Eldric en el campamento.";
                j.target("Campamento", d.campPos, Level.OVERWORLD);
            }
            case StoryData.STAGE_VILLAGE, StoryData.STAGE_SEEK, StoryData.STAGE_RETURN -> chapter(p, d, j, gi, g, ch);
            case StoryData.STAGE_BOSS -> finale(p, d, j);
            case StoryData.STAGE_END -> epilogue(p, d, j);
            default -> j.objective = "...";
        }
        if (j.color == 0) j.color = d.stage >= StoryData.STAGE_BOSS ? PURPLE : GOLD;
        return new OpenJournal(open, j.title, j.color, j.objective, j.steps, j.states, j.hasTarget, j.targetName,
                j.tx, j.tz, j.dim, j.heat, j.hint, d.gemsDelivered);
    }

    // =====================================================================================
    private static void chapter(ServerPlayer p, StoryData d, J j, int gi, GemType g, Chapters.Chapter ch) {
        j.title = "Capítulo " + (gi + 1) + " · " + g.gemName;
        j.color = g.rgb;
        boolean fragments = StoryManager.count(p, ModItems.FRAGMENTO_MAPA.get()) >= 3;

        int current;
        if (d.stage == StoryData.STAGE_VILLAGE) {
            current = switch (d.questStep) {
                case StoryData.Q_MEET -> 0;
                case StoryData.Q_FETCH -> 1;
                case StoryData.Q_HUNT -> 2;
                default -> fragments ? 4 : 3;
            };
        } else if (d.stage == StoryData.STAGE_SEEK) {
            current = d.dungeonSeen[gi] ? 6 : 5;
        } else {
            current = 7;
        }

        String fetch = current == 1 ? StoryManager.progress(p, ch) : reqList(ch);
        String hunt = ch.killName() + (current == 2 ? " (" + Math.min(d.killCount, ch.killCount()) + "/" + ch.killCount() + ")" : "");
        String[] steps = {
                "Viaja a " + ch.village() + " y habla con " + ch.elder(),
                "Consigue: " + fetch,
                "Elimina " + ch.killCount() + " " + hunt,
                "Encuentra la torre de vigía y su fragmento",
                "Lleva los 3 fragmentos a " + ch.elder(),
                "Encuentra la entrada oculta del " + g.baseName,
                "Supera la mazmorra y coge la " + g.gemName,
                "Vuelve al campamento y entrégale la gema a Silas"};
        for (int i = 0; i < steps.length; i++) j.step(steps[i], i < current ? 2 : i == current ? 1 : 0);

        switch (current) {
            case 0 -> {
                j.objective = "Viaja a " + ch.village() + " y habla con " + ch.elder() + ".";
                j.target(ch.village(), d.villagePos[gi], Level.OVERWORLD);
            }
            case 1 -> {
                j.objective = "Reúne los materiales y vuelve a hablar con " + ch.elder() + ".";
                j.target(ch.village(), d.villagePos[gi], Level.OVERWORLD);
            }
            case 2 -> {
                j.objective = d.killCount >= ch.killCount()
                        ? "¡Caza completada! Vuelve con " + ch.elder() + "."
                        : "Elimina " + ch.killName() + ": " + d.killCount + "/" + ch.killCount() + ".";
                j.target(ch.village(), d.villagePos[gi], Level.OVERWORLD);
            }
            case 3 -> {
                j.objective = "Encuentra la torre de vigía. El diario no puede guiarte hasta ella.";
                j.hint = ch.elder() + " dijo que está " + StoryManager.towerDirection(d, gi)
                        + ". Oriéntate por el sol: sale por el este y se pone por el oeste.";
            }
            case 4 -> {
                j.objective = "Lleva los tres fragmentos del mapa a " + ch.elder() + ".";
                j.target(ch.village(), d.villagePos[gi], Level.OVERWORLD);
            }
            case 5 -> {
                j.objective = "Encuentra la entrada oculta del " + g.baseName + ". Cuando arda, busca algo fuera de lugar en el suelo.";
                // La flecha solo lleva a la zona aproximada; el calor dice lo cerca que está la entrada.
                if (d.compassPos[gi] != null) j.target("Zona aproximada", d.compassPos[gi], Level.OVERWORLD);
                j.heat(p, d.basePos[gi]);
            }
            case 6 -> j.objective = "Resuelve los enigmas, derrota al guardián y abre la cámara de la " + g.gemName + ".";
            default -> {
                j.objective = "Vuelve al campamento y entrégale la " + g.gemName + " a Silas.";
                j.target("Campamento", d.campPos, Level.OVERWORLD);
            }
        }
    }

    private static void finale(ServerPlayer p, StoryData d, J j) {
        j.title = "Capítulo Final · La Fortaleza del Eclipse";
        ServerLevel castleLevel = StoryManager.castleLevel(p.server, d);
        boolean atCastle = p.serverLevel() == castleLevel && d.castlePos != null && p.blockPosition().closerThan(d.castlePos, 200);
        boolean crossed = atCastle || d.castleSeen;
        int current = switch (d.castlePhase) {
            case StoryData.C_DEFENSES -> crossed ? 1 : 0;
            case StoryData.C_GATE_OPEN -> 2;
            case StoryData.C_GUARDIANS -> 3;
            case StoryData.C_FUSION -> 4;
            default -> 5;
        };
        String[] steps = {
                d.riftPos != null ? "Cruza la Grieta del Eclipse" : "Llega a la Fortaleza del Eclipse",
                "Rompe los Cristales de defensa" + (d.castlePhase == StoryData.C_DEFENSES ? " (quedan " + d.crystalsLeft + ")" : ""),
                "Entra en el Salón del Trono",
                "Derrota a los ocho guardianes",
                "Derrota a la Quimera del Eclipse",
                "Derrota a Silas"};
        for (int i = 0; i < steps.length; i++) j.step(steps[i], i < current ? 2 : i == current ? 1 : 0);

        j.objective = switch (current) {
            case 0 -> d.riftPos != null ? "Prepárate bien y cruza la Grieta del Eclipse, junto al campamento." : "Viaja a la Fortaleza del Eclipse.";
            case 1 -> "Sube a lo alto de las cuatro torres y rompe los cristales. Quedan " + d.crystalsLeft + ".";
            case 2 -> "La puerta está abierta. Entra en el Salón del Trono.";
            case 3 -> "Derrota a los ocho guardianes.";
            case 4 -> "Derrota a la Quimera del Eclipse.";
            default -> "Derrota a Silas, Señor del Eclipse.";
        };
        if (d.castlePos == null) return;
        if (!atCastle && d.riftPos != null && p.level().dimension() == Level.OVERWORLD) {
            j.target("Grieta del Eclipse", d.riftPos, Level.OVERWORLD);
        } else {
            j.target(current >= 2 ? "Salón del Trono" : "Fortaleza del Eclipse", d.castlePos, castleLevel.dimension());
        }
    }

    private static void epilogue(ServerPlayer p, StoryData d, J j) {
        j.title = "Epílogo · Las gemas dispersas";
        int found = 0;
        BlockPos nearest = null;
        double best = Double.MAX_VALUE;
        for (int i = 0; i < StoryData.N; i++) {
            if (d.scatterFound[i]) found++;
            j.step(GemType.byIndex(i).gemName, d.scatterFound[i] ? 2 : 0);
            if (d.scatterPos[i] == null || d.scatterFound[i]) continue;
            double dist = StoryManager.horizontal(p, d.scatterPos[i]);
            if (dist < best) { best = dist; nearest = d.scatterPos[i]; }
        }
        if (nearest == null) {
            j.objective = "Has encontrado todas las gemas. Tu leyenda está completa.";
            return;
        }
        j.objective = "Silas ha caído. Busca los cráteres donde cayeron las gemas (" + found + "/8 encontradas).";
        j.heat(p, nearest);
    }

    private static String reqList(Chapters.Chapter ch) {
        StringBuilder sb = new StringBuilder();
        for (Chapters.Req r : ch.fetch()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(r.count()).append(" ").append(r.name());
        }
        return sb.toString();
    }

    /** Distancia -> nivel de calor: 0 helado ... 6 ¡aquí mismo! */
    public static int heatLevel(double dist) {
        if (dist > 400) return 0;
        if (dist > 250) return 1;
        if (dist > 150) return 2;
        if (dist > 80) return 3;
        if (dist > 35) return 4;
        if (dist > 8) return 5;
        return 6;
    }

    /** Acumulador de lo que va a mostrar el diario. */
    private static final class J {
        final boolean open;
        String title = "", objective = "", hint = "", targetName = "", dim = Level.OVERWORLD.location().toString();
        int color = 0, heat = -1;
        boolean hasTarget = false;
        double tx, tz;
        final List<String> steps = new ArrayList<>();
        final List<Integer> states = new ArrayList<>();

        J(boolean open) {
            this.open = open;
        }

        void step(String text, int state) {
            steps.add(text);
            states.add(state);
        }

        void target(String name, BlockPos pos, net.minecraft.resources.ResourceKey<Level> dimension) {
            if (pos == null) return;
            hasTarget = true;
            targetName = name;
            tx = pos.getX() + 0.5;
            tz = pos.getZ() + 0.5;
            dim = dimension.location().toString();
        }

        void heat(ServerPlayer p, BlockPos pos) {
            if (pos == null) return;
            if (p.level().dimension() != Level.OVERWORLD) {
                hint = "Aquí no sientes el calor de ninguna gema. Vuelve al mundo normal.";
                return;
            }
            heat = heatLevel(StoryManager.horizontal(p, pos));
        }
    }

    private Journal() {}
}
