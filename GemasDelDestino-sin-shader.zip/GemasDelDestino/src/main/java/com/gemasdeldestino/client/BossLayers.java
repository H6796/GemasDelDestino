package com.gemasdeldestino.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

import java.util.function.Function;

/** Capas extra de los jefes: partes que brillan en la oscuridad y un aura de energía alrededor del cuerpo. */
public final class BossLayers {

    /** Ojos, runas y emblemas a plena luz, con un pulso suave. */
    public static class Glow<T extends LivingEntity> extends RenderLayer<T, PlayerModel<T>> {
        private final Function<T, ResourceLocation> texture;

        public Glow(RenderLayerParent<T, PlayerModel<T>> parent, Function<T, ResourceLocation> texture) {
            super(parent);
            this.texture = texture;
        }

        @Override
        public void render(PoseStack pose, MultiBufferSource buffers, int light, T entity, float limbSwing, float limbSwingAmount,
                           float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
            if (entity.isInvisible()) return;
            float pulse = 0.75F + 0.25F * (float) Math.sin(ageInTicks * 0.15F);
            VertexConsumer vc = buffers.getBuffer(RenderType.eyes(texture.apply(entity)));
            getParentModel().renderToBuffer(pose, vc, 0xF000F0, OverlayTexture.NO_OVERLAY, pulse, pulse, pulse, 1.0F);
        }
    }

    /** Envoltura de energía que se desplaza por el cuerpo, como la de un creeper cargado. */
    public static class Aura<T extends LivingEntity> extends RenderLayer<T, PlayerModel<T>> {
        private final HumanoidModel<T> shell;
        private final Function<T, ResourceLocation> texture;
        private final float speed;

        public Aura(RenderLayerParent<T, PlayerModel<T>> parent, EntityModelSet models, Function<T, ResourceLocation> texture, float speed) {
            super(parent);
            this.shell = new HumanoidModel<>(models.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR));
            this.texture = texture;
            this.speed = speed;
        }

        @Override
        public void render(PoseStack pose, MultiBufferSource buffers, int light, T entity, float limbSwing, float limbSwingAmount,
                           float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
            if (entity.isInvisible()) return;
            getParentModel().copyPropertiesTo(shell);
            float t = ageInTicks * speed;
            // Más intensa cuando el jefe está malherido
            float k = entity.getHealth() < entity.getMaxHealth() * 0.4F ? 0.85F : 0.55F;
            VertexConsumer vc = buffers.getBuffer(RenderType.energySwirl(texture.apply(entity), (t * 0.01F) % 1.0F, (t * 0.006F) % 1.0F));
            shell.renderToBuffer(pose, vc, 0xF000F0, OverlayTexture.NO_OVERLAY, k, k, k, 1.0F);
        }
    }

    private BossLayers() {}
}
