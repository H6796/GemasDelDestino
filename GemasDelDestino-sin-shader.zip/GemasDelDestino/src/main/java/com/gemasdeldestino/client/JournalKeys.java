package com.gemasdeldestino.client;

import com.gemasdeldestino.GemasMod;
import com.gemasdeldestino.network.ModNetwork;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Tecla J: abre el Diario del Destino. */
@Mod.EventBusSubscriber(modid = GemasMod.MODID, value = Dist.CLIENT)
public final class JournalKeys {

    public static final KeyMapping OPEN = new KeyMapping("key.gemasdeldestino.journal", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.gemasdeldestino");

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (OPEN.consumeClick()) {
            if (mc.player != null && mc.screen == null) ModNetwork.CHANNEL.sendToServer(new ModNetwork.RequestJournal(true));
        }
    }

    private JournalKeys() {}
}
