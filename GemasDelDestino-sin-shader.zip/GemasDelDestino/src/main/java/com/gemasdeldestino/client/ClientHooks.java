package com.gemasdeldestino.client;

import com.gemasdeldestino.cinematic.Cinematic;
import com.gemasdeldestino.cinematic.Cinematics;
import com.gemasdeldestino.story.DialogueLine;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Puntos de entrada del lado cliente (solo se llaman desde paquetes en el cliente). */
public final class ClientHooks {

    public static void openDialogue(String id, List<DialogueLine> lines) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof CinematicScreen cs) {
            cs.queueDialogue(id, lines);
            return;
        }
        mc.setScreen(new DialogueScreen(id, lines));
    }

    public static void playCinematic(String id, Vec3 anchor) {
        Cinematic c = Cinematics.get(id);
        if (c == null || Minecraft.getInstance().level == null) return;
        Minecraft.getInstance().setScreen(new CinematicScreen(c, anchor));
    }

    /** Abre el diario o, si ya está abierto, actualiza lo que muestra. */
    public static void openJournal(com.gemasdeldestino.network.ModNetwork.OpenJournal data) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof JournalScreen js) {
            js.update(data);
            return;
        }
        if (data.open() && mc.screen == null && mc.player != null) mc.setScreen(new JournalScreen(data));
    }

    private ClientHooks() {}
}
