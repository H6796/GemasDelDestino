package com.gemasdeldestino.client;

import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.network.ModNetwork;
import com.gemasdeldestino.network.ModNetwork.OpenJournal;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * El Diario del Destino: misión actual, pasos del capítulo, rosa de los vientos con una flecha
 * hacia el destino (si se conoce), indicador de frío / caliente (si hay que buscar a ciegas)
 * y las gemas reunidas. Se abre y se cierra con la tecla J.
 */
public class JournalScreen extends Screen {
    private static final String[] HEAT_NAMES = {"Helado", "Frío", "Templado", "Caliente", "Muy caliente", "¡Ardiendo!", "¡Aquí mismo!"};
    private static final int[] HEAT_COLORS = {0x7FD8FF, 0x4FA8FF, 0xE0E0E0, 0xFFB030, 0xFF6020, 0xD01010, 0xC050FF};

    private OpenJournal data;
    private int ticks = 0;

    public JournalScreen(OpenJournal data) {
        super(Component.literal("Diario del Destino"));
        this.data = data;
    }

    public void update(OpenJournal newData) {
        if (minecraft != null && newData.heat() >= 0 && newData.heat() != data.heat()) {
            float pitch = 0.5F + newData.heat() * 0.25F;
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.AMETHYST_BLOCK_CHIME, pitch, 0.6F));
        }
        this.data = newData;
    }

    @Override
    protected void init() {
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.BOOK_PAGE_TURN, 1.0F));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        // Se actualiza cada segundo mientras está abierto (distancia, calor, progreso)
        if (++ticks % 20 == 0) ModNetwork.CHANNEL.sendToServer(new ModNetwork.RequestJournal(false));
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (JournalKeys.OPEN.matches(key, scanCode) || key == GLFW.GLFW_KEY_E) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        int w = Math.min(380, width - 16), h = Math.min(230, height - 16);
        int x = (width - w) / 2, y = (height - h) / 2;
        int accent = 0xFF000000 | data.color();

        // Tapas del libro
        g.fill(x - 3, y - 3, x + w + 3, y + h + 3, accent);
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF2A1E14);
        g.fill(x, y, x + w, y + h, 0xF01A1520);
        int mid = x + w * 58 / 100;
        g.fill(mid, y + 8, mid + 1, y + h - 30, 0x55FFFFFF);

        // Título
        g.drawCenteredString(font, data.title(), x + w / 2, y + 7, data.color());
        g.fill(x + 10, y + 19, x + w - 10, y + 20, accent);

        // ---- Página izquierda: objetivo y pasos
        int lx = x + 10, ly = y + 26, lw = mid - lx - 8;
        g.drawString(font, "OBJETIVO", lx, ly, 0xAAAAAA, false);
        ly += 11;
        ly = wrap(g, data.objective(), lx, ly, lw, 0xFFFFFF);
        ly += 6;
        List<String> steps = data.steps();
        if (!steps.isEmpty()) {
            g.drawString(font, "PASOS", lx, ly, 0xAAAAAA, false);
            ly += 11;
            for (int i = 0; i < steps.size() && ly < y + h - 40; i++) {
                int st = data.stepStates().get(i);
                String icon = st == 2 ? "✔" : st == 1 ? "▶" : "•";
                int col = st == 2 ? 0x6FBF6F : st == 1 ? data.color() : 0x8A8A8A;
                g.drawString(font, icon, lx, ly, col, false);
                ly = wrap(g, steps.get(i), lx + 10, ly, lw - 10, st == 0 ? 0x9A9A9A : st == 1 ? 0xFFFFFF : 0x7FA07F);
                ly += 2;
            }
        }

        // ---- Página derecha: navegación
        int rx = mid + 8, rw = x + w - 10 - rx;
        int cx = rx + rw / 2, cy = y + 74, radius = Math.min(40, rw / 2 - 6);
        Player player = minecraft != null ? minecraft.player : null;
        if (data.hasTarget() || data.heat() >= 0 || !data.hint().isEmpty()) {
            g.drawCenteredString(font, "NAVEGACIÓN", cx, y + 26, 0xAAAAAA);
        }
        if (data.hasTarget() && player != null) {
            compass(g, player, cx, cy, radius, accent, partial);
            g.drawCenteredString(font, data.targetName(), cx, cy + radius + 6, data.color());
            String dist;
            if (!player.level().dimension().location().toString().equals(data.targetDim())) dist = "En otra dimensión";
            else {
                double dx = data.tx() - player.getX(), dz = data.tz() - player.getZ();
                int m = (int) Math.sqrt(dx * dx + dz * dz);
                dist = m < 6 ? "¡Has llegado!" : "a " + (m < 100 ? m : (m / 10) * 10) + " bloques";
            }
            g.drawCenteredString(font, dist, cx, cy + radius + 17, 0xDDDDDD);
        }
        int by = data.hasTarget() ? cy + radius + 32 : y + 40;
        if (data.heat() >= 0) {
            heatBar(g, rx, by, rw);
            by += 34;
        }
        if (!data.hint().isEmpty()) {
            wrap(g, data.hint(), rx, by, rw, 0xC8B7E8);
        }

        // ---- Pie: las ocho gemas
        int gy = y + h - 24;
        g.fill(x + 10, gy - 5, x + w - 10, gy - 4, 0x55FFFFFF);
        int gx = x + (w - 8 * 20) / 2;
        for (int i = 0; i < 8; i++) {
            GemType gem = GemType.byIndex(i);
            g.renderItem(new ItemStack(gem.item()), gx + i * 20, gy);
            if (i >= data.gemsDelivered()) g.fill(gx + i * 20, gy, gx + i * 20 + 16, gy + 16, 0xC0101018);
        }
        String foot = "J para cerrar";
        g.drawString(font, foot, x + w - font.width(foot) - 6, y + h - 11, 0x666666, false);
        super.render(g, mouseX, mouseY, partial);
    }

    /** Rosa de los vientos que gira con el jugador y flecha hacia el destino. */
    private void compass(GuiGraphics g, Player player, int cx, int cy, int r, int accent, float partial) {
        double yaw = Math.toRadians(player.getViewYRot(partial));
        // Vectores "delante" y "derecha" del jugador en el mundo
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rxv = -Math.cos(yaw), rzv = -Math.sin(yaw);
        for (int a = 0; a < 360; a += 4) {
            double t = Math.toRadians(a);
            int px = cx + (int) Math.round(Math.cos(t) * r), py = cy + (int) Math.round(Math.sin(t) * r);
            g.fill(px, py, px + 2, py + 2, a % 90 == 0 ? 0xFFFFFFFF : 0xFF6A5A7A);
        }
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
        // Puntos cardinales
        String[] names = {"N", "E", "S", "O"};
        double[][] dirs = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
        for (int i = 0; i < 4; i++) {
            double sx = dirs[i][0] * rxv + dirs[i][1] * rzv, sy = -(dirs[i][0] * fx + dirs[i][1] * fz);
            int px = cx + (int) Math.round(sx * (r + 8)), py = cy + (int) Math.round(sy * (r + 8));
            g.drawCenteredString(font, names[i], px, py - 4, i == 0 ? 0xFF5555 : 0xBBBBBB);
        }
        if (!player.level().dimension().location().toString().equals(data.targetDim())) return;
        double dx = data.tx() - player.getX(), dz = data.tz() - player.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5) return;
        dx /= len;
        dz /= len;
        double sx = dx * rxv + dz * rzv, sy = -(dx * fx + dz * fz);
        int col = 0xFF000000 | data.color();
        int tipX = cx + (int) Math.round(sx * (r - 4)), tipY = cy + (int) Math.round(sy * (r - 4));
        line(g, cx, cy, tipX, tipY, col, 3);
        double ang = Math.atan2(sy, sx);
        for (double off : new double[]{2.6, -2.6}) {
            int ex = tipX + (int) Math.round(Math.cos(ang + off) * 10), ey = tipY + (int) Math.round(Math.sin(ang + off) * 10);
            line(g, tipX, tipY, ex, ey, col, 3);
        }
    }

    private void heatBar(GuiGraphics g, int x, int y, int w) {
        g.drawString(font, "CALOR DE LA GEMA", x, y, 0xAAAAAA, false);
        int seg = (w - 6) / 7;
        for (int i = 0; i < 7; i++) {
            int sx = x + i * (seg + 1);
            int col = HEAT_COLORS[i];
            boolean on = i <= data.heat();
            g.fill(sx, y + 11, sx + seg, y + 19, on ? 0xFF000000 | col : 0xFF000000 | ((col >> 2) & 0x3F3F3F));
            if (i == data.heat()) g.fill(sx, y + 20, sx + seg, y + 21, 0xFFFFFFFF);
        }
        g.drawString(font, HEAT_NAMES[data.heat()], x, y + 23, HEAT_COLORS[data.heat()], false);
    }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color, int size) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= steps; i++) {
            int px = x0 + (steps == 0 ? 0 : (x1 - x0) * i / steps) - size / 2;
            int py = y0 + (steps == 0 ? 0 : (y1 - y0) * i / steps) - size / 2;
            g.fill(px, py, px + size, py + size, color);
        }
    }

    private int wrap(GuiGraphics g, String text, int x, int y, int w, int color) {
        for (FormattedCharSequence seq : font.split(Component.literal(text), w)) {
            g.drawString(font, seq, x, y, color, false);
            y += 10;
        }
        return y;
    }
}
