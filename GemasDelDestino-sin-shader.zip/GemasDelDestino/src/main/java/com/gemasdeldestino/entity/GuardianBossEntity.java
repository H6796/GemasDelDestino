package com.gemasdeldestino.entity;

import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.registry.ModItems;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.UUID;

/**
 * Minijefe guardián de cada mazmorra. Duerme hasta que un jugador se acerca.
 * Al morir suelta la Llave del Sello que abre la cámara de la gema.
 */
public class GuardianBossEntity extends Monster {

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide && isAlive()) BossAuras.guardian(this);
    }

    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(GuardianBossEntity.class, EntityDataSerializers.INT);
    private static final UUID HEALTH_ID = UUID.fromString("6f0e9c62-31a3-4c2b-9d3e-6b7c3f1a2e01");

    private final ServerBossEvent bossEvent = new ServerBossEvent(Component.literal("Guardián"),
            BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_6);
    private boolean awake = false;
    private int freeze = 0;
    private int cooldown = 60;
    private boolean enraged = false;

    public GuardianBossEntity(EntityType<? extends GuardianBossEntity> type, Level level) {
        super(type, level);
        this.xpReward = 150;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 120.0D)
                .add(Attributes.ATTACK_DAMAGE, 7.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.7D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
    }

    public GemType getGem() {
        return GemType.byIndex(entityData.get(VARIANT));
    }

    /** Configura el guardián para la gema indicada: vida, daño, nombre y barra de jefe. */
    public void setup(GemType g) {
        entityData.set(VARIANT, g.ordinal());
        double extraHealth = 30.0D * g.ordinal() + (g == GemType.VACIO ? 40 : 0);
        var hp = getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) {
            hp.removeModifier(HEALTH_ID);
            hp.addPermanentModifier(new AttributeModifier(HEALTH_ID, "gemas_vida", extraHealth, AttributeModifier.Operation.ADDITION));
        }
        var dmg = getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg != null) dmg.setBaseValue(7.0D + g.ordinal() * 1.5D);
        setHealth(getMaxHealth());
        setCustomName(Component.literal(g.bossName()).withStyle(g.color, ChatFormatting.BOLD));
        refreshBar();
    }

    public static final String ARENA_TAG = "gemas_arena";

    /** Versión resucitada por Silas en el salón del trono: despierta y con menos vida. */
    public void setupArena(GemType g) {
        setup(g);
        setHealth(getMaxHealth() * 0.6F);
        awake = true;
        cooldown = 40 + random.nextInt(60);
        addTag(ARENA_TAG);
    }

    public boolean isArena() {
        return getTags().contains(ARENA_TAG);
    }

    private void refreshBar() {
        GemType g = getGem();
        bossEvent.setName(Component.literal(g.bossName()).withStyle(g.color, ChatFormatting.BOLD));
        bossEvent.setColor(g.barColor());
    }

    public boolean isAwake() {
        return awake;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> awake));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(level() instanceof ServerLevel level)) return;
        bossEvent.setProgress(getHealth() / getMaxHealth());

        if (!awake) {
            getNavigation().stop();
            setTarget(null);
            if (tickCount % 10 == 0) {
                Player near = level.getNearestPlayer(this, 11.0D);
                if (near != null && !near.isCreative() && !near.isSpectator()) wake(level);
            }
            return;
        }
        if (tickCount % 20 == 0) updateBarPlayers(level);
        if (freeze > 0) {
            freeze--;
            getNavigation().stop();
            return;
        }
        if (tickCount % 5 == 0) {
            level.sendParticles(enraged ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.ENCHANT,
                    getX(), getY() + 1.2, getZ(), 2, 0.4, 0.7, 0.4, 0.02);
        }
        if (!enraged && getHealth() < getMaxHealth() * 0.4F) {
            enraged = true;
            shout("¡No permitiré que llegues a la gema!");
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 600, 0));
            addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 600, 0));
            summonMinions(level, 2 + getGem().ordinal() / 2);
        }

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        if (--cooldown > 0) return;
        cooldown = enraged ? 45 : 80;
        useAbility(level, target, random.nextInt(2));
    }

    private void wake(ServerLevel level) {
        awake = true;
        freeze = StoryManager.onGuardianAwake(this);
        level.playSound(null, blockPosition(), SoundEvents.WITHER_AMBIENT, SoundSource.HOSTILE, 1.5F, 0.6F);
        updateBarPlayers(level);
    }

    private void updateBarPlayers(ServerLevel level) {
        for (ServerPlayer p : new ArrayList<>(bossEvent.getPlayers())) {
            if (p.distanceToSqr(this) > 40 * 40 || !p.isAlive()) bossEvent.removePlayer(p);
        }
        for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(32))) bossEvent.addPlayer(p);
    }

    private void useAbility(ServerLevel level, LivingEntity target, int which) {
        GemType g = getGem();
        switch (g) {
            case FUEGO -> {
                if (which == 0) {
                    for (int i = -2; i <= 2; i++) {
                        Vec3 dir = target.getEyePosition().subtract(getEyePosition()).normalize().yRot((float) Math.toRadians(i * 9));
                        SmallFireball fb = new SmallFireball(level, this, dir.x, dir.y, dir.z);
                        fb.setPos(getX() + dir.x, getEyeY() + dir.y, getZ() + dir.z);
                        level.addFreshEntity(fb);
                    }
                    level.playSound(null, blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.HOSTILE, 1.5F, 0.7F);
                } else {
                    for (Player p : playersNear(6)) p.setSecondsOnFire(5);
                    level.sendParticles(ParticleTypes.FLAME, getX(), getY() + 0.3, getZ(), 120, 3.0, 0.2, 3.0, 0.05);
                }
            }
            case TORMENTA -> {
                if (which == 0) {
                    lightning(level, target.position());
                } else {
                    for (int i = 0; i < 3; i++)
                        lightning(level, target.position().add(random.nextInt(7) - 3, 0, random.nextInt(7) - 3));
                }
            }
            case VIENTO -> {
                if (which == 0) {
                    target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 1));
                } else {
                    for (Player p : playersNear(8)) {
                        Vec3 push = p.position().subtract(position()).normalize();
                        p.setDeltaMovement(push.x * 2.0D, 0.8D, push.z * 2.0D);
                        p.hurtMarked = true;
                    }
                }
                level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1, getZ(), 60, 2.0, 0.5, 2.0, 0.2);
                level.playSound(null, blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.HOSTILE, 1.5F, 0.8F);
            }
            case TIERRA -> {
                if (which == 0) {
                    for (Player p : playersNear(7)) {
                        p.hurt(damageSources().mobAttack(this), 7.0F);
                        p.setDeltaMovement(p.getDeltaMovement().add(0, 0.9D, 0));
                        p.hurtMarked = true;
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                    }
                    level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 10, 3.0, 0.2, 3.0, 0.0);
                    level.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0F, 0.5F);
                } else {
                    summonMinions(level, 2);
                }
            }
            case HIELO -> {
                if (which == 0) {
                    for (Player p : playersNear(8)) {
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
                        p.setTicksFrozen(Math.max(p.getTicksFrozen(), 240));
                        p.hurt(damageSources().freeze(), 4.0F);
                    }
                    level.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1, getZ(), 150, 4.0, 1.0, 4.0, 0.05);
                } else {
                    summonMinions(level, 3);
                }
                level.playSound(null, blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.HOSTILE, 1.5F, 0.5F);
            }
            case LUZ -> {
                if (which == 0) {
                    for (Player p : playersNear(12)) {
                        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                        p.hurt(damageSources().magic(), 5.0F);
                    }
                    level.sendParticles(ParticleTypes.FLASH, getX(), getY() + 1, getZ(), 3, 0, 0, 0, 0);
                } else {
                    heal(15.0F);
                    level.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 60, 1.0, 1.5, 1.0, 0.05);
                }
                level.playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.5F, 1.5F);
            }
            case TIEMPO -> {
                if (which == 0) {
                    for (Player p : playersNear(14)) {
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 4));
                        p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 100, 2));
                    }
                } else {
                    addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 3));
                    addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 1));
                }
                level.sendParticles(ParticleTypes.ENCHANT, getX(), getY() + 1, getZ(), 150, 5.0, 2.0, 5.0, 0.5);
                level.playSound(null, blockPosition(), SoundEvents.BELL_RESONATE, SoundSource.HOSTILE, 1.5F, 0.5F);
            }
            case VACIO -> {
                if (which == 0) {
                    Vec3 behind = target.position().subtract(target.getLookAngle().multiply(2.5D, 0, 2.5D));
                    BlockPos bp = BlockPos.containing(behind);
                    if (level.getBlockState(bp).isAir() && level.getBlockState(bp.above()).isAir()) {
                        level.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1, getZ(), 50, 0.4, 1.0, 0.4, 0.5);
                        teleportTo(behind.x, behind.y, behind.z);
                        level.playSound(null, bp, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0F, 0.6F);
                    }
                } else {
                    for (Player p : playersNear(10)) {
                        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
                        p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                    }
                }
            }
        }
    }

    private void lightning(ServerLevel level, Vec3 pos) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(pos);
            level.addFreshEntity(bolt);
        }
    }

    private java.util.List<Player> playersNear(double r) {
        return level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(r), p -> !p.isSpectator() && !p.isCreative());
    }

    private void summonMinions(ServerLevel level, int n) {
        GemType g = getGem();
        for (int i = 0; i < n; i++) {
            Entity e = (i % 2 == 0 ? g.spawnerMob : g.secondMob()).create(level);
            if (!(e instanceof Mob mob)) continue;
            mob.moveTo(getX() + random.nextInt(5) - 2, getY(), getZ() + random.nextInt(5) - 2, 0, 0);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(blockPosition()), MobSpawnType.EVENT, null, null);
            level.addFreshEntity(mob);
        }
        level.playSound(null, blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 1.0F, 1.0F);
    }

    private void shout(String text) {
        GemType g = getGem();
        Component msg = Component.literal("<" + g.bossName() + "> ").withStyle(g.color)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE));
        for (Player p : level().getEntitiesOfClass(Player.class, new AABB(blockPosition()).inflate(30))) p.sendSystemMessage(msg);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() == this) return false;
        if (!awake && source.getEntity() instanceof Player && level() instanceof ServerLevel sl) wake(sl);
        if (freeze > 0) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void thunderHit(ServerLevel level, LightningBolt bolt) {
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && isArena()) {
            bossEvent.removeAllPlayers();
            StoryManager.onArenaGuardianDied(this);
            return;
        }
        if (!level().isClientSide) {
            spawnAtLocation(new ItemStack(ModItems.LLAVE_SELLO.get()));
            spawnAtLocation(new ItemStack(Items.EMERALD, 8 + random.nextInt(8) + getGem().ordinal() * 3));
            spawnAtLocation(new ItemStack(Items.DIAMOND, 1 + random.nextInt(2) + getGem().ordinal() / 2));
            if (getGem().ordinal() >= 2) spawnAtLocation(new ItemStack(Items.GOLDEN_APPLE, 2));
            shout("La llave... no... la gema... caerá en manos del Eclipse...");
            bossEvent.removeAllPlayers();
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Gema", entityData.get(VARIANT));
        tag.putBoolean("Despierto", awake);
        tag.putBoolean("Furia", enraged);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(VARIANT, tag.getInt("Gema"));
        awake = tag.getBoolean("Despierto");
        enraged = tag.getBoolean("Furia");
        refreshBar();
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }
}
