package com.gemasdeldestino.entity;

import com.gemasdeldestino.item.GemType;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

/**
 * Auras de partículas de los jefes. Solo se ejecuta en el cliente (no gasta red):
 *  - un anillo de polvo de color girando a ras de suelo,
 *  - dos chispas en espiral subiendo alrededor del cuerpo,
 *  - partículas del elemento saliendo del cuerpo,
 *  - más intensidad cuando el jefe está malherido.
 */
public final class BossAuras {
    private static final int[] GEM_RGB = {0xFF5A2A, 0x4FD8FF, 0xDDFFF4, 0x5BC236, 0x9FE7FF, 0xFFF27A, 0x2EC4A6, 0x9B4DFF};

    public static void guardian(GuardianBossEntity e) {
        GemType g = e.getGem();
        ring(e, 1.3, g.rgb, 1.4F, 12);
        spiral(e, 1.0, dust(g.rgb, 1.0F), 2);
        element(e, g);
    }

    public static void quimera(LivingEntity e) {
        Level level = e.level();
        // Anillo con los colores de las ocho gemas
        int n = 16;
        double a0 = e.tickCount * 0.05;
        if (e.tickCount % 3 == 0) {
            for (int i = 0; i < n; i++) {
                double a = a0 + Math.PI * 2 * i / n;
                level.addParticle(dust(GEM_RGB[i % 8], 2.0F), e.getX() + Math.cos(a) * 2.6, e.getY() + 0.1, e.getZ() + Math.sin(a) * 2.6, 0, 0, 0);
            }
        }
        spiral(e, 1.8, ParticleTypes.SOUL_FIRE_FLAME, 3);
        element(e, GemType.byIndex((e.tickCount / 40) % 8));
        if (enraged(e) && e.tickCount % 2 == 0) {
            RandomSource r = e.getRandom();
            level.addParticle(ParticleTypes.LAVA, e.getX() + (r.nextDouble() - 0.5) * 2, e.getY() + 3, e.getZ() + (r.nextDouble() - 0.5) * 2, 0, 0, 0);
        }
    }

    public static void silas(LivingEntity e) {
        Level level = e.level();
        ring(e, 1.4, 0x9B4DFF, 1.6F, 14);
        // Las ocho gemas orbitando a su alrededor, a la altura del pecho
        double a0 = e.tickCount * 0.08;
        for (int i = 0; i < 8; i++) {
            double a = a0 + Math.PI * 2 * i / 8;
            double y = e.getY() + 1.5 + Math.sin(a0 * 2 + i) * 0.25;
            level.addParticle(dust(GEM_RGB[i], 1.3F), e.getX() + Math.cos(a) * 1.5, y, e.getZ() + Math.sin(a) * 1.5, 0, 0, 0);
        }
        spiral(e, 1.0, ParticleTypes.REVERSE_PORTAL, 1);
        if (e.tickCount % 2 == 0) {
            RandomSource r = e.getRandom();
            level.addParticle(enraged(e) ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.SMOKE,
                    e.getX() + (r.nextDouble() - 0.5) * 0.8, e.getY() + 0.1, e.getZ() + (r.nextDouble() - 0.5) * 0.8, 0, 0.03, 0);
        }
    }

    // ------------------------------------------------------------------------------------
    private static void ring(LivingEntity e, double radius, int rgb, float size, int n) {
        if (e.tickCount % 4 != 0) return;
        double a0 = e.tickCount * 0.04;
        double r = radius * (enraged(e) ? 1.3 : 1.0) * e.getBbWidth() / 0.8;
        for (int i = 0; i < n; i++) {
            double a = a0 + Math.PI * 2 * i / n;
            e.level().addParticle(dust(rgb, size), e.getX() + Math.cos(a) * r, e.getY() + 0.08, e.getZ() + Math.sin(a) * r, 0, 0, 0);
        }
    }

    private static void spiral(LivingEntity e, double radius, ParticleOptions p, int arms) {
        double h = e.getBbHeight();
        double t = e.tickCount * 0.18;
        double y = (e.tickCount % 30) / 30.0 * h;
        for (int k = 0; k < arms; k++) {
            double a = t + Math.PI * 2 * k / arms;
            e.level().addParticle(p, e.getX() + Math.cos(a) * radius, e.getY() + y, e.getZ() + Math.sin(a) * radius, 0, 0.01, 0);
        }
    }

    private static void element(LivingEntity e, GemType g) {
        RandomSource r = e.getRandom();
        int every = enraged(e) ? 1 : 3;
        if (e.tickCount % every != 0) return;
        ParticleOptions p = switch (g) {
            case FUEGO -> r.nextInt(4) == 0 ? ParticleTypes.LAVA : ParticleTypes.FLAME;
            case TORMENTA -> ParticleTypes.ELECTRIC_SPARK;
            case VIENTO -> ParticleTypes.CLOUD;
            case TIERRA -> r.nextBoolean() ? ParticleTypes.SPORE_BLOSSOM_AIR : ParticleTypes.HAPPY_VILLAGER;
            case HIELO -> ParticleTypes.SNOWFLAKE;
            case LUZ -> r.nextBoolean() ? ParticleTypes.END_ROD : ParticleTypes.WAX_ON;
            case TIEMPO -> r.nextBoolean() ? ParticleTypes.ENCHANT : ParticleTypes.GLOW;
            case VACIO -> r.nextBoolean() ? ParticleTypes.PORTAL : ParticleTypes.SQUID_INK;
        };
        double w = e.getBbWidth();
        e.level().addParticle(p, e.getX() + (r.nextDouble() - 0.5) * w * 1.6, e.getY() + r.nextDouble() * e.getBbHeight(),
                e.getZ() + (r.nextDouble() - 0.5) * w * 1.6, (r.nextDouble() - 0.5) * 0.04, 0.03, (r.nextDouble() - 0.5) * 0.04);
    }

    private static boolean enraged(LivingEntity e) {
        return e.getHealth() < e.getMaxHealth() * 0.4F;
    }

    private static DustParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(new Vector3f(((rgb >> 16) & 255) / 255F, ((rgb >> 8) & 255) / 255F, (rgb & 255) / 255F), size);
    }

    private BossAuras() {}
}
