package com.gemasdeldestino.entity;

import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Silas, Señor del Eclipse. El jefe final: usa los poderes de las ocho gemas.
 */
public class SilasBossEntity extends Monster {

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide && isAlive()) BossAuras.silas(this);
    }

    private final ServerBossEvent bossEvent = (ServerBossEvent) new ServerBossEvent(
            Component.literal("Silas, Señor del Eclipse").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_20)
            .setDarkenScreen(true)
            .setPlayBossMusic(true);

    private int abilityCooldown = 60;
    private boolean summonedMinions = false;
    private boolean finalPhase = false;

    public SilasBossEntity(EntityType<? extends SilasBossEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 600.0D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ARMOR, 14.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    private boolean phaseTwo() {
        return getHealth() < getMaxHealth() * 0.5F;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        if (!(level() instanceof ServerLevel level)) return;

        if (tickCount % 4 == 0) {
            level.sendParticles(phaseTwo() ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.REVERSE_PORTAL,
                    getX(), getY() + 1.2, getZ(), 3, 0.4, 0.8, 0.4, 0.02);
        }

        if (phaseTwo() && !summonedMinions) {
            summonedMinions = true;
            speak("¡Sombras del Eclipse, a mí!");
            for (int i = 0; i < 4; i++) {
                Vex vex = EntityType.VEX.create(level);
                if (vex == null) continue;
                vex.moveTo(getX() + random.nextInt(5) - 2, getY() + 2, getZ() + random.nextInt(5) - 2, 0, 0);
                vex.finalizeSpawn(level, level.getCurrentDifficultyAt(blockPosition()), MobSpawnType.EVENT, null, null);
                level.addFreshEntity(vex);
            }
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 60, 1));
        }

        if (!finalPhase && getHealth() < getMaxHealth() * 0.25F) {
            finalPhase = true;
            speak("¡Sentid el poder de las OCHO GEMAS!");
            addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 999, 1));
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 999, 2));
            for (int i = 0; i < 4; i++) {
                net.minecraft.world.entity.monster.WitherSkeleton ws = EntityType.WITHER_SKELETON.create(level);
                if (ws == null) continue;
                ws.moveTo(getX() + random.nextInt(7) - 3, getY(), getZ() + random.nextInt(7) - 3, 0, 0);
                ws.finalizeSpawn(level, level.getCurrentDifficultyAt(blockPosition()), MobSpawnType.EVENT, null, null);
                level.addFreshEntity(ws);
            }
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 1, getZ(), 1, 0, 0, 0, 0);
        }

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        if (--abilityCooldown > 0) return;
        abilityCooldown = finalPhase ? 25 : phaseTwo() ? 40 : 60;

        switch (random.nextInt(8)) {
            case 0 -> { // FUEGO
                for (int i = -1; i <= 1; i++) {
                    Vec3 dir = target.getEyePosition().subtract(getEyePosition()).normalize().yRot((float) Math.toRadians(i * 10));
                    SmallFireball fb = new SmallFireball(level, this, dir.x, dir.y, dir.z);
                    fb.setPos(getX() + dir.x, getEyeY() + dir.y, getZ() + dir.z);
                    level.addFreshEntity(fb);
                }
                level.playSound(null, blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.HOSTILE, 1.5F, 0.7F);
            }
            case 1 -> { // TORMENTA
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                if (bolt != null) {
                    bolt.moveTo(target.position());
                    level.addFreshEntity(bolt);
                }
            }
            case 2 -> { // VIENTO
                Vec3 push = target.position().subtract(position()).normalize();
                target.setDeltaMovement(push.x * 1.5D, 1.2D, push.z * 1.5D);
                target.hurtMarked = true;
                level.sendParticles(ParticleTypes.CLOUD, target.getX(), target.getY(), target.getZ(), 40, 0.6, 0.3, 0.6, 0.1);
                level.playSound(null, target.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.HOSTILE, 1.5F, 0.8F);
            }
            case 3 -> { // TIERRA
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(6.0D))) {
                    p.hurt(damageSources().mobAttack(this), 6.0F);
                    p.knockback(1.2D, getX() - p.getX(), getZ() - p.getZ());
                }
                level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 8, 3.0, 0.2, 3.0, 0.0);
                level.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0F, 0.5F);
            }
            case 5 -> { // HIELO
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(10.0D))) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
                    p.setTicksFrozen(Math.max(p.getTicksFrozen(), 240));
                    p.hurt(damageSources().freeze(), 5.0F);
                }
                level.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1, getZ(), 200, 5.0, 1.0, 5.0, 0.05);
            }
            case 6 -> { // LUZ
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(14.0D))) {
                    p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 50, 0));
                }
                heal(12.0F);
                level.sendParticles(ParticleTypes.FLASH, getX(), getY() + 1, getZ(), 2, 0, 0, 0, 0);
            }
            case 7 -> { // TIEMPO
                for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(14.0D))) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 4));
                }
                addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 2));
                level.playSound(null, blockPosition(), SoundEvents.BELL_RESONATE, SoundSource.HOSTILE, 2.0F, 0.5F);
            }
            default -> { // VACÍO: se teletransporta detrás del objetivo
                Vec3 behind = target.position().subtract(target.getLookAngle().multiply(2.5D, 0, 2.5D));
                BlockPos bp = BlockPos.containing(behind);
                if (level.getBlockState(bp).isAir() && level.getBlockState(bp.above()).isAir()) {
                    level.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1, getZ(), 50, 0.4, 1.0, 0.4, 0.5);
                    teleportTo(behind.x, behind.y, behind.z);
                    level.playSound(null, bp, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0F, 0.6F);
                }
            }
        }
    }

    private void speak(String text) {
        Component msg = Component.literal("<Silas> ").withStyle(ChatFormatting.DARK_PURPLE)
                .append(Component.literal(text).withStyle(ChatFormatting.LIGHT_PURPLE));
        for (ServerPlayer p : bossEvent.getPlayers()) p.sendSystemMessage(msg);
    }

    @Override
    public void thunderHit(ServerLevel level, LightningBolt bolt) {
        // Silas controla las tormentas: los rayos no le afectan.
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() == this) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) {
            StoryManager.onBossDefeated(this);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }
}
