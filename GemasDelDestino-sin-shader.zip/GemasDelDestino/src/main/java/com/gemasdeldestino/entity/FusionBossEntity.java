package com.gemasdeldestino.entity;

import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * La Quimera del Eclipse: los ocho guardianes fusionados por Silas en un solo ser.
 * Usa al azar los poderes de las ocho gemas y se vuelve más rápido según pierde vida.
 */
public class FusionBossEntity extends Monster {

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide && isAlive()) BossAuras.quimera(this);
    }

    private final ServerBossEvent bossEvent = (ServerBossEvent) new ServerBossEvent(
            Component.literal("La Quimera del Eclipse").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD),
            BossEvent.BossBarColor.PINK, BossEvent.BossBarOverlay.NOTCHED_20)
            .setDarkenScreen(true)
            .setPlayBossMusic(true)
            .setCreateWorldFog(true);

    private int cooldown = 80;
    private int phase = 0;

    public FusionBossEntity(EntityType<? extends FusionBossEntity> type, Level level) {
        super(type, level);
        this.xpReward = 800;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 800.0D)
                .add(Attributes.ATTACK_DAMAGE, 14.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1D, true));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        if (!(level() instanceof ServerLevel level)) return;
        if (tickCount % 3 == 0) {
            GemType g = GemType.byIndex(random.nextInt(GemType.values().length));
            level.sendParticles(new net.minecraft.core.particles.DustParticleOptions(new org.joml.Vector3f(
                            ((g.rgb >> 16) & 255) / 255f, ((g.rgb >> 8) & 255) / 255f, (g.rgb & 255) / 255f), 2.0F),
                    getX(), getY() + 2.0, getZ(), 4, 0.8, 1.5, 0.8, 0.0);
        }
        float hp = getHealth() / getMaxHealth();
        if (phase == 0 && hp < 0.66F) {
            phase = 1;
            shout("¡SOMOS... OCHO... Y UNO!");
            summon(level, 4);
        } else if (phase == 1 && hp < 0.33F) {
            phase = 2;
            shout("¡EL ECLIPSE... NO CAERÁ!");
            summon(level, 6);
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 999, 1));
            addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 999, 1));
        }

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        if (--cooldown > 0) return;
        cooldown = phase == 2 ? 30 : phase == 1 ? 45 : 60;
        ability(level, target, GemType.byIndex(random.nextInt(GemType.values().length)));
    }

    private void ability(ServerLevel level, LivingEntity target, GemType g) {
        level.sendParticles(ParticleTypes.FLASH, getX(), getY() + 2, getZ(), 1, 0, 0, 0, 0);
        switch (g) {
            case FUEGO -> {
                for (int i = -3; i <= 3; i++) {
                    Vec3 dir = target.getEyePosition().subtract(getEyePosition()).normalize().yRot((float) Math.toRadians(i * 8));
                    SmallFireball fb = new SmallFireball(level, this, dir.x, dir.y, dir.z);
                    fb.setPos(getX() + dir.x * 2, getEyeY() + dir.y, getZ() + dir.z * 2);
                    level.addFreshEntity(fb);
                }
                level.playSound(null, blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.HOSTILE, 2.0F, 0.5F);
            }
            case TORMENTA -> {
                for (Player p : players(24)) {
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                    if (bolt != null) {
                        bolt.moveTo(p.position());
                        level.addFreshEntity(bolt);
                    }
                }
            }
            case VIENTO -> {
                for (Player p : players(10)) {
                    Vec3 push = p.position().subtract(position()).normalize();
                    p.setDeltaMovement(push.x * 2.5D, 1.2D, push.z * 2.5D);
                    p.hurtMarked = true;
                }
                level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1, getZ(), 120, 4.0, 0.5, 4.0, 0.3);
                level.playSound(null, blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.HOSTILE, 2.0F, 0.6F);
            }
            case TIERRA -> {
                for (Player p : players(9)) {
                    p.hurt(damageSources().mobAttack(this), 10.0F);
                    p.setDeltaMovement(p.getDeltaMovement().add(0, 1.0D, 0));
                    p.hurtMarked = true;
                }
                level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 20, 4.0, 0.2, 4.0, 0.0);
                level.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5F, 0.4F);
            }
            case HIELO -> {
                for (Player p : players(12)) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
                    p.setTicksFrozen(Math.max(p.getTicksFrozen(), 300));
                    p.hurt(damageSources().freeze(), 6.0F);
                }
                level.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1, getZ(), 250, 6.0, 1.5, 6.0, 0.05);
            }
            case LUZ -> {
                for (Player p : players(16)) {
                    p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                    p.hurt(damageSources().magic(), 6.0F);
                }
                heal(20.0F);
                level.playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 2.0F, 1.8F);
            }
            case TIEMPO -> {
                for (Player p : players(16)) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 4));
                    p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 120, 2));
                }
                level.sendParticles(ParticleTypes.ENCHANT, getX(), getY() + 2, getZ(), 250, 8.0, 3.0, 8.0, 0.6);
                level.playSound(null, blockPosition(), SoundEvents.BELL_RESONATE, SoundSource.HOSTILE, 2.0F, 0.4F);
            }
            case VACIO -> {
                Vec3 behind = target.position().subtract(target.getLookAngle().multiply(3.0D, 0, 3.0D));
                BlockPos bp = BlockPos.containing(behind);
                if (level.getBlockState(bp).isAir() && level.getBlockState(bp.above()).isAir() && level.getBlockState(bp.above(2)).isAir()) {
                    level.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 2, getZ(), 80, 0.8, 1.5, 0.8, 0.5);
                    teleportTo(behind.x, behind.y, behind.z);
                    level.playSound(null, bp, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.5F, 0.4F);
                }
                for (Player p : players(10)) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
            }
        }
    }

    private List<Player> players(double r) {
        return level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(r), p -> !p.isSpectator() && !p.isCreative());
    }

    private void summon(ServerLevel level, int n) {
        for (int i = 0; i < n; i++) {
            GemType g = GemType.byIndex(random.nextInt(GemType.values().length));
            Entity e = (random.nextBoolean() ? g.spawnerMob : g.secondMob()).create(level);
            if (!(e instanceof Mob mob)) continue;
            mob.moveTo(getX() + random.nextInt(9) - 4, getY(), getZ() + random.nextInt(9) - 4, 0, 0);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(blockPosition()), MobSpawnType.EVENT, null, null);
            level.addFreshEntity(mob);
        }
        level.playSound(null, blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 2.0F, 0.6F);
    }

    private void shout(String text) {
        Component msg = Component.literal("<La Quimera> ").withStyle(ChatFormatting.LIGHT_PURPLE)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD));
        for (ServerPlayer p : bossEvent.getPlayers()) p.sendSystemMessage(msg);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() == this) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void thunderHit(ServerLevel level, LightningBolt bolt) {
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) {
            bossEvent.removeAllPlayers();
            StoryManager.onFusionDefeated(this);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fase", phase);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        phase = tag.getInt("Fase");
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }
}
