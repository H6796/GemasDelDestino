package com.gemasdeldestino.cinematic;

import com.gemasdeldestino.item.GemType;

import java.util.HashMap;
import java.util.Map;

import static com.gemasdeldestino.story.DialogueLine.*;

/**
 * Todas las cinemáticas del mod. Las usan el servidor (para saber cuánto duran) y el cliente (para reproducirlas).
 */
public final class Cinematics {
    private static final Map<String, Cinematic> ALL = new HashMap<>();

    public static final String INTRO = "intro";
    public static final String BETRAYAL = "traicion";
    public static final String ENDING = "final";
    public static final String FORTRESS = "fortaleza";
    public static final String THRONE = "trono";
    public static final String FUSION = "fusion";
    public static final String SILAS_FINAL = "silas_final";

    public static String gemFound(int gem) {
        return "gema_" + gem;
    }

    public static String village(int gem) {
        return "pueblo_" + gem;
    }

    public static String dungeon(int gem) {
        return "mazmorra_" + gem;
    }

    public static String guardian(int gem) {
        return "guardian_" + gem;
    }

    private static final String[][] GUARDIAN_LINES = {
            {"¿Quién se atreve a despertar a Ignar?", "¡Arderás como todos los que vinieron antes!"},
            {"Siento la electricidad de tu miedo, mortal.", "¡Voltra no ha perdido un duelo en mil años!"},
            {"El viento me susurró que vendrías...", "¡Y también me susurró que caerías!"},
            {"Gorrak... despierta... ¡Gorrak aplasta!", "¡Nadie toca la gema de la Tierra!"},
            {"Tu sangre se congelará antes de que des un paso más.", "¡El invierno eterno comienza contigo!"},
            {"Una vez fui un ángel de luz... hasta que me encerraron aquí.", "¡Te cegaré con mil soles!"},
            {"Tic... tac... llegas tarde, mortal. Llevo siglos esperándote.", "¡Tu tiempo se ha acabado!"},
            {"Así que tú eres quien recoge las gemas para él...", "Qué ironía. Pero no saldrás de mi Vacío."}};

    static {
        // Ancla: centro del campamento (al nivel del suelo).
        register(new Cinematic(INTRO)
                .shot(-16, 12, -16, 16, 12, -16, 0, 1, 0, 130,
                        narrador("Hace mil años, ocho gemas nacieron del corazón del mundo: Fuego, Tormenta, Viento, Tierra, Hielo, Luz, Tiempo y Vacío.")).sound("beacon")
                .shot(16, 12, -16, 16, 9, 16, 0, 1, 0, 130,
                        narrador("Quien reuniera las ocho obtendría un poder capaz de doblegar la propia realidad."))
                .shot(16, 9, 16, -12, 6, 12, 0, 1, 0, 130,
                        narrador("Para protegerlas, los antiguos guardianes las ocultaron en bases secretas, bajo la tierra..."))
                .shot(-12, 6, 12, -4, 3, 5, 0, 1, 0, 130,
                        narrador("Pero la Orden del Eclipse ha despertado. Y alguien, muy cerca, desea las gemas más que nada.")).sound("wither")
                .shot(0, 2.6, 0, 0, 2.4, -1.4, 0, 1.6, -4, 110,
                        eldric("¡Por fin has llegado! Acércate al fuego, tenemos mucho de qué hablar.")));

        // Ancla: pedestal de la gema (dentro de la cámara de la base).
        for (GemType g : GemType.values()) {
            register(new Cinematic(gemFound(g.ordinal()))
                    .shot(-4, 3.5, -4, 4, 3.5, -4, 0.5, 1.2, 0.5, 80,
                            narrador("La " + g.gemName + " brilla con un poder ancestral...")).sound("chime")
                    .shot(4, 2.0, -3, 3, 1.6, 3, 0.5, 1.2, 0.5, 70,
                            narrador("Sientes su energía recorriendo tu cuerpo.")).sound("totem")
                    .shot(0, 4.5, 4, 0, 3.5, 1.5, 0.5, 1.0, 0.5, 70,
                            voz("Los ladrones de gemas no saldrán vivos del " + g.baseName + "...")).sound("portal"));
        }

        for (GemType g : GemType.values()) {
            com.gemasdeldestino.story.Chapters.Chapter ch = com.gemasdeldestino.story.Chapters.get(g.ordinal());
            // Ancla: centro del pueblo
            register(new Cinematic(village(g.ordinal()))
                    .shot(-22, 18, -22, 22, 16, -22, 0, 2, 0, 90,
                            narrador("Has llegado a " + ch.village() + ", el pueblo más cercano al " + g.baseName + ".")).sound("chime")
                    .shot(0, 5, 10, 0, 2.6, 2, 0, 1.6, -3, 80,
                            new com.gemasdeldestino.story.DialogueLine(ch.elder(), "Forastero... acércate. Te estábamos esperando.", 0xE6C27A)));
            // Ancla: centro de la sala de entrada de la mazmorra
            register(new Cinematic(dungeon(g.ordinal()))
                    .shot(-5, 4.5, -5, 5, 4.5, -5, 0, 1, 0, 80,
                            narrador("El " + g.baseName + ". El aire huele a magia antigua...")).sound("portal")
                    .shot(5, 3, 5, 3, 2.5, 5, -5, 1, 0, 80,
                            voz("Muchos entraron buscando la " + g.gemName + ". Ninguno salió.")));
            // Ancla: posición del guardián
            register(new Cinematic(guardian(g.ordinal()))
                    .shot(0, 2.6, 6, 0, 2.4, 4, 0, 2.3, 0, 70,
                            new com.gemasdeldestino.story.DialogueLine(g.bossName(), GUARDIAN_LINES[g.ordinal()][0], 0xFF5555)).sound("wither")
                    .shot(4, 1.2, 0, 0, 1.2, 4, 0, 2.6, 0, 60,
                            new com.gemasdeldestino.story.DialogueLine(g.bossName(), GUARDIAN_LINES[g.ordinal()][1], 0xFF5555)).sound("thunder"));
        }

        // Ancla: posición de Silas en el campamento.
        register(new Cinematic(BETRAYAL)
                .shot(0, 2.0, 5, 0, 1.8, 3, 0, 1.6, 0, 90,
                        silas("Ocho gemas... reunidas al fin.")).sound("chime")
                .shot(-4, 2.0, -3, -3, 2.0, -2, 0, 1.6, 0, 80,
                        eldric("¿Silas? ¿Qué estás haciendo?"))
                .shot(3, 1.2, 3, 2, 1.0, 2, 0, 1.8, 0, 100,
                        silas("¿Aún no lo entendéis? Yo soy el líder de la Orden del Eclipse.")).sound("thunder")
                .shot(2, 1.0, 2, -2, 2.5, 3, 0, 1.6, 0, 110,
                        silas("Vosotros hicisteis el trabajo sucio. Cada base, cada trampa... Gracias por traérmelas una a una."))
                .shot(-5, 2.5, 2, -4, 2.5, 4, 0, 1.6, 0, 90,
                        lyra("Las huellas... los diarios firmados con una 'S'... ¡Eras tú desde el principio!"))
                .shot(0, 6, 9, 0, 4, 6, 0, 2.0, 0, 100,
                        silas("Si queréis las gemas... ¡venid a buscarlas a mi Fortaleza del Eclipse!")).sound("portal"));

        // Ancla: centro de la fortaleza (a ras del suelo)
        register(new Cinematic(FORTRESS)
                .shot(0, 22, 125, 0, 30, 70, 0, 30, 0, 120,
                        narrador("La Fortaleza del Eclipse, suspendida sobre el vacío. Muros que ninguna herramienta puede romper.")).sound("wither")
                .shot(-75, 55, -60, 75, 55, -60, 0, 32, 0, 120,
                        narrador("En lo alto de cada torre brilla un Cristal de defensa. Mientras resistan, la puerta seguirá sellada."))
                .shot(0, 9, 58, 0, 6, 44, 0, 9, 33, 90,
                        new com.gemasdeldestino.story.DialogueLine("Silas (voz)", "Destruid mis cristales si podéis. Os estaré esperando en mi trono.", com.gemasdeldestino.story.DialogueLine.SILAS)));

        // Ancla: centro del salón del trono
        register(new Cinematic(THRONE)
                .shot(0, 3, 10, 0, 2.5, 2, 0, 3, -11, 100,
                        silas("Bienvenidos a la Fortaleza del Eclipse, mis queridos amigos.")).sound("chime")
                .shot(-7, 8, -3, 7, 8, -3, 0, 1, 0, 100,
                        silas("Con el poder de las ocho gemas he devuelto la vida a sus guardianes."))
                .shot(0, 7, 9, 0, 4, 5, 0, 2, 0, 90,
                        silas("¡Ahora sirven al Eclipse! ¡Guardianes, acabad con ellos!")).sound("wither"));

        register(new Cinematic(FUSION)
                .shot(0, 4, 8, 0, 3, 4, 0, 3, -6, 90,
                        silas("¿Creéis que habéis ganado? Qué adorable.")).sound("portal")
                .shot(-8, 5, 2, 0, 5, 8, 0, 1.5, 0, 100,
                        silas("Las almas de los guardianes me pertenecen. ¡UNÍOS!")).sound("thunder")
                .shot(0, 12, 10, 0, 7, 7, 0, 3, 0, 100,
                        narrador("Las ocho almas se funden en una sola criatura: la Quimera del Eclipse.")).sound("wither"));

        register(new Cinematic(SILAS_FINAL)
                .shot(0, 3, 2, 0, 2.6, -1, 0, 2.5, -6, 90,
                        silas("¡Basta! Si quieres algo bien hecho...")).sound("thunder")
                .shot(6, 2, -1, -6, 2, -1, 0, 2.2, -6, 100,
                        silas("...tienes que hacerlo tú mismo. ¡Venid, héroes! ¡Probad el poder de las ocho gemas!")).sound("wither"));

        // Ancla: centro del salón del trono
        register(new Cinematic(ENDING)
                .shot(0, 3, 6, 0, 3, 3, 0, 1.5, -2, 100,
                        silas("No... ¡las gemas! ¡Se están escapando del guantelete!")).sound("portal")
                .shot(0, 6, 8, 0, 11, 5, 0, 30, -2, 100,
                        narrador("Las ocho gemas atravesaron el techo de la fortaleza como estrellas fugaces...")).sound("thunder")
                .shot(-70, 70, -45, 70, 70, -45, 0, 40, 0, 120,
                        narrador("...y se dispersaron por los confines del mundo, esperando a un nuevo portador."))
                .shot(0, 8, 14, 0, 6, 10, 0, 4, 0, 110,
                        narrador("Silas ha caído. El Eclipse ha terminado... por ahora. FIN.")).sound("levelup"));
    }

    private static void register(Cinematic c) {
        ALL.put(c.id, c);
    }

    public static Cinematic get(String id) {
        return ALL.get(id);
    }

    public static int duration(String id) {
        Cinematic c = ALL.get(id);
        return c == null ? 0 : c.totalTicks();
    }

    private Cinematics() {}
}
