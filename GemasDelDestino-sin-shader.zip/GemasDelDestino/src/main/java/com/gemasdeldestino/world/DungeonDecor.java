package com.gemasdeldestino.world;

import com.gemasdeldestino.item.GemType;
import com.gemasdeldestino.world.DungeonBuilder.Room;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CaveVines;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * Decoración de las salas de las mazmorras.
 *
 * Cada gema tiene su propia paleta (columnas, molduras, vigas, antorchas, alfombras, estandartes y
 * objetos colgantes). La decoración se pone en dos pasadas:
 *  - {@link #decorate}: ANTES del contenido de la sala (columnas, marcos de puerta, molduras, vigas,
 *    lámparas, alfombra y trastos). El contenido de la sala se coloca encima y tiene prioridad.
 *  - {@link #finish}: DESPUÉS del contenido, con detalles propios de cada tipo de sala.
 *
 * Todo lo decorativo está DENTRO de los muros irrompibles: romperlo no permite salir de la sala.
 * Nunca se coloca nada en los huecos de puerta (posiciones 6-8 de cada muro, alturas 1-3).
 */
public final class DungeonDecor {

    /** Paleta de decoración de una mazmorra. */
    public record Theme(BlockState pillar, BlockState base, BlockState capital, Block stairs, Block slab,
                        BlockState beam, Block wallTorch, Block lantern, Block carpet, Block carpetEdge,
                        Block carpetCenter, Block banner, BlockState[] hanging, BlockState[] clutter) {}

    public static Theme theme(GemType g) {
        return switch (g) {
            case FUEGO -> new Theme(Blocks.POLISHED_BASALT.defaultBlockState(), Blocks.CHISELED_NETHER_BRICKS.defaultBlockState(),
                    Blocks.GILDED_BLACKSTONE.defaultBlockState(), Blocks.NETHER_BRICK_STAIRS, Blocks.NETHER_BRICK_SLAB,
                    Blocks.STRIPPED_CRIMSON_STEM.defaultBlockState(), Blocks.WALL_TORCH, Blocks.LANTERN,
                    Blocks.RED_CARPET, Blocks.BLACK_CARPET, Blocks.ORANGE_CARPET, Blocks.RED_WALL_BANNER,
                    states(Blocks.CHAIN.defaultBlockState(), Blocks.WEEPING_VINES.defaultBlockState(), Blocks.WEEPING_VINES.defaultBlockState()),
                    states(Blocks.DECORATED_POT.defaultBlockState(), candles(Blocks.RED_CANDLE), Blocks.SKELETON_SKULL.defaultBlockState(),
                            Blocks.POTTED_CRIMSON_FUNGUS.defaultBlockState(), Blocks.SHROOMLIGHT.defaultBlockState()));
            case TORMENTA -> new Theme(Blocks.WAXED_OXIDIZED_COPPER.defaultBlockState(), Blocks.CHISELED_DEEPSLATE.defaultBlockState(),
                    Blocks.WAXED_OXIDIZED_CUT_COPPER.defaultBlockState(), Blocks.DEEPSLATE_TILE_STAIRS, Blocks.DEEPSLATE_TILE_SLAB,
                    Blocks.STRIPPED_DARK_OAK_LOG.defaultBlockState(), Blocks.SOUL_WALL_TORCH, Blocks.SOUL_LANTERN,
                    Blocks.CYAN_CARPET, Blocks.GRAY_CARPET, Blocks.LIGHT_BLUE_CARPET, Blocks.CYAN_WALL_BANNER,
                    states(Blocks.CHAIN.defaultBlockState(), facing(Blocks.LIGHTNING_ROD, Direction.DOWN)),
                    states(Blocks.BARREL.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.UP),
                            Blocks.LIGHTNING_ROD.defaultBlockState(), candles(Blocks.CYAN_CANDLE), Blocks.DECORATED_POT.defaultBlockState()));
            case VIENTO -> new Theme(Blocks.QUARTZ_PILLAR.defaultBlockState(), Blocks.CHISELED_QUARTZ_BLOCK.defaultBlockState(),
                    Blocks.CHISELED_QUARTZ_BLOCK.defaultBlockState(), Blocks.QUARTZ_STAIRS, Blocks.QUARTZ_SLAB,
                    Blocks.STRIPPED_BIRCH_LOG.defaultBlockState(), Blocks.WALL_TORCH, Blocks.LANTERN,
                    Blocks.WHITE_CARPET, Blocks.LIGHT_BLUE_CARPET, Blocks.LIGHT_GRAY_CARPET, Blocks.WHITE_WALL_BANNER,
                    states(Blocks.CHAIN.defaultBlockState(), facing(Blocks.END_ROD, Direction.DOWN)),
                    states(Blocks.POTTED_AZURE_BLUET.defaultBlockState(), candles(Blocks.WHITE_CANDLE), Blocks.DECORATED_POT.defaultBlockState(),
                            Blocks.POTTED_BIRCH_SAPLING.defaultBlockState()));
            case TIERRA -> new Theme(Blocks.STRIPPED_OAK_LOG.defaultBlockState(), Blocks.MUD_BRICKS.defaultBlockState(),
                    Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), Blocks.MOSSY_STONE_BRICK_STAIRS, Blocks.MOSSY_STONE_BRICK_SLAB,
                    Blocks.OAK_LOG.defaultBlockState(), Blocks.WALL_TORCH, Blocks.LANTERN,
                    Blocks.GREEN_CARPET, Blocks.BROWN_CARPET, Blocks.MOSS_CARPET, Blocks.GREEN_WALL_BANNER,
                    states(Blocks.SPORE_BLOSSOM.defaultBlockState(), Blocks.HANGING_ROOTS.defaultBlockState(),
                            Blocks.CAVE_VINES.defaultBlockState().setValue(CaveVines.BERRIES, true)),
                    states(Blocks.POTTED_FERN.defaultBlockState(), Blocks.DECORATED_POT.defaultBlockState(), candles(Blocks.GREEN_CANDLE),
                            Blocks.MOSSY_COBBLESTONE.defaultBlockState(), Blocks.POTTED_RED_MUSHROOM.defaultBlockState()));
            case HIELO -> new Theme(Blocks.BLUE_ICE.defaultBlockState(), Blocks.POLISHED_DIORITE.defaultBlockState(),
                    Blocks.PACKED_ICE.defaultBlockState(), Blocks.POLISHED_DIORITE_STAIRS, Blocks.POLISHED_DIORITE_SLAB,
                    Blocks.STRIPPED_SPRUCE_LOG.defaultBlockState(), Blocks.SOUL_WALL_TORCH, Blocks.SOUL_LANTERN,
                    Blocks.LIGHT_BLUE_CARPET, Blocks.BLUE_CARPET, Blocks.WHITE_CARPET, Blocks.LIGHT_BLUE_WALL_BANNER,
                    states(Blocks.CHAIN.defaultBlockState(), facing(Blocks.END_ROD, Direction.DOWN)),
                    states(Blocks.POTTED_SPRUCE_SAPLING.defaultBlockState(), candles(Blocks.LIGHT_BLUE_CANDLE),
                            Blocks.BARREL.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.UP), Blocks.DECORATED_POT.defaultBlockState()));
            case LUZ -> new Theme(Blocks.QUARTZ_PILLAR.defaultBlockState(), Blocks.QUARTZ_BRICKS.defaultBlockState(),
                    Blocks.CHISELED_QUARTZ_BLOCK.defaultBlockState(), Blocks.SMOOTH_QUARTZ_STAIRS, Blocks.SMOOTH_QUARTZ_SLAB,
                    Blocks.SMOOTH_QUARTZ.defaultBlockState(), Blocks.WALL_TORCH, Blocks.LANTERN,
                    Blocks.YELLOW_CARPET, Blocks.WHITE_CARPET, Blocks.ORANGE_CARPET, Blocks.YELLOW_WALL_BANNER,
                    states(facing(Blocks.END_ROD, Direction.DOWN), Blocks.CHAIN.defaultBlockState()),
                    states(candles(Blocks.YELLOW_CANDLE), candles(Blocks.WHITE_CANDLE), Blocks.POTTED_LILY_OF_THE_VALLEY.defaultBlockState(),
                            Blocks.DECORATED_POT.defaultBlockState()));
            case TIEMPO -> new Theme(Blocks.WAXED_CUT_COPPER.defaultBlockState(), Blocks.DARK_PRISMARINE.defaultBlockState(),
                    Blocks.WAXED_COPPER_BLOCK.defaultBlockState(), Blocks.DARK_PRISMARINE_STAIRS, Blocks.DARK_PRISMARINE_SLAB,
                    Blocks.STRIPPED_WARPED_STEM.defaultBlockState(), Blocks.SOUL_WALL_TORCH, Blocks.SOUL_LANTERN,
                    Blocks.CYAN_CARPET, Blocks.BLACK_CARPET, Blocks.LIGHT_GRAY_CARPET, Blocks.BLACK_WALL_BANNER,
                    states(Blocks.CHAIN.defaultBlockState(), Blocks.CHAIN.defaultBlockState(), facing(Blocks.LIGHTNING_ROD, Direction.DOWN)),
                    states(Blocks.GRINDSTONE.defaultBlockState().setValue(BlockStateProperties.ATTACH_FACE, AttachFace.FLOOR),
                            Blocks.LODESTONE.defaultBlockState(), candles(Blocks.CYAN_CANDLE), Blocks.OBSERVER.defaultBlockState()));
            case VACIO -> new Theme(Blocks.PURPUR_PILLAR.defaultBlockState(), Blocks.CRYING_OBSIDIAN.defaultBlockState(),
                    Blocks.PURPUR_BLOCK.defaultBlockState(), Blocks.PURPUR_STAIRS, Blocks.PURPUR_SLAB,
                    Blocks.OBSIDIAN.defaultBlockState(), Blocks.SOUL_WALL_TORCH, Blocks.SOUL_LANTERN,
                    Blocks.PURPLE_CARPET, Blocks.BLACK_CARPET, Blocks.MAGENTA_CARPET, Blocks.PURPLE_WALL_BANNER,
                    states(facing(Blocks.AMETHYST_CLUSTER, Direction.DOWN), facing(Blocks.END_ROD, Direction.DOWN), Blocks.CHAIN.defaultBlockState()),
                    states(candles(Blocks.PURPLE_CANDLE), Blocks.AMETHYST_CLUSTER.defaultBlockState(), Blocks.ENDER_CHEST.defaultBlockState(),
                            Blocks.DRAGON_HEAD.defaultBlockState()));
        };
    }

    // =====================================================================================
    // Pasada 1: estructura decorativa (antes del contenido de la sala)
    // =====================================================================================
    public static void decorate(Builder b, GemType g, Room type, RandomSource r) {
        if (type == Room.LABERINTO) return; // el laberinto ocupa toda la sala
        Theme t = theme(g);
        boolean parkour = type == Room.PARKOUR;

        // Columnas en las esquinas
        for (int[] c : new int[][]{{1, 1}, {13, 1}, {1, 13}, {13, 13}}) column(b, t, c[0], c[1], 1, 5);

        // Moldura del techo (escaleras invertidas pegadas al muro)
        for (int i = 2; i <= 12; i++) {
            b.set(i, 6, 1, stair(t, Direction.NORTH, true));
            b.set(i, 6, 13, stair(t, Direction.SOUTH, true));
            b.set(1, 6, i, stair(t, Direction.WEST, true));
            b.set(13, 6, i, stair(t, Direction.EAST, true));
        }

        // Vigas en cruz y lámpara central
        for (int i = 2; i <= 12; i++) {
            b.set(7, 6, i, axis(t.beam(), Direction.Axis.Z));
            b.set(i, 6, 7, axis(t.beam(), Direction.Axis.X));
        }
        b.set(7, 6, 7, g.light.defaultBlockState());
        if (type != Room.ENTRADA) b.set(7, 5, 7, hanging(t.lantern()));
        for (int[] p : new int[][]{{7, 3}, {7, 11}, {3, 7}, {11, 7}}) b.set(p[0], 5, p[1], hanging(t.lantern()));

        // Cada muro: marco de puerta (o arco ciego), estandartes y antorchas
        for (Direction side : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
            if (type == Room.RUNAS && side == Direction.NORTH) continue; // ahí está el mural del puzzle
            if (!parkour) doorFrame(b, t, side);
            wall(b, side, 3, 5, banner(t, side));
            wall(b, side, 11, 5, banner(t, side));
            wall(b, side, 4, 3, torch(t, side));
            wall(b, side, 10, 3, torch(t, side));
        }

        // Cosas colgando del techo
        int hangs = 4 + r.nextInt(4);
        for (int i = 0; i < hangs; i++) {
            int x = 2 + r.nextInt(11), z = 2 + r.nextInt(11);
            if (x == 7 || z == 7) continue;
            BlockState h = t.hanging()[r.nextInt(t.hanging().length)];
            b.set(x, 6, z, h);
            if (h.is(Blocks.CHAIN) && r.nextBoolean()) b.set(x, 5, z, hanging(t.lantern()));
        }

        if (parkour) return;

        // Alfombra central con borde y rombo
        if (type == Room.ENTRADA || type == Room.DESCANSO || type == Room.BIBLIOTECA || type == Room.TESORO
                || type == Room.CAMARA || type == Room.DESAFIO || type == Room.GUARDIAN) {
            for (int x = 3; x <= 11; x++)
                for (int z = 3; z <= 11; z++) {
                    Block c = (x == 3 || x == 11 || z == 3 || z == 11) ? t.carpetEdge()
                            : Math.abs(x - 7) + Math.abs(z - 7) <= 2 ? t.carpetCenter() : t.carpet();
                    if (b.get(x, 1, z).isAir()) b.set(x, 1, z, c);
                }
        }

        // Trastos junto a las esquinas y telarañas en lo alto
        int[][] spots = {{2, 1}, {12, 1}, {2, 13}, {12, 13}, {1, 2}, {1, 12}, {13, 2}, {13, 12}};
        for (int[] p : spots) {
            if (r.nextInt(3) == 0) continue;
            if (b.get(p[0], 1, p[1]).isAir()) b.set(p[0], 1, p[1], t.clutter()[r.nextInt(t.clutter().length)]);
            if (r.nextInt(3) == 0 && b.get(p[0], 5, p[1]).isAir()) b.set(p[0], 5, p[1], Blocks.COBWEB.defaultBlockState());
        }
    }

    // =====================================================================================
    // Pasada 2: detalles de cada tipo de sala (después del contenido)
    // =====================================================================================
    public static void finish(Builder b, GemType g, Room type, RandomSource r) {
        Theme t = theme(g);
        switch (type) {
            case ENTRADA -> {
                // Dos estatuas de antiguos guardianes y dos braseros
                statue(b, t, 4, 11, 8);
                statue(b, t, 10, 11, 8);
                brazier(b, t, 4, 9, g);
                brazier(b, t, 10, 9, g);
            }
            case COMBATE -> {
                // Huesos, calaveras y cadenas: aquí ha habido muchas batallas
                for (int i = 0; i < 6; i++) {
                    int x = 2 + r.nextInt(11), z = 2 + r.nextInt(11);
                    if (doorLane(x, z) || !b.get(x, 1, z).isAir()) continue;
                    b.set(x, 1, z, i % 3 == 0 ? Blocks.BONE_BLOCK.defaultBlockState()
                            : (r.nextBoolean() ? Blocks.SKELETON_SKULL : Blocks.WITHER_SKELETON_SKULL).defaultBlockState()
                            .setValue(BlockStateProperties.ROTATION_16, r.nextInt(16)));
                }
                for (int[] p : new int[][]{{4, 4}, {10, 4}, {4, 10}, {10, 10}}) {
                    // Antorchas en las cuatro caras de cada pilar central
                    for (Direction d : Direction.Plane.HORIZONTAL) {
                        int x = p[0] + d.getStepX(), z = p[1] + d.getStepZ();
                        if (b.get(x, 3, z).isAir()) b.set(x, 3, z, t.wallTorch().defaultBlockState()
                                .setValue(BlockStateProperties.HORIZONTAL_FACING, d));
                    }
                }
            }
            case TESORO -> {
                // Montones de oro con velas alrededor de los cofres
                int[][] piles = {{3, 2}, {2, 3}, {11, 2}, {12, 3}, {3, 12}, {2, 11}, {11, 12}, {12, 11}};
                for (int[] p : piles) {
                    if (!b.get(p[0], 1, p[1]).isAir() && !isCarpet(b.get(p[0], 1, p[1]))) continue;
                    b.set(p[0], 1, p[1], (r.nextBoolean() ? Blocks.RAW_GOLD_BLOCK : Blocks.GOLD_BLOCK).defaultBlockState());
                    if (r.nextBoolean()) b.set(p[0], 2, p[1], candles(Blocks.YELLOW_CANDLE));
                }
                b.set(4, 1, 2, Blocks.DECORATED_POT.defaultBlockState());
                b.set(10, 1, 12, Blocks.DECORATED_POT.defaultBlockState());
                b.set(2, 1, 4, Blocks.AMETHYST_CLUSTER.defaultBlockState());
                b.set(12, 1, 10, Blocks.AMETHYST_CLUSTER.defaultBlockState());
            }
            case BIBLIOTECA -> {
                // Remate de las estanterías, mesa de lectura con sillas y estanterías cinceladas
                for (int i : new int[]{1, 2, 3, 4, 10, 11, 12, 13}) {
                    b.set(i, 4, 1, slab(t, true));
                    b.set(i, 4, 13, slab(t, true));
                    b.set(1, 4, i, slab(t, true));
                    b.set(13, 4, i, slab(t, true));
                }
                b.set(9, 1, 9, slab(t, true));
                b.set(10, 1, 9, slab(t, true));
                b.set(9, 2, 9, candles(Blocks.WHITE_CANDLE));
                b.set(9, 1, 10, stair(t, Direction.SOUTH, false));
                b.set(10, 1, 10, stair(t, Direction.SOUTH, false));
                b.set(1, 2, 2, Blocks.CHISELED_BOOKSHELF.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.EAST));
                b.set(13, 2, 12, Blocks.CHISELED_BOOKSHELF.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.WEST));
            }
            case DESCANSO -> {
                b.set(3, 1, 2, Blocks.POTTED_FERN.defaultBlockState());
                b.set(12, 2, 12, Blocks.LANTERN.defaultBlockState());
                b.set(12, 1, 3, Blocks.BARREL.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.UP));
                b.set(12, 1, 4, Blocks.BARREL.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.UP));
                b.set(2, 1, 4, Blocks.BOOKSHELF.defaultBlockState());
                b.set(2, 2, 4, candles(Blocks.WHITE_CANDLE));
            }
            case RUNAS -> {
                // Marco tallado alrededor del mural y velas junto a las runas
                for (int x = 3; x <= 11; x++) b.set(x, 5, 1, t.capital());
                b.set(3, 3, 1, t.capital());
                b.set(3, 4, 1, t.capital());
                b.set(11, 3, 1, t.capital());
                b.set(11, 4, 1, t.capital());
                b.set(3, 1, 10, candles(Blocks.WHITE_CANDLE));
                b.set(11, 1, 10, candles(Blocks.WHITE_CANDLE));
            }
            case DESAFIO -> {
                for (int[] p : new int[][]{{3, 3}, {11, 3}, {3, 11}, {11, 11}}) b.set(p[0], 3, p[1], facing(Blocks.END_ROD, Direction.UP));
            }
            case GUARDIAN -> {
                // Arena: braseros en las esquinas, cadenas colgantes y calaveras
                brazier(b, t, 2, 2, g);
                brazier(b, t, 12, 2, g);
                brazier(b, t, 2, 12, g);
                brazier(b, t, 12, 12, g);
                for (int[] p : new int[][]{{5, 5}, {9, 5}, {5, 9}, {9, 9}}) {
                    b.set(p[0], 6, p[1], Blocks.CHAIN.defaultBlockState());
                    b.set(p[0], 5, p[1], Blocks.CHAIN.defaultBlockState());
                    b.set(p[0], 4, p[1], hanging(Blocks.SOUL_LANTERN));
                }
                for (int i = 0; i < 4; i++) {
                    int x = 2 + r.nextInt(11), z = 2 + r.nextInt(11);
                    if (doorLane(x, z) || Math.abs(x - 7) < 3 && Math.abs(z - 7) < 3) continue;
                    if (b.get(x, 1, z).isAir() || isCarpet(b.get(x, 1, z)))
                        b.set(x, 1, z, Blocks.SKELETON_SKULL.defaultBlockState().setValue(BlockStateProperties.ROTATION_16, r.nextInt(16)));
                }
            }
            case CAMARA -> {
                // Estrado de la gema: escalones alrededor del pedestal y rayos de luz
                b.set(7, 1, 8, stair(t, Direction.NORTH, false));
                b.set(7, 1, 6, stair(t, Direction.SOUTH, false));
                b.set(6, 1, 7, stair(t, Direction.EAST, false));
                b.set(8, 1, 7, stair(t, Direction.WEST, false));
                for (int[] p : new int[][]{{6, 6}, {8, 6}, {6, 8}, {8, 8}}) b.set(p[0], 1, p[1], t.capital());
                for (int[] p : new int[][]{{5, 5}, {9, 5}, {5, 9}, {9, 9}}) b.set(p[0], 2, p[1], facing(Blocks.END_ROD, Direction.UP));
                for (int[] p : new int[][]{{4, 7}, {10, 7}, {7, 4}, {7, 10}}) b.set(p[0], 1, p[1], candles(Blocks.WHITE_CANDLE));
                statue(b, t, 3, 3, 14);
                statue(b, t, 11, 3, 2);
                statue(b, t, 3, 11, 10);
                statue(b, t, 11, 11, 6);
            }
            default -> {}
        }
    }

    // =====================================================================================
    // Piezas
    // =====================================================================================
    private static void column(Builder b, Theme t, int x, int z, int y0, int y1) {
        b.set(x, y0, z, t.base());
        for (int y = y0 + 1; y < y1; y++) b.set(x, y, z, t.pillar());
        b.set(x, y1, z, t.capital());
        b.set(x, y1 + 1, z, t.capital());
    }

    /** Marco de puerta en un muro: dos columnas y un dintel con clave. Si no hay puerta, queda un arco ciego. */
    private static void doorFrame(Builder b, Theme t, Direction side) {
        for (int y = 1; y <= 3; y++) {
            wall(b, side, 5, y, y == 1 ? t.base() : t.pillar());
            wall(b, side, 9, y, y == 1 ? t.base() : t.pillar());
        }
        wall(b, side, 5, 4, t.capital());
        wall(b, side, 9, 4, t.capital());
        wall(b, side, 7, 4, t.capital());
        boolean alongX = side == Direction.NORTH || side == Direction.SOUTH;
        wall(b, side, 6, 4, stair(t, alongX ? Direction.WEST : Direction.NORTH, true));
        wall(b, side, 8, 4, stair(t, alongX ? Direction.EAST : Direction.SOUTH, true));
    }

    /** Pone un bloque pegado al muro {@code side}, en la posición {@code i} (0-14) a lo largo de él. */
    private static void wall(Builder b, Direction side, int i, int y, BlockState s) {
        switch (side) {
            case NORTH -> b.set(i, y, 1, s);
            case SOUTH -> b.set(i, y, 13, s);
            case WEST -> b.set(1, y, i, s);
            default -> b.set(13, y, i, s);
        }
    }

    /** Estatua de un antiguo guardián: pedestal, cuerpo, hombros y calavera. */
    /** {@code rot}: hacia dónde mira (0 sur, 4 oeste, 8 norte, 12 este). */
    private static void statue(Builder b, Theme t, int x, int z, int rot) {
        b.set(x, 1, z, t.base());
        b.set(x, 2, z, t.pillar());
        b.set(x, 3, z, t.pillar());
        b.set(x, 4, z, Blocks.WITHER_SKELETON_SKULL.defaultBlockState().setValue(BlockStateProperties.ROTATION_16, rot));
    }

    private static void brazier(Builder b, Theme t, int x, int z, GemType g) {
        b.set(x, 1, z, t.base());
        b.set(x, 2, z, t.capital());
        boolean soul = g == GemType.TORMENTA || g == GemType.HIELO || g == GemType.TIEMPO || g == GemType.VACIO;
        b.set(x, 3, z, (soul ? Blocks.SOUL_CAMPFIRE : Blocks.CAMPFIRE).defaultBlockState());
    }

    private static boolean doorLane(int x, int z) {
        boolean midX = x >= 5 && x <= 9, midZ = z >= 5 && z <= 9;
        return (midX && (z <= 3 || z >= 11)) || (midZ && (x <= 3 || x >= 11));
    }

    private static boolean isCarpet(BlockState s) {
        return s.getBlock() instanceof net.minecraft.world.level.block.CarpetBlock;
    }

    // =====================================================================================
    // Estados de bloque
    // =====================================================================================
    private static BlockState stair(Theme t, Direction facing, boolean top) {
        return t.stairs().defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, facing)
                .setValue(BlockStateProperties.HALF, top ? Half.TOP : Half.BOTTOM);
    }

    private static BlockState slab(Theme t, boolean top) {
        return t.slab().defaultBlockState().setValue(BlockStateProperties.SLAB_TYPE, top ? SlabType.TOP : SlabType.BOTTOM);
    }

    private static BlockState banner(Theme t, Direction side) {
        return t.banner().defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, side.getOpposite());
    }

    private static BlockState torch(Theme t, Direction side) {
        return t.wallTorch().defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, side.getOpposite());
    }

    static BlockState hanging(Block lantern) {
        return with(lantern.defaultBlockState(), BlockStateProperties.HANGING, true);
    }

    static BlockState candles(Block candle) {
        return candle.defaultBlockState().setValue(BlockStateProperties.CANDLES, 3).setValue(BlockStateProperties.LIT, true);
    }

    static BlockState facing(Block block, Direction d) {
        return with(block.defaultBlockState(), BlockStateProperties.FACING, d);
    }

    static BlockState axis(BlockState s, Direction.Axis a) {
        return with(s, BlockStateProperties.AXIS, a);
    }

    static <T extends Comparable<T>> BlockState with(BlockState s, Property<T> p, T v) {
        return s.hasProperty(p) ? s.setValue(p, v) : s;
    }

    private static BlockState[] states(BlockState... s) {
        return s;
    }

    private DungeonDecor() {}
}
