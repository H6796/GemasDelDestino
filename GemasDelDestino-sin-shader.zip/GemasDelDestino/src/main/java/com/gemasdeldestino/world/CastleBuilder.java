package com.gemasdeldestino.world;

import com.gemasdeldestino.block.DungeonUtil;
import com.gemasdeldestino.registry.ModBlocks;
import com.gemasdeldestino.story.Lore;
import com.gemasdeldestino.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EndPortalFrameBlock;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * La Fortaleza del Eclipse: el castillo de Silas, en una isla flotante del End.
 *
 *  - Llegada: un islote al sur con la Grieta de vuelta al campamento.
 *  - Un puente sobre el vacío, con arcos, farolas y cadenas, lleva hasta la puerta.
 *  - Muralla irrompible de 16 bloques con contrafuertes, almenas y una gran puerta sellada
 *    entre dos torres, con el Ojo del Eclipse encima.
 *  - Cuatro torres redondas con generadores y un Cristal de defensa en lo alto de cada una.
 *    Al romper los cuatro cristales, el sello de la puerta desaparece.
 *  - Patio: avenida con los ocho santuarios de las gemas, jardines de coros, cementerio de la
 *    Orden, braseros y estatuas.
 *  - Torre del homenaje con el Salón del Trono (la arena final): columnas, nervaduras, balcones,
 *    vidrieras, un rosetón, lámparas colgantes, un círculo ritual en el suelo y el trono sobre un
 *    estrado. Encima, una aguja de 80 bloques con un halo flotante.
 *  - Islotes flotantes alrededor, cascadas de lava que caen al vacío y cristales colgando por debajo.
 */
public final class CastleBuilder {
    /** Centro del salón del trono relativo al centro del castillo. */
    public static final int THRONE_Z = -10;
    /** Mitad del lado interior del salón (la arena). */
    public static final int HALL = 12;
    /** Dónde se construye la fortaleza en el End (lejos de la isla del dragón). */
    public static final BlockPos END_CENTER = new BlockPos(0, 80, 640);

    static final int ISLAND_R = 62, ISLAND_DEPTH = 44;
    /** La muralla ocupa los anillos 33 y 34. La puerta está en el lado sur. */
    static final int WALL = 33, GATE_Z = 33;
    static final int ARRIVAL_Z = 96, RIFT_Z = 103;

    private static final Block[] GEM_GLASS = {Blocks.RED_STAINED_GLASS, Blocks.LIGHT_BLUE_STAINED_GLASS, Blocks.WHITE_STAINED_GLASS,
            Blocks.LIME_STAINED_GLASS, Blocks.BLUE_STAINED_GLASS, Blocks.YELLOW_STAINED_GLASS, Blocks.CYAN_STAINED_GLASS,
            Blocks.PURPLE_STAINED_GLASS};

    /** Construye toda la fortaleza repartida en ticks. Devuelve el último tick usado. */
    public static int build(ServerLevel level, BlockPos c) {
        RandomSource r = RandomSource.create(c.asLong() ^ 0xEC11L);
        long seed = c.asLong() ^ 0x15L;
        int t = 1;

        // ---- Islas
        for (int x0 = -ISLAND_R - 8; x0 <= ISLAND_R + 8; x0 += 3) {
            final int fx = x0;
            StoryManager.schedule(t++, s -> island(level, c, fx, fx + 2, ISLAND_R, ISLAND_DEPTH, seed));
        }
        StoryManager.schedule(t++, s -> island(level, c.offset(0, 0, ARRIVAL_Z), -16, 16, 11, 16, seed + 1));
        StoryManager.schedule(t++, s -> debris(level, c, RandomSource.create(seed + 2)));

        // ---- Suelo del patio y foso de cimientos de las torres
        StoryManager.schedule(t++, s -> courtyardFloor(level, c));

        // ---- Murallas, puerta y torres
        StoryManager.schedule(t++, s -> outerWall(level, c));
        StoryManager.schedule(t++, s -> gatehouse(level, c));
        int[][] towers = {{-34, -34, -1, -1}, {34, -34, 1, -1}, {-34, 34, -1, 1}, {34, 34, 1, 1}};
        for (int[] tw : towers) StoryManager.schedule(t++, s -> tower(level, c.offset(tw[0], 0, tw[1]), tw[2], tw[3], r));

        // ---- Torre del homenaje y Salón del Trono
        StoryManager.schedule(t++, s -> keepShell(level, c));
        StoryManager.schedule(t++, s -> hallFloor(level, c));
        StoryManager.schedule(t++, s -> hallColumnsAndVaults(level, c));
        StoryManager.schedule(t++, s -> hallWalls(level, c));
        StoryManager.schedule(t++, s -> throne(level, c));
        StoryManager.schedule(t++, s -> chandeliers(level, c));
        StoryManager.schedule(t++, s -> keepExterior(level, c));
        StoryManager.schedule(t++, s -> spire(level, c));

        // ---- Patio, puente, llegada y detalles
        StoryManager.schedule(t++, s -> courtyard(level, c, r));
        StoryManager.schedule(t++, s -> bridge(level, c));
        StoryManager.schedule(t++, s -> arrival(level, c));
        StoryManager.schedule(t++, s -> lavaFalls(level, c));

        // ---- Guarnición
        final int last = t + 3;
        StoryManager.schedule(last, s -> {
            EntityType<?>[] garrison = {EntityType.WITHER_SKELETON, EntityType.WITHER_SKELETON, EntityType.VINDICATOR, EntityType.VINDICATOR,
                    EntityType.VINDICATOR, EntityType.EVOKER, EntityType.PILLAGER, EntityType.PILLAGER, EntityType.RAVAGER, EntityType.BLAZE,
                    EntityType.ENDERMAN, EntityType.ENDERMAN};
            int[][] spots = {{-20, -6}, {20, -6}, {-20, 6}, {20, 6}, {-12, 22}, {12, 22}, {-20, 24}, {20, 24}, {0, -22}, {-10, -24},
                    {24, 0}, {-24, 0}};
            for (int i = 0; i < garrison.length; i++) spawnMob(level, garrison[i], c.offset(spots[i][0], 0, spots[i][1]));
            // Shulkers vigilando desde lo alto de la puerta y de la muralla
            int[][] shulkers = {{-5, 25, 36}, {5, 25, 36}, {-21, 16, -33}, {21, 16, -33}};
            for (int[] p : shulkers) spawnMob(level, EntityType.SHULKER, c.offset(p[0], p[1], p[2]));
            for (var p : level.players()) {
                if (p.blockPosition().closerThan(c, 300)) {
                    p.sendSystemMessage(Component.literal("El vacío ruge... la Fortaleza del Eclipse se alza ante ti.")
                            .withStyle(ChatFormatting.DARK_PURPLE));
                }
            }
        });
        return last;
    }

    // =====================================================================================
    // Islas flotantes
    // =====================================================================================
    /** Isla en forma de cono invertido con bordes irregulares. Construye solo las columnas x0..x1. */
    static void island(ServerLevel level, BlockPos center, int x0, int x1, int radius, int depth, long seed) {
        Builder b = new Builder(level, center);
        for (int x = x0; x <= x1; x++) {
            for (int z = -radius - 8; z <= radius + 8; z++) {
                double a = Math.atan2(z, x);
                double edge = radius + radius * 0.07 * Math.sin(3 * a + 1) + radius * 0.05 * Math.cos(5 * a) + radius * 0.03 * Math.sin(7 * a + 2);
                double d = Math.sqrt(x * x + z * z);
                if (d > edge) continue;
                double f = d / edge;
                int bottom = (int) (depth * Math.pow(1 - f, 0.75) + 2 + noise(x, z, seed) * 3);
                if (noise(x, z, seed + 7) < 0.03) bottom += 6 + (int) (noise(x, z, seed + 8) * 10); // estalactitas
                for (int y = -1; y >= -bottom; y--) {
                    double v = noise3(x, y, z, seed);
                    Block blk;
                    if (y == -1) blk = Blocks.END_STONE;
                    else if (y == -bottom && bottom > 8) blk = Blocks.OBSIDIAN;
                    else if (v < 0.06) blk = Blocks.OBSIDIAN;
                    else if (v < 0.09) blk = Blocks.CRYING_OBSIDIAN;
                    else if (v < 0.11) blk = Blocks.AMETHYST_BLOCK;
                    else blk = Blocks.END_STONE;
                    b.set(x, y, z, blk);
                }
                if (noise(x, z, seed + 3) < 0.05) b.set(x, -bottom - 1, z, DungeonDecor.facing(Blocks.AMETHYST_CLUSTER, Direction.DOWN));
            }
        }
    }

    /** Islotes sueltos alrededor de la fortaleza, con un obelisco de obsidiana. */
    private static void debris(ServerLevel level, BlockPos c, RandomSource r) {
        for (int i = 0; i < 7; i++) {
            double a = Math.PI * 2 * i / 7 + r.nextDouble() * 0.5;
            if (Math.abs(Math.sin(a) - 1) < 0.25) a += 0.6; // deja libre el puente (sur)
            int dist = 78 + r.nextInt(22);
            BlockPos p = c.offset((int) (Math.cos(a) * dist), -12 + r.nextInt(34), (int) (Math.sin(a) * dist));
            int rad = 3 + r.nextInt(4);
            island(level, p, -rad - 2, rad + 2, rad, rad * 2 + 2, r.nextLong());
            Builder b = new Builder(level, p);
            int h = 4 + r.nextInt(7);
            b.fill(0, 0, 0, 0, h, 0, Blocks.OBSIDIAN);
            b.set(0, h + 1, 0, Blocks.CRYING_OBSIDIAN);
            b.set(0, h + 2, 0, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
            if (rad >= 5) b.set(1, 0, 1, Blocks.CHORUS_FLOWER);
        }
    }

    private static void lavaFalls(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        for (int sx : new int[]{1, -1}) {
            for (int z : new int[]{-9, 10}) {
                for (int x = ISLAND_R + 10; x > 40; x--) {
                    if (!b.get(sx * x, -1, z).isAir()) {
                        b.set(sx * x, -1, z, Blocks.LAVA);
                        b.set(sx * (x - 1), -1, z, Blocks.MAGMA_BLOCK);
                        break;
                    }
                }
            }
        }
    }

    // =====================================================================================
    // Patio y muralla
    // =====================================================================================
    private static void courtyardFloor(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        for (int x = -32; x <= 32; x++)
            for (int z = -32; z <= 32; z++) {
                int m = Math.max(Math.abs(x), Math.abs(z));
                Block blk = Blocks.END_STONE_BRICKS;
                if (m == 32) blk = Blocks.OBSIDIAN;
                else if (m >= 15 && m <= 17) blk = (m == 16) ? Blocks.POLISHED_BLACKSTONE_BRICKS : Blocks.POLISHED_BLACKSTONE;
                else if (m > 17 && Math.abs(Math.abs(x) - Math.abs(z)) <= 1) blk = Blocks.POLISHED_BLACKSTONE_BRICKS;
                if (z >= 15 && Math.abs(x) <= 3) blk = x == 0 ? Blocks.PURPUR_BLOCK : Math.abs(x) == 3 ? Blocks.POLISHED_BLACKSTONE : Blocks.POLISHED_BLACKSTONE_BRICKS;
                b.set(x, -1, z, blk);
                b.fill(x, 0, z, x, 30, z, Blocks.AIR);
            }
        // Cimientos bajo las torres de las esquinas, por si asoman por el borde de la isla
        for (int[] k : new int[][]{{-34, -34}, {34, -34}, {-34, 34}, {34, 34}}) {
            for (int dy = 0; dy <= 14; dy++) {
                double rad = 8.5 - dy * 0.5;
                for (int x = -9; x <= 9; x++)
                    for (int z = -9; z <= 9; z++)
                        if (Math.sqrt(x * x + z * z) <= rad && b.get(k[0] + x, -2 - dy, k[1] + z).isAir())
                            b.set(k[0] + x, -2 - dy, k[1] + z, dy % 5 == 4 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
            }
        }
    }

    private static void outerWall(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        BlockState wall = ModBlocks.MURO_ECLIPSE.get().defaultBlockState();
        Direction[] sides = {Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
        for (Direction side : sides) {
            for (int i = -34; i <= 34; i++) {
                for (int d = WALL; d <= WALL + 1; d++) col(b, side, i, d, 0, 15, wall);
                if ((i & 1) == 0) put(b, side, i, WALL + 1, 16, wall);
                // Banda de obsidiana llorosa por fuera
                put(b, side, i, WALL + 2, 10, Blocks.CRYING_OBSIDIAN.defaultBlockState());
            }
            // Contrafuertes y estandartes por fuera
            for (int i = -24; i <= 24; i += 6) {
                if (side == Direction.SOUTH && Math.abs(i) <= 11) continue; // la puerta
                col(b, side, i, WALL + 2, 0, 13, Blocks.PURPUR_PILLAR.defaultBlockState());
                put(b, side, i, WALL + 2, 14, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
                col(b, side, i, WALL + 3, 0, 7, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
                put(b, side, i, WALL + 3, 8, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, side.getOpposite(), false));
                col(b, side, i, WALL + 4, 0, 3, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
                put(b, side, i, WALL + 4, 4, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, side.getOpposite(), false));
                if (Math.abs(i) <= 24) {
                    put(b, side, i + 3, WALL + 2, 13, Blocks.BLACK_WALL_BANNER.defaultBlockState()
                            .setValue(BlockStateProperties.HORIZONTAL_FACING, side));
                }
            }
        }
    }

    /** Gran puerta sellada entre dos torres, con el Ojo del Eclipse encima. */
    private static void gatehouse(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        BlockState wall = ModBlocks.MURO_ECLIPSE.get().defaultBlockState();
        // Torres de la puerta (macizas e irrompibles)
        for (int sx : new int[]{-1, 1}) {
            for (int x = 4; x <= 9; x++)
                for (int z = 32; z <= 38; z++) {
                    b.fill(sx * x, 0, z, sx * x, 24, z, wall);
                    boolean rim = x == 4 || x == 9 || z == 32 || z == 38;
                    if (rim && ((x + z) & 1) == 0) b.set(sx * x, 25, z, wall);
                }
            // Esquinas de purpur, ventanas y remates
            for (int[] k : new int[][]{{4, 39}, {9, 39}, {10, 38}}) {
                b.fill(sx * k[0], 0, k[1], sx * k[0], 24, k[1], Blocks.PURPUR_PILLAR);
                b.set(sx * k[0], 25, k[1], DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
            }
            for (int y = 14; y <= 19; y++)
                for (int x = 6; x <= 7; x++) b.set(sx * x, y, 38, (y == 19 ? Blocks.MAGENTA_STAINED_GLASS : Blocks.PURPLE_STAINED_GLASS));
            b.set(sx * 6, 20, 39, Blocks.BLACK_WALL_BANNER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
            b.set(sx * 7, 20, 39, Blocks.PURPLE_WALL_BANNER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
            b.set(sx * 7, 25, 35, Blocks.SOUL_LANTERN);
            // Braseros delante de la puerta
            b.fill(sx * 5, 0, 41, sx * 5, 2, 41, Blocks.POLISHED_BLACKSTONE_BRICKS);
            b.set(sx * 5, 3, 41, Blocks.SOUL_CAMPFIRE);
        }
        // Arco sobre la puerta (hasta la altura de las torres)
        b.fill(-3, 8, GATE_Z, 3, 24, GATE_Z + 1, wall);
        for (int x = -3; x <= 3; x += 2) b.set(x, 25, GATE_Z + 1, wall);
        // La puerta sellada
        b.fill(-3, 0, GATE_Z, 3, 7, GATE_Z + 1, ModBlocks.SELLO.get().defaultBlockState());
        // Marco exterior de la puerta
        int f = GATE_Z + 2;
        b.fill(-3, 8, f, 3, 8, f, Blocks.POLISHED_BLACKSTONE_BRICKS);
        b.set(0, 9, f, Blocks.CHISELED_POLISHED_BLACKSTONE);
        b.set(-3, 7, f, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, Direction.WEST, true));
        b.set(3, 7, f, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, Direction.EAST, true));
        // El Ojo del Eclipse
        for (int x = -3; x <= 3; x++)
            for (int y = 10; y <= 20; y++) {
                double d = Math.sqrt(x * x + (y - 15) * (y - 15));
                if (d <= 1.0) b.set(x, y, f, Blocks.PEARLESCENT_FROGLIGHT);
                else if (d <= 2.6) b.set(x, y, f, Blocks.PURPLE_STAINED_GLASS);
                else if (d <= 3.6) b.set(x, y, f, Blocks.CRYING_OBSIDIAN);
                else if (d <= 4.4 && (x == 0 || y == 15)) b.set(x, y, f, Blocks.OBSIDIAN);
            }
        // Cadenas colgando delante del sello
        for (int x : new int[]{-2, 2}) b.fill(x, 4, f, x, 7, f, Blocks.CHAIN);
    }

    /** Torre redonda de la muralla con el Cristal de defensa arriba. */
    private static void tower(ServerLevel level, BlockPos tc, int sx, int sz, RandomSource r) {
        Builder b = new Builder(level, tc);
        BlockState wall = ModBlocks.MURO_ECLIPSE.get().defaultBlockState();
        for (int x = -9; x <= 9; x++)
            for (int z = -9; z <= 9; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d <= 7.5) b.set(x, -1, z, Blocks.POLISHED_BLACKSTONE_BRICKS);
                if (d <= 5.5) {
                    b.fill(x, 0, z, x, 34, z, Blocks.AIR);
                    b.set(x, 12, z, Blocks.POLISHED_BLACKSTONE);
                    b.set(x, 24, z, Blocks.POLISHED_BLACKSTONE);
                    b.set(x, 35, z, Blocks.POLISHED_BLACKSTONE_BRICKS);
                } else if (d <= 7.5) {
                    b.fill(x, 0, z, x, 35, z, wall);
                    if (d > 6.5 && ((x + z) & 1) == 0) b.fill(x, 36, z, x, 37, z, wall);
                } else if (d <= 8.5) {
                    // Por fuera: bandas de obsidiana llorosa (solo donde hay aire)
                    for (int y : new int[]{12, 24, 34})
                        if (b.get(x, y, z).isAir()) b.set(x, y, z, Blocks.CRYING_OBSIDIAN);
                }
            }
        // Pilastras de purpur por fuera
        for (int[] p : new int[][]{{8, 0}, {-8, 0}, {0, 8}, {0, -8}, {6, 6}, {-6, 6}, {6, -6}, {-6, -6}}) {
            if (!b.get(p[0], 2, p[1]).isAir()) continue;
            for (int y = 0; y <= 35; y++) if (b.get(p[0], y, p[1]).isAir()) b.set(p[0], y, p[1], Blocks.PURPUR_PILLAR);
            b.set(p[0], 36, p[1], DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        }
        // Escalera de mano hasta la azotea
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
        for (int y = 0; y <= 35; y++) b.set(0, y, -5, ladder);
        // Puerta hacia el patio
        b.fill(-sx * 5, 0, -sz * 3, -sx * 6, 2, -sz * 3, Blocks.AIR);
        b.fill(-sx * 7, 0, -sz * 3, -sx * 7, 2, -sz * 3, Blocks.AIR);
        // Interior: generadores y luces
        spawner(b, level, 2, 0, 2, EntityType.WITHER_SKELETON, r);
        spawner(b, level, -2, 13, 2, EntityType.SKELETON, r);
        spawner(b, level, 2, 25, -2, EntityType.ENDERMAN, r);
        for (int y : new int[]{11, 23, 34}) {
            b.set(3, y, 0, DungeonDecor.hanging(Blocks.SOUL_LANTERN));
            b.set(-3, y, 0, DungeonDecor.hanging(Blocks.SOUL_LANTERN));
        }
        // Azotea: cristal de defensa sobre un altar, cuatro agujas y generadores
        b.fill(-1, 36, -1, 1, 36, 1, Blocks.CRYING_OBSIDIAN);
        b.set(0, 37, 0, ModBlocks.CRISTAL_DEFENSA.get());
        for (int[] p : new int[][]{{4, 4}, {-4, 4}, {4, -4}, {-4, -4}}) {
            b.fill(p[0], 36, p[1], p[0], 41, p[1], Blocks.OBSIDIAN);
            b.set(p[0], 42, p[1], Blocks.CRYING_OBSIDIAN);
            b.set(p[0], 43, p[1], DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        }
        spawner(b, level, 3, 36, 0, EntityType.BLAZE, r);
        spawner(b, level, -3, 36, 0, EntityType.SKELETON, r);
        b.set(0, 36, 3, Blocks.SOUL_LANTERN);
    }

    // =====================================================================================
    // Torre del homenaje y Salón del Trono
    // =====================================================================================
    private static void keepShell(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        BlockState wall = ModBlocks.MURO_ECLIPSE.get().defaultBlockState();
        b.fill(-14, 0, -14, 14, 22, 14, wall);
        b.fill(-HALL, 0, -HALL, HALL, 21, HALL, Blocks.AIR);
        for (int i = -14; i <= 14; i += 2) {
            b.set(i, 23, -14, wall); b.set(i, 23, 14, wall); b.set(-14, 23, i, wall); b.set(14, 23, i, wall);
        }
        b.fill(-3, 0, 13, 3, 8, 14, Blocks.AIR); // gran puerta
        // Luces en el techo (entre las nervaduras)
        for (int x : new int[]{-6, -2, 2, 6})
            for (int z : new int[]{-9, -3, 3, 9}) b.set(x, 22, z, ModBlocks.LUZ.get());
    }

    private static void hallFloor(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        for (int x = -HALL; x <= HALL; x++)
            for (int z = -HALL; z <= HALL; z++) {
                double d = Math.sqrt(x * x + z * z);
                Block blk = (x % 4 == 0 || z % 4 == 0) ? Blocks.POLISHED_BLACKSTONE_BRICKS : Blocks.POLISHED_BLACKSTONE;
                if (d >= 6.5 && d <= 7.5) blk = Blocks.CRYING_OBSIDIAN;
                else if (d <= 2.5) blk = Blocks.PURPUR_BLOCK;
                else if (d <= 3.5) blk = Blocks.OBSIDIAN;
                b.set(x, -1, z, blk);
                b.set(x, -2, z, Blocks.OBSIDIAN);
            }
        // Las ocho baldosas de las gemas, iluminadas desde abajo, donde reaparecen los guardianes
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            int x = (int) Math.round(Math.cos(a) * 7), z = (int) Math.round(Math.sin(a) * 7);
            b.set(x, -1, z, GEM_GLASS[i]);
            b.set(x, -2, z, ModBlocks.LUZ.get());
        }
        // Círculo ritual de marcos de portal alrededor del centro
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8 + Math.PI / 8;
            int x = (int) Math.round(Math.cos(a) * 3), z = (int) Math.round(Math.sin(a) * 3);
            Direction toCenter = Math.abs(x) > Math.abs(z) ? (x > 0 ? Direction.WEST : Direction.EAST) : (z > 0 ? Direction.NORTH : Direction.SOUTH);
            b.set(x, 0, z, Blocks.END_PORTAL_FRAME.defaultBlockState()
                    .setValue(EndPortalFrameBlock.FACING, toCenter).setValue(EndPortalFrameBlock.HAS_EYE, true));
        }
        b.set(0, -1, 0, Blocks.CRYING_OBSIDIAN);
        // Alfombra desde la puerta hasta el estrado
        for (int z = 4; z <= 12; z++) b.set(0, 0, z, Blocks.PURPLE_CARPET);
        for (int z = -7; z <= -4; z++) b.set(0, 0, z, Blocks.PURPLE_CARPET);
    }

    /** Columnas de purpur, nervaduras de la bóveda y balcones laterales. */
    private static void hallColumnsAndVaults(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        Block bricks = Blocks.POLISHED_BLACKSTONE_BRICKS;
        // Nervaduras longitudinales (x = ±9) y transversales (z = -6, 0, 6)
        int[] zs = {-12, -6, 0, 6, 12};
        for (int sx : new int[]{-9, 9}) {
            for (int k = 0; k < zs.length - 1; k++)
                for (int z = zs[k]; z <= zs[k + 1]; z++) {
                    double tt = (z - zs[k]) / 6.0;
                    int under = 15 + (int) Math.round(4 * Math.sin(Math.PI * tt));
                    b.fill(sx, under, z, sx, 21, z, bricks);
                }
        }
        int[] xs = {-12, -9, 9, 12};
        for (int z : new int[]{-6, 0, 6}) {
            for (int k = 0; k < xs.length - 1; k++) {
                int w = xs[k + 1] - xs[k];
                for (int x = xs[k]; x <= xs[k + 1]; x++) {
                    double tt = (x - xs[k]) / (double) w;
                    int under = 15 + (int) Math.round((w > 6 ? 6 : 2) * Math.sin(Math.PI * tt));
                    b.fill(x, under, z, x, 21, z, bricks);
                }
            }
        }
        // Columnas
        for (int x : new int[]{-9, 9})
            for (int z : new int[]{-6, 0, 6}) {
                b.fill(x, 0, z, x, 21, z, Blocks.PURPUR_PILLAR);
                b.set(x, 0, z, Blocks.CHISELED_POLISHED_BLACKSTONE);
                for (Direction d : Direction.Plane.HORIZONTAL) {
                    int px = x + d.getStepX(), pz = z + d.getStepZ();
                    b.set(px, 0, pz, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, d.getOpposite(), false));
                    if (b.get(px, 14, pz).isAir()) b.set(px, 14, pz, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, d.getOpposite(), true));
                }
                b.set(x, 13, z, Blocks.CRYING_OBSIDIAN);
            }
        // Balcones a los lados (x = 10..12), con barandilla y faroles
        for (int sx : new int[]{-1, 1}) {
            for (int z = -11; z <= 11; z++) {
                b.fill(sx * 10, 9, z, sx * 12, 9, z, bricks);
                b.set(sx * 10, 8, z, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, sx > 0 ? Direction.EAST : Direction.WEST, true));
                b.set(sx * 10, 10, z, Blocks.POLISHED_BLACKSTONE_BRICK_WALL);
                if (z % 3 == 0) b.set(sx * 10, 11, z, Blocks.SOUL_LANTERN);
            }
        }
    }

    /** Vidrieras, rosetón, estandartes y antorchas del salón. */
    private static void hallWalls(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        // Vidrieras altas en los muros este y oeste
        for (int sx : new int[]{-1, 1})
            for (int z0 : new int[]{-6, 0, 6})
                for (int dz = -1; dz <= 1; dz++)
                    for (int y = 11; y <= 19; y++) {
                        if (y == 19 && dz != 0) continue;
                        Block g = y == 15 ? Blocks.BLACK_STAINED_GLASS : dz == 0 ? Blocks.PURPLE_STAINED_GLASS : Blocks.MAGENTA_STAINED_GLASS;
                        b.set(sx * 13, y, z0 + dz, g);
                        b.set(sx * 14, y, z0 + dz, g);
                    }
        // Vidrieras en el muro sur, a los lados de la puerta
        for (int x0 : new int[]{-8, 8})
            for (int dx = -1; dx <= 1; dx++)
                for (int y = 11; y <= 19; y++) {
                    if (y == 19 && dx != 0) continue;
                    Block g = y == 15 ? Blocks.BLACK_STAINED_GLASS : dx == 0 ? Blocks.PURPLE_STAINED_GLASS : Blocks.MAGENTA_STAINED_GLASS;
                    b.set(x0 + dx, y, 13, g);
                    b.set(x0 + dx, y, 14, g);
                }
        // Rosetón detrás del trono
        for (int x = -5; x <= 5; x++)
            for (int y = 9; y <= 21; y++) {
                int dy = y - 15;
                double d = Math.sqrt(x * x + dy * dy);
                if (d > 4.5) continue;
                Block g;
                if (d <= 1.5) g = Blocks.MAGENTA_STAINED_GLASS;
                else if (x == 0 || dy == 0 || Math.abs(x) == Math.abs(dy)) g = Blocks.BLACK_STAINED_GLASS;
                else g = Blocks.PURPLE_STAINED_GLASS;
                b.set(x, y, -13, g);
                b.set(x, y, -14, g);
            }
        // Estandartes y antorchas bajo los balcones
        for (int sx : new int[]{-1, 1}) {
            Direction in = sx > 0 ? Direction.WEST : Direction.EAST;
            for (int z : new int[]{-9, -3, 3, 9}) {
                b.set(sx * 12, 7, z, (z % 2 == 0 ? Blocks.BLACK_WALL_BANNER : Blocks.PURPLE_WALL_BANNER).defaultBlockState()
                        .setValue(BlockStateProperties.HORIZONTAL_FACING, in));
                b.set(sx * 12, 17, z, Blocks.PURPLE_WALL_BANNER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, in));
            }
            for (int z : new int[]{-6, 0, 6})
                b.set(sx * 12, 4, z, Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, in));
        }
        // Estatuas a los lados de la entrada y el libro de Silas
        statue(b, -6, 10);
        statue(b, 6, 10);
        b.set(-10, 0, 10, Blocks.LECTERN.defaultBlockState().setValue(LecternBlock.HAS_BOOK, true));
        if (level.getBlockEntity(b.at(-10, 0, 10)) instanceof LecternBlockEntity l) {
            l.setBook(Lore.book("La Última Página", "S.",
                    "Si has llegado hasta aquí, has cruzado el vacío y destruido mis defensas.\n\nImpresionante.\n\n"
                            + "Pero los ocho guardianes me obedecen ahora. Y cuando caigan, sus almas me pertenecerán.\n\n- S."));
        }
    }

    /** Estrado de tres niveles y el trono de Silas. */
    private static void throne(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        Block bricks = Blocks.POLISHED_BLACKSTONE_BRICKS;
        Block st = Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS;
        int[][] tiers = {{7, -8}, {5, -9}, {3, -10}}; // {media anchura, borde delantero}
        for (int lv = 0; lv < tiers.length; lv++) {
            int w = tiers[lv][0], front = tiers[lv][1];
            b.fill(-w, lv, -12, w, lv, front, bricks);
            for (int x = -w + 1; x <= w - 1; x++) b.set(x, lv, front, stair(st, Direction.NORTH, false));
            for (int z = -12; z <= front; z++) {
                b.set(-w, lv, z, stair(st, Direction.EAST, false));
                b.set(w, lv, z, stair(st, Direction.WEST, false));
            }
            b.set(-w, lv, front, Blocks.CHISELED_POLISHED_BLACKSTONE);
            b.set(w, lv, front, Blocks.CHISELED_POLISHED_BLACKSTONE);
        }
        // El trono
        b.set(0, 3, -11, stair(Blocks.PURPUR_STAIRS, Direction.NORTH, false));
        b.set(-1, 3, -11, Blocks.GILDED_BLACKSTONE);
        b.set(1, 3, -11, Blocks.GILDED_BLACKSTONE);
        b.set(-1, 4, -11, Blocks.POLISHED_BLACKSTONE_BRICK_SLAB);
        b.set(1, 4, -11, Blocks.POLISHED_BLACKSTONE_BRICK_SLAB);
        b.fill(0, 3, -12, 0, 9, -12, Blocks.CRYING_OBSIDIAN);
        b.fill(-1, 3, -12, -1, 7, -12, Blocks.OBSIDIAN);
        b.fill(1, 3, -12, 1, 7, -12, Blocks.OBSIDIAN);
        b.fill(-2, 3, -12, -2, 5, -12, Blocks.GILDED_BLACKSTONE);
        b.fill(2, 3, -12, 2, 5, -12, Blocks.GILDED_BLACKSTONE);
        b.set(-1, 8, -12, Blocks.AMETHYST_CLUSTER);
        b.set(1, 8, -12, Blocks.AMETHYST_CLUSTER);
        b.set(-2, 6, -12, Blocks.AMETHYST_CLUSTER);
        b.set(2, 6, -12, Blocks.AMETHYST_CLUSTER);
        b.set(0, 10, -12, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        // Braseros a los lados del trono
        for (int x : new int[]{-5, 5}) {
            b.set(x, 2, -11, Blocks.POLISHED_BLACKSTONE_BRICK_WALL);
            b.set(x, 3, -11, Blocks.POLISHED_BLACKSTONE_BRICK_WALL);
            b.set(x, 4, -11, Blocks.SOUL_CAMPFIRE);
        }
        // Estandartes detrás del trono
        for (int x : new int[]{-8, -4, 4, 8}) {
            b.set(x, 8, -12, (Math.abs(x) == 4 ? Blocks.PURPLE_WALL_BANNER : Blocks.BLACK_WALL_BANNER).defaultBlockState()
                    .setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
        }
    }

    /** Una gran lámpara central y cuatro más pequeñas colgando de la bóveda. */
    private static void chandeliers(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        b.fill(0, 15, 0, 0, 21, 0, Blocks.CHAIN);
        b.set(0, 14, 0, Blocks.CRYING_OBSIDIAN);
        for (Direction d : Direction.Plane.HORIZONTAL) {
            int x1 = d.getStepX(), z1 = d.getStepZ();
            b.set(x1, 14, z1, slab(Blocks.POLISHED_BLACKSTONE_BRICK_SLAB, true));
            b.set(x1 * 2, 14, z1 * 2, Blocks.CHAIN);
            b.set(x1 * 2, 13, z1 * 2, DungeonDecor.hanging(Blocks.SOUL_LANTERN));
            b.set(x1 + z1, 14, z1 - x1, Blocks.CHAIN);
            b.set(x1 + z1, 13, z1 - x1, DungeonDecor.facing(Blocks.END_ROD, Direction.DOWN));
        }
        b.set(0, 13, 0, DungeonDecor.facing(Blocks.END_ROD, Direction.DOWN));
        for (int x : new int[]{-5, 5})
            for (int z : new int[]{-4, 4}) {
                b.fill(x, 17, z, x, 21, z, Blocks.CHAIN);
                b.set(x, 16, z, DungeonDecor.hanging(Blocks.SOUL_LANTERN));
            }
    }

    /** Fachada de la torre del homenaje: portada, pilastras, torretas de las esquinas y almenas. */
    private static void keepExterior(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        // Portada
        b.fill(-4, 0, 15, -4, 10, 15, Blocks.PURPUR_PILLAR);
        b.fill(4, 0, 15, 4, 10, 15, Blocks.PURPUR_PILLAR);
        b.fill(-4, 9, 15, 4, 9, 15, Blocks.POLISHED_BLACKSTONE_BRICKS);
        b.set(0, 10, 15, Blocks.CHISELED_POLISHED_BLACKSTONE);
        b.set(-3, 8, 15, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, Direction.WEST, true));
        b.set(3, 8, 15, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, Direction.EAST, true));
        b.set(-4, 11, 15, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        b.set(4, 11, 15, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        for (int x = -2; x <= 2; x++)
            for (int y = 11; y <= 15; y++) {
                double d = Math.sqrt(x * x + (y - 13) * (y - 13));
                if (d <= 0.9) b.set(x, y, 15, Blocks.PEARLESCENT_FROGLIGHT);
                else if (d <= 2.2) b.set(x, y, 15, Blocks.CRYING_OBSIDIAN);
            }
        b.set(-5, 5, 15, Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
        b.set(5, 5, 15, Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
        // Pilastras y banda en las cuatro fachadas
        for (Direction side : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
            // Las pilastras no tapan las vidrieras ni la puerta
            java.util.List<Integer> pil = switch (side) {
                case NORTH -> java.util.List.of(-9, -6, 6, 9);
                case SOUTH -> java.util.List.of(-6, 6);
                default -> java.util.List.of(-9, -3, 3, 9);
            };
            for (int i = -14; i <= 14; i++) {
                if (side == Direction.SOUTH && Math.abs(i) <= 4) continue;
                if (pil.contains(i)) {
                    col(b, side, i, 15, 0, 21, Blocks.PURPUR_PILLAR.defaultBlockState());
                    put(b, side, i, 15, 22, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
                } else {
                    put(b, side, i, 15, 10, Blocks.CRYING_OBSIDIAN.defaultBlockState());
                }
            }
        }
        // Torretas redondas en las esquinas, con aguja cónica
        for (int[] k : new int[][]{{-14, -14}, {14, -14}, {-14, 14}, {14, 14}}) {
            for (int x = -4; x <= 4; x++)
                for (int z = -4; z <= 4; z++) {
                    int wx = k[0] + x, wz = k[1] + z;
                    if (Math.max(Math.abs(wx), Math.abs(wz)) < 13) continue; // no invadir el salón
                    double d = Math.sqrt(x * x + z * z);
                    if (d > 3.5) continue;
                    for (int y = 0; y <= 32; y++) {
                        Block blk = (y == 12 || y == 24) ? Blocks.PURPUR_BLOCK : Blocks.POLISHED_BLACKSTONE_BRICKS;
                        b.set(wx, y, wz, blk);
                    }
                    if (d > 2.5 && ((x + z) & 1) == 0) b.set(wx, 33, wz, Blocks.POLISHED_BLACKSTONE_BRICK_WALL);
                }
            for (int y = 33; y <= 42; y++) {
                double rad = 3.0 * (1 - (y - 33) / 10.0);
                for (int x = -3; x <= 3; x++)
                    for (int z = -3; z <= 3; z++)
                        if (Math.sqrt(x * x + z * z) <= rad + 0.2)
                            b.set(k[0] + x, y, k[1] + z, (y & 1) == 0 ? Blocks.PURPUR_BLOCK : Blocks.OBSIDIAN);
            }
            b.set(k[0], 43, k[1], DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        }
    }

    /** Torre central sobre el salón y aguja con un halo flotante. */
    private static void spire(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        for (int x = -6; x <= 6; x++)
            for (int z = -6; z <= 6; z++) {
                int m = Math.max(Math.abs(x), Math.abs(z));
                for (int y = 23; y <= 50; y++) {
                    Block blk = Blocks.POLISHED_BLACKSTONE_BRICKS;
                    if (m == 6 && Math.abs(x) == 6 && Math.abs(z) == 6) blk = Blocks.PURPUR_PILLAR;
                    else if (m == 6 && (y == 36 || y == 46)) blk = Blocks.CRYING_OBSIDIAN;
                    else if (m == 6 && (Math.abs(x) <= 1 || Math.abs(z) <= 1) && y >= 29 && y <= 43)
                        blk = (Math.abs(x) == 0 || Math.abs(z) == 0) ? Blocks.PURPLE_STAINED_GLASS : Blocks.MAGENTA_STAINED_GLASS;
                    b.set(x, y, z, blk);
                }
                if (m == 6 && ((x + z) & 1) == 0) b.set(x, 51, z, Blocks.POLISHED_BLACKSTONE_BRICKS);
            }
        b.fill(-5, 24, -5, 5, 49, 5, ModBlocks.LUZ.get().defaultBlockState()); // brilla a través de las vidrieras
        b.fill(-4, 24, -4, 4, 49, 4, Blocks.OBSIDIAN);
        for (int y = 51; y <= 80; y++) {
            double rad = 5.0 * (1 - (y - 51) / 30.0);
            for (int x = -5; x <= 5; x++)
                for (int z = -5; z <= 5; z++)
                    if (Math.sqrt(x * x + z * z) <= rad + 0.3)
                        b.set(x, y, z, y % 6 == 0 ? Blocks.CRYING_OBSIDIAN : (y & 1) == 0 ? Blocks.OBSIDIAN : Blocks.PURPUR_BLOCK);
        }
        b.fill(0, 81, 0, 0, 84, 0, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        // Halo flotante
        for (int x = -10; x <= 10; x++)
            for (int z = -10; z <= 10; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d >= 8.6 && d <= 9.6) b.set(x, 66, z, Blocks.CRYING_OBSIDIAN);
            }
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            int x = (int) Math.round(Math.cos(a) * 9), z = (int) Math.round(Math.sin(a) * 9);
            b.set(x, 67, z, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
            b.set(x, 65, z, DungeonDecor.facing(Blocks.END_ROD, Direction.DOWN));
        }
    }

    // =====================================================================================
    // Patio
    // =====================================================================================
    private static void courtyard(ServerLevel level, BlockPos c, RandomSource r) {
        Builder b = new Builder(level, c);
        // Los ocho santuarios de las gemas a lo largo de la avenida
        int[] zs = {31, 28, 25, 22};
        for (int i = 0; i < 8; i++) {
            int x = i < 4 ? -6 : 6, z = zs[i % 4];
            b.set(x, 0, z, Blocks.CHISELED_POLISHED_BLACKSTONE);
            b.fill(x, 1, z, x, 2, z, Blocks.PURPUR_PILLAR);
            b.fill(x, 3, z, x, 4, z, GEM_GLASS[i]);
            b.set(x, 5, z, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
            for (Direction d : Direction.Plane.HORIZONTAL)
                b.set(x + d.getStepX(), 0, z + d.getStepZ(), stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, d.getOpposite(), false));
        }
        // Braseros en el camino de ronda alrededor de la torre del homenaje
        for (int[] p : new int[][]{{-16, -16}, {16, -16}, {-16, 16}, {16, 16}, {-16, 0}, {16, 0}, {0, -16}}) {
            b.fill(p[0], 0, p[1], p[0], 2, p[1], Blocks.POLISHED_BLACKSTONE_BRICKS);
            b.set(p[0], 3, p[1], Blocks.SOUL_CAMPFIRE);
        }
        // Estatuas delante de la torre del homenaje
        statue(b, -10, 19);
        statue(b, 10, 19);
        // Jardines de coros al este y al oeste
        for (int sx : new int[]{-1, 1}) {
            for (int x = 20; x <= 29; x++)
                for (int z = -11; z <= 11; z++) {
                    boolean border = x == 20 || x == 29 || z == -11 || z == 11;
                    b.set(sx * x, -1, z, Blocks.END_STONE);
                    if (border && !(z == 0 && x == 20)) b.set(sx * x, 0, z, Blocks.END_STONE_BRICK_WALL);
                }
            for (int i = 0; i < 9; i++) {
                int x = 22 + r.nextInt(6), z = -9 + r.nextInt(19);
                if (b.get(sx * x, 0, z).isAir()) b.set(sx * x, 0, z, i < 6 ? Blocks.CHORUS_FLOWER : Blocks.AMETHYST_CLUSTER);
            }
            for (int z : new int[]{-6, 6}) {
                b.fill(sx * 25, 0, z, sx * 25, 4, z, Blocks.PURPUR_PILLAR);
                b.set(sx * 25, 5, z, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
            }
        }
        // Cementerio de la Orden al norte
        for (int x = -10; x <= 10; x += 4)
            for (int z : new int[]{-27, -23}) {
                b.set(x, 0, z, Blocks.POLISHED_BLACKSTONE_BRICKS);
                b.set(x, 1, z, Blocks.POLISHED_BLACKSTONE_BRICK_SLAB);
                b.set(x, -1, z + 1, Blocks.SOUL_SOIL);
                if (r.nextBoolean()) b.set(x + 1, 0, z + 1, Blocks.SKELETON_SKULL.defaultBlockState()
                        .setValue(BlockStateProperties.ROTATION_16, r.nextInt(16)));
            }
        b.fill(-1, 0, -30, 1, 4, -30, Blocks.OBSIDIAN);
        b.set(0, 5, -30, Blocks.CRYING_OBSIDIAN);
        b.set(0, 6, -30, Blocks.WITHER_SKELETON_SKULL.defaultBlockState().setValue(BlockStateProperties.ROTATION_16, 0));
        // Generadores del patio
        spawner(b, level, -18, 0, 8, EntityType.WITHER_SKELETON, r);
        spawner(b, level, 18, 0, 8, EntityType.BLAZE, r);
        spawner(b, level, 12, 0, 27, EntityType.SKELETON, r);
        spawner(b, level, -12, 0, 27, EntityType.ENDERMAN, r);
    }

    // =====================================================================================
    // Puente y llegada
    // =====================================================================================
    private static void bridge(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c);
        int z0 = GATE_Z + 2, z1 = ARRIVAL_Z - 8;
        for (int z = z0; z <= z1; z++) {
            for (int x = -3; x <= 3; x++) {
                Block blk = x == 0 ? Blocks.PURPUR_BLOCK : Math.abs(x) == 3 ? Blocks.POLISHED_BLACKSTONE : Blocks.POLISHED_BLACKSTONE_BRICKS;
                b.set(x, -1, z, blk);
                if (z > z0) b.fill(x, 0, z, x, 6, z, Blocks.AIR);
                if (b.get(x, -2, z).isAir()) b.set(x, -2, z, slab(Blocks.POLISHED_BLACKSTONE_BRICK_SLAB, true));
            }
            if (z > 42) {
                b.set(-3, 0, z, Blocks.END_STONE_BRICK_WALL);
                b.set(3, 0, z, Blocks.END_STONE_BRICK_WALL);
            }
            if (z > 42 && z % 6 == 0) {
                for (int x : new int[]{-3, 3}) {
                    b.fill(x, 1, z, x, 2, z, Blocks.END_STONE_BRICK_WALL);
                    b.set(x, 3, z, Blocks.SOUL_LANTERN);
                    if (b.get(x, -3, z).isAir()) {
                        b.set(x, -3, z, Blocks.CHAIN);
                        b.set(x, -4, z, Blocks.CHAIN);
                        b.set(x, -5, z, DungeonDecor.hanging(Blocks.SOUL_LANTERN));
                    }
                }
            }
        }
        // Arcos sobre el puente
        for (int z : new int[]{62, 76}) {
            for (int x : new int[]{-4, 4}) b.fill(x, -3, z, x, 8, z, Blocks.OBSIDIAN);
            b.fill(-4, 9, z, 4, 9, z, Blocks.OBSIDIAN);
            b.set(0, 10, z, Blocks.CRYING_OBSIDIAN);
            b.set(0, 9, z, Blocks.CRYING_OBSIDIAN);
            b.set(-3, 8, z, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, Direction.WEST, true));
            b.set(3, 8, z, stair(Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS, Direction.EAST, true));
            b.set(0, 8, z, DungeonDecor.hanging(Blocks.SOUL_LANTERN));
            for (int x : new int[]{-4, 4}) b.set(x, 10, z, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
            // Pilares que bajan bajo el puente
            for (int dy = 2; dy <= 10; dy++) {
                int w = Math.max(0, 3 - dy / 3);
                b.fill(-w, -dy, z, w, -dy, z, Blocks.OBSIDIAN);
            }
        }
        // Estatuas al pie de la puerta
        statue(b, -7, 46);
        statue(b, 7, 46);
    }

    private static void arrival(ServerLevel level, BlockPos c) {
        Builder b = new Builder(level, c.offset(0, 0, ARRIVAL_Z));
        for (int x = -8; x <= 8; x++)
            for (int z = -8; z <= 8; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d > 7.5) continue;
                b.set(x, -1, z, d > 6.5 ? Blocks.PURPUR_BLOCK : d <= 1.5 ? Blocks.CRYING_OBSIDIAN : Blocks.POLISHED_BLACKSTONE_BRICKS);
                b.fill(x, 0, z, x, 8, z, Blocks.AIR);
            }
        for (int[] p : new int[][]{{-6, -3}, {6, -3}, {-6, 3}, {6, 3}}) {
            b.fill(p[0], 0, p[1], p[0], 2, p[1], Blocks.END_STONE_BRICK_WALL);
            b.set(p[0], 3, p[1], Blocks.SOUL_LANTERN);
        }
        buildRift(new Builder(level, c.offset(0, 0, RIFT_Z)));
    }

    // =====================================================================================
    // Grietas (portales entre el campamento y la fortaleza)
    // =====================================================================================
    /** Construye una Grieta del Eclipse en el mundo normal. */
    public static void buildCampRift(ServerLevel level, BlockPos pos) {
        Builder b = new Builder(level, pos);
        b.fill(-6, 0, -4, 6, 9, 4, Blocks.AIR);
        for (int x = -5; x <= 5; x++)
            for (int z = -3; z <= 3; z++) {
                b.set(x, -1, z, (Math.abs(x) == 5 || Math.abs(z) == 3) ? Blocks.PURPUR_BLOCK : Blocks.POLISHED_BLACKSTONE_BRICKS);
                for (int y = -2; y >= -7; y--) {
                    BlockState st = b.get(x, y, z);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.canBeReplaced()) b.set(x, y, z, Blocks.BLACKSTONE);
                }
            }
        b.set(0, -1, 2, Blocks.CRYING_OBSIDIAN);
        b.set(0, -1, -2, Blocks.CRYING_OBSIDIAN);
        buildRift(b);
    }

    /** Marco de la grieta (en el plano z = 0 del constructor). El hueco es x -2..2, y 0..4. */
    private static void buildRift(Builder b) {
        for (int y = 0; y <= 5; y++) {
            b.set(-3, y, 0, (y & 1) == 0 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
            b.set(3, y, 0, (y & 1) == 0 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
        }
        for (int x = -3; x <= 3; x++) b.set(x, 5, 0, (x & 1) == 0 ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN);
        b.fill(-2, 0, 0, 2, 4, 0, Blocks.AIR);
        b.set(0, 6, 0, Blocks.CRYING_OBSIDIAN);
        b.set(0, 7, 0, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        b.set(-2, 4, 0, DungeonDecor.facing(Blocks.AMETHYST_CLUSTER, Direction.DOWN));
        b.set(2, 4, 0, DungeonDecor.facing(Blocks.AMETHYST_CLUSTER, Direction.DOWN));
        for (int x : new int[]{-5, 5}) {
            b.fill(x, 0, 0, x, 3, 0, Blocks.OBSIDIAN);
            b.set(x, 4, 0, DungeonDecor.facing(Blocks.END_ROD, Direction.UP));
        }
    }

    /** ¿Está {@code p} dentro del hueco de la grieta construida en {@code rift}? */
    public static boolean inRift(BlockPos rift, BlockPos p) {
        int dx = p.getX() - rift.getX(), dy = p.getY() - rift.getY(), dz = p.getZ() - rift.getZ();
        return Math.abs(dx) <= 2 && dy >= 0 && dy <= 4 && Math.abs(dz) <= 1;
    }

    public static BlockPos endRift(BlockPos c) {
        return c.offset(0, 0, RIFT_Z);
    }

    /** Donde aparece el jugador al cruzar la grieta (mirando al norte, hacia el castillo). */
    public static BlockPos arrivalSpot(BlockPos c) {
        return c.offset(0, 0, ARRIVAL_Z - 2);
    }

    // =====================================================================================
    // Estado de la historia
    // =====================================================================================
    /** Rompe el sello de la puerta. */
    public static void openGate(ServerLevel level, BlockPos c) {
        DungeonUtil.breakBlocks(level, c.offset(0, 4, GATE_Z + 1), 4, 5, 4, ModBlocks.SELLO.get());
        // Fortalezas construidas con versiones antiguas del mod: la puerta estaba en z = 22
        DungeonUtil.breakBlocks(level, c.offset(0, 2, 22), 3, 3, 4, ModBlocks.SELLO.get());
    }

    public static BlockPos gate(BlockPos c) {
        return c.offset(0, 2, GATE_Z);
    }

    public static BlockPos throne(BlockPos c) {
        return c.offset(0, 0, THRONE_Z + 4);
    }

    /** ¿Está esta posición dentro del salón del trono? */
    public static boolean inHall(BlockPos c, BlockPos p) {
        return Math.abs(p.getX() - c.getX()) <= HALL && Math.abs(p.getZ() - c.getZ()) <= HALL
                && p.getY() >= c.getY() - 1 && p.getY() <= c.getY() + 16;
    }

    // =====================================================================================
    // Utilidades
    // =====================================================================================
    /** Estatua encapuchada de un caballero de la Orden (simétrica, 7 bloques de alto). */
    private static void statue(Builder b, int x, int z) {
        b.fill(x - 1, 0, z - 1, x + 1, 0, z + 1, Blocks.POLISHED_BLACKSTONE_BRICKS);
        b.fill(x, 1, z, x, 4, z, Blocks.POLISHED_BLACKSTONE);
        for (Direction d : Direction.Plane.HORIZONTAL) {
            b.set(x + d.getStepX(), 1, z + d.getStepZ(), stair(Blocks.BLACKSTONE_STAIRS, d.getOpposite(), false));
            b.set(x + d.getStepX(), 4, z + d.getStepZ(), stair(Blocks.BLACKSTONE_STAIRS, d.getOpposite(), true));
        }
        b.set(x, 5, z, Blocks.CRYING_OBSIDIAN);
        b.set(x, 6, z, Blocks.BLACKSTONE_SLAB);
    }

    /** Coloca una columna en el anillo {@code d} del lado {@code side}, posición {@code i} a lo largo. */
    private static void col(Builder b, Direction side, int i, int d, int y0, int y1, BlockState s) {
        for (int y = y0; y <= y1; y++) put(b, side, i, d, y, s);
    }

    private static void put(Builder b, Direction side, int i, int d, int y, BlockState s) {
        switch (side) {
            case NORTH -> b.set(i, y, -d, s);
            case SOUTH -> b.set(i, y, d, s);
            case WEST -> b.set(-d, y, i, s);
            default -> b.set(d, y, i, s);
        }
    }

    private static BlockState stair(Block block, Direction facing, boolean top) {
        return block.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, facing)
                .setValue(BlockStateProperties.HALF, top ? Half.TOP : Half.BOTTOM);
    }

    private static BlockState slab(Block block, boolean top) {
        return block.defaultBlockState().setValue(BlockStateProperties.SLAB_TYPE, top ? SlabType.TOP : SlabType.BOTTOM);
    }

    private static double noise(int x, int z, long seed) {
        long h = seed ^ (x * 341873128712L) ^ (z * 132897987541L);
        h = (h ^ (h >>> 13)) * 0x5bd1e995L;
        h ^= h >>> 15;
        return (h & 0xFFFF) / 65535.0;
    }

    private static double noise3(int x, int y, int z, long seed) {
        return noise(x + y * 7919, z - y * 104729, seed ^ (y * 0x9E3779B97F4A7C15L));
    }

    private static void spawner(Builder b, ServerLevel level, int x, int y, int z, EntityType<?> type, RandomSource r) {
        b.set(x, y, z, Blocks.SPAWNER);
        if (level.getBlockEntity(b.at(x, y, z)) instanceof SpawnerBlockEntity sp) sp.setEntityId(type, r);
    }

    private static void spawnMob(ServerLevel level, EntityType<?> type, BlockPos pos) {
        Entity e = type.create(level);
        if (!(e instanceof Mob mob)) return;
        mob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360, 0);
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
        mob.setPersistenceRequired();
        mob.setCustomName(Component.literal("Soldado del Eclipse").withStyle(ChatFormatting.DARK_PURPLE));
        level.addFreshEntity(mob);
    }

    private CastleBuilder() {}
}
